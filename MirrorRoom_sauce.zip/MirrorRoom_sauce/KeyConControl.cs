﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyConControl : MonoBehaviour {

    [SerializeField]
    private string seName;

    // Update is called once per frame
    void Update () {

        if (Input.GetKeyDown(KeyCode.Return))
        {

            AudioManager.Instance.PlaySE(seName);
            AudioManager.Instance.FadeOutBGM(1);
            LoadScene.Instance.ManiChange();
        }

	}
}
