﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultControl : MonoBehaviour
{
    [SerializeField]
    private GameObject resultTime;

    private GameStatus gameStatus;

    [SerializeField]
    private string ResultBgm;
    [SerializeField]
    private string okSeName;

    //--------------------------------------------------

    private void Awake()
    {
        Initialization();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            AudioManager.Instance.PlaySE(okSeName);
            LoadScene.Instance.TitleChange();
        }
    }

    //--------------------------------------------------

    /// <summary>
    /// 初期化メソッド
    /// </summary>
    private void Initialization()
    {
        gameStatus = GameObject.Find("GameStatusObj").GetComponent<GameStatus>();

        resultTime.GetComponent<Text>().text = gameStatus.TimeMinu10 + gameStatus.TimeMinu + ":" + gameStatus.TimeSec.ToString("F0");

        AudioManager.Instance.PlayBGM(ResultBgm);
    }
}
