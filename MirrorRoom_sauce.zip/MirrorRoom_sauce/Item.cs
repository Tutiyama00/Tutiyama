﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour {

    [SerializeField]
    private float positionRange;
    [SerializeField]
    private float rotationRange;


    [SerializeField]
    private Vector3 answerPosition;
    [SerializeField]
    private Vector3 answerRotation;

    [SerializeField]
    private bool answerFrag;

    private Vector3 minAnswerPosition;
    private Vector3 maxAnswerPosition;
    private float minAnswerRotation;
    private float maxAnswerRotation;

    public bool AnswerFrag { get { return answerFrag; } }

    [SerializeField]
    private string AnswerSeName;

    //------------------------------------------------------------------

    private void Awake()
    {
        Initialization();
        newJudge();
    }

    private void Update()
    {
        ////デバック用
        //if (Input.GetKeyDown(KeyCode.Space))
        //{
        //    print("debugKey_Space");
        //    Judge();
        //    print(minAnswerRotation);
        //    print(maxAnswerRotation);
        //    print(this.transform.localEulerAngles.y);
        //    print(minAnswerPosition);
        //    print(maxAnswerPosition);
        //}
    }

    //------------------------------------------------------------------


    private void newJudge()
    {
        answerFrag = false;

        if (JudgePosition(this.transform.position))
        {
            //print("positionはあってます");

            if (JudgeRotation(this.transform.localEulerAngles.y))
            {


                //print("正しいです。");
                print(this.name + "正しい");
                answerFrag = true;

            }
        }
    }

    /// <summary>
    /// このオブジェクトが正しい場所に置かれているかの判定メソッド
    /// </summary>
    public void Judge()
    {
        answerFrag = false;

        if (JudgePosition(this.transform.position))
        {
            //print("positionはあってます");

            if (JudgeRotation(this.transform.localEulerAngles.y))
            {
                AudioManager.Instance.PlaySE(AnswerSeName);

                //print("正しいです。");
                print(this.name + "正しい");
                answerFrag = true;
                
            }
        }

        //print(this.name + "正しくないです。");
       
        //answerFrag = false;
    }

    /// <summary>
    /// ポジションのジャッジ
    /// </summary>
    /// <param name="thisPosition"></param>
    /// <returns></returns>
    private bool JudgePosition(Vector3 thisPosition)
    {
        bool ok = false;

        if(minAnswerPosition.x <= thisPosition.x && thisPosition.x <= maxAnswerPosition.x)
        {
            if(minAnswerPosition.y <= thisPosition.y && thisPosition.y <= maxAnswerPosition.y)
            {
                if(minAnswerPosition.z <= thisPosition.z && thisPosition.z <= maxAnswerPosition.z)
                {
                    ok = true;
                }
            }
        }

        return ok;
    }

    /// <summary>
    /// ローテーションのジャッジ
    /// </summary>
    /// <param name="thisYRotation"></param>
    /// <returns></returns>
    private bool JudgeRotation(float thisYRotation)
    {
        bool ok = false;

        if(minAnswerRotation <= thisYRotation && thisYRotation <= maxAnswerRotation)
        {
            ok = true;
        }

        return ok;
    }

    /// <summary>
    /// 初期化メソッド
    /// </summary>
    private void Initialization()
    {
        minAnswerPosition = new Vector3(answerPosition.x - positionRange, answerPosition.y - positionRange, answerPosition.z - positionRange);
        maxAnswerPosition = new Vector3(answerPosition.x + positionRange, answerPosition.y + positionRange, answerPosition.z + positionRange);
        minAnswerRotation = answerRotation.y - rotationRange;
        maxAnswerRotation = answerRotation.y + rotationRange;
    }

}
