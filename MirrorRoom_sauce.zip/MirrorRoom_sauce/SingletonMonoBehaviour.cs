﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SingletonMonoBehaviour<T> : MonoBehaviour where T : MonoBehaviour
{

    private static T instance;
 
    public static T Instance
    {
        get
        {
            if (instance == null)
            {
                instance = (T)FindObjectOfType(typeof(T));

                if (instance == null) print(typeof(T) + "がアタッチされたGameObjectは見つかりませんでした。");
            }

            return instance;
        }
    }

    protected virtual void Awake()
    {
        CheckInstance();
    }


    protected void CheckInstance()
    {
        if(instance == null)
        {
            instance = this as T;
        }
        else if(instance != this)
        {
            print(typeof(T) + "が重複したのでDestroyしました。");

            Destroy(this.gameObject);
        }
    }
}
