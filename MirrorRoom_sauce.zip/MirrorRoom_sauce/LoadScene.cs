﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;



public class LoadScene : SingletonMonoBehaviour<LoadScene>
{
    protected override void Awake()
    {
        base.Awake();
        DontDestroyOnLoad(this.gameObject);
    }

    public void ManiChange()
    {
        
        SceneManager.LoadScene("MAINSCENE");
       
    }

    public void ResultChange()
    {
        SceneManager.LoadScene("RESULT");
    }

    public void TitleChange()
    {
        SceneManager.LoadScene("TITLE");
    }

   public void KeyConChange()
    {
        SceneManager.LoadScene("KeyCon");
    }

}
