﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpeed : MonoBehaviour {
    //最大速度
    [SerializeField]
    private float maxVelocity;
    //最大速度の2乗
    private float maxSqrVelocity;

    private Rigidbody rigidbody;

	void Start () {
		rigidbody= GetComponent<Rigidbody>();
        //最大速度の2乗を求めておく
        maxSqrVelocity = maxVelocity * maxVelocity;
    }
	
	void Update () {
        //速度チェック
        if (rigidbody.velocity.sqrMagnitude > maxSqrVelocity)
        {
            //物理オブジェクトの速度をmaxVelocityで指定した最大速度にする
            rigidbody.velocity = rigidbody.velocity.normalized * maxVelocity;
        }
    }
}
