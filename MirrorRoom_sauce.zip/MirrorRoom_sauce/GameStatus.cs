﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStatus : MonoBehaviour {

    private float timeSec;
    private float timeMinu;
    private float timeMinu10;

    public float TimeSec { get { return timeSec; } set { timeSec = value; } }
    public float TimeMinu { get { return timeMinu; } set { timeMinu = value; } }
    public float TimeMinu10 { get { return timeMinu10; } set { timeMinu10 = value; } }

    private void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
    }
}
