﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameControl : MonoBehaviour
{
    [SerializeField]
    private GameObject Namber1;
    [SerializeField]
    private GameObject Namber2;
    [SerializeField]
    private GameObject Namber3;
    [SerializeField]
    private GameObject StartObj;
    [SerializeField]
    private GameObject AnswerCountObj;
    [SerializeField]
    private GameObject AllAnswerCountObj;
    [SerializeField]
    private GameObject ItemSample;
    [SerializeField]
    private GameObject TimerObj;
    [SerializeField]
    private GameObject MenuSceneObj;
    [SerializeField]
    private GameObject Player;

    [SerializeField]
    private string bgmName;
    [SerializeField]
    private string menuOpenSeName, menuCloseSeName;
    [SerializeField]
    private string countDounSeName1, countDounSeName2, countDounSeName3;
    [SerializeField]
    private string startSeName;
    [SerializeField]
    private string gameClearSeName, gameClearBoiceSeName;
    [SerializeField]
    private GameObject gameClearObj;


    private List<GameObject> Object_list = new List<GameObject>();
    private List<Item> item_list = new List<Item>();

    private int answerCount;
    private int allAnswerCount;

    private float playTime;
    private bool timerActive;
    private float timeSeconds;
    private float timeMinute;
    private float timeMinute10;
    private Text playTimeText;

    private float ClearTime;

    private bool menuFrag;
    private MenuControl menuControl;

    //-----------------------------------------------

    private void Awake()
    {
        Initialization();
        
    }

    private void Start()
    {
        AudioManager.Instance.ChangeVolume(0.3f, 1f);
        AllJudge();
        StartCoroutine("CountDownMain");
    }

    private void Update()
    {
        TimerCount();

        MenuSceneSelect();

        ////デバッグ用
        //if (Input.GetKeyDown(KeyCode.V))
        //{
        //    print("debugKey_v");
        //    AllJudge();
        //}
    }

    //--------------------------------------------

    /// <summary>
    /// カウントダウンメソッド
    /// </summary>
    private IEnumerator CountDownMain()
    {
        CountDown(3);
        AudioManager.Instance.PlaySE(countDounSeName3);

        yield return new WaitForSeconds(1.0f);

        CountDown(2);
        AudioManager.Instance.PlaySE(countDounSeName2);

        yield return new WaitForSeconds(1.0f);

        CountDown(1);
        AudioManager.Instance.PlaySE(countDounSeName1);

        yield return new WaitForSeconds(1.0f);

        CountDown(0);
        AudioManager.Instance.PlaySE(startSeName);

        yield return new WaitForSeconds(1.0f);

       
        AudioManager.Instance.PlayBGM(bgmName);
       
        CountDown();

        timerActive = true;

        Player.GetComponent<Player>().CanMove = true;

       
    }


    /// <summary>
    /// カウントダウンで表示するものを選択
    /// </summary>
    /// <param name="Namber"></param>
    private void CountDown(int Namber)
    {
        switch (Namber)
        {
            case 1:
                Namber1.SetActive(false);
                Namber2.SetActive(false);
                Namber3.SetActive(false);
                StartObj.SetActive(false);

                Namber1.SetActive(true);

                break;

            case 2:
                Namber1.SetActive(false);
                Namber2.SetActive(false);
                Namber3.SetActive(false);
                StartObj.SetActive(false);

                Namber2.SetActive(true);

                break;

            case 3:
                Namber1.SetActive(false);
                Namber2.SetActive(false);
                Namber3.SetActive(false);
                StartObj.SetActive(false);

                Namber3.SetActive(true);

                break;

            case 0:
                Namber1.SetActive(false);
                Namber2.SetActive(false);
                Namber3.SetActive(false);
                StartObj.SetActive(false);

                StartObj.SetActive(true);

                break;
        }
    }

    /// <summary>
    /// カウントダウンの最後に呼ぶメソッド
    /// </summary>
    private void CountDown()
    {
        Namber1.SetActive(false);
        Namber2.SetActive(false);
        Namber3.SetActive(false);
        StartObj.SetActive(false);
    }


    /// <summary>
    /// 全てのオブジェクトが正しい場所に置かれているのかをジャッジ。正解数も表示
    /// </summary>
    public void AllJudge()
    {
        answerCount = 0;

        foreach (Item item in item_list)
        {
            if (item.AnswerFrag)
            {
                answerCount++;
            }
        }

        //foreach (GameObject obj in Object_list)
        //{
        //    print("ww");
        //    if (obj.GetComponent<Item>().AnswerFrag)
        //    {
        //        print(obj.name);
        //        answerCount++;
        //    }
        //}

        AnswerCountObj.GetComponent<Text>().text = answerCount.ToString();

        //全てのアイテムを正しい場所に置くことができていたら
        if(answerCount == item_list.Count-1)
        {
            StartCoroutine("Clear");
        }
    }

    /// <summary>
    /// 初期化メソッド
    /// </summary>
    private void Initialization()
    {
        gameClearObj.SetActive(false);
        Player.GetComponent<Player>().CanMove = false;
        menuControl = GameObject.Find("MenuController").GetComponent<MenuControl>();
        playTimeText = TimerObj.GetComponent<Text>();
        menuFrag = false;
        MenuSceneObj.SetActive(false);

        timerActive = false;
        playTime = 0;

        Object_list.AddRange(GameObject.FindGameObjectsWithTag(ItemSample.tag));
        foreach(GameObject obj in Object_list)
        {
            item_list.Add(obj.GetComponent<Item>());
        }

        AllAnswerCountObj.GetComponent<Text>().text = (item_list.Count - 1).ToString();
    }


    /// <summary>
    /// 時間の加算表示
    /// </summary>
    private void TimerCount()
    {
        if (timerActive)
        {
            
            timeSeconds += Time.deltaTime;
           
            if (timeSeconds > 60)
            {
                timeSeconds = 0;
                timeMinute += 1;
            }

            if (timeMinute > 10)
            {
                timeMinute = 0;
                timeMinute10 += 1;
            }

            playTimeText.text = timeMinute10 + timeMinute + ":" + timeSeconds.ToString("F0");
        }
    }

    /// <summary>
    /// クリアしたときの処理
    /// </summary>
    private IEnumerator Clear()
    {
        timerActive = false;
        Player.GetComponent<Player>().CanMove = false;

        GameStatus gameStatus = GameObject.Find("GameStatusObj").GetComponent<GameStatus>();

        gameStatus.TimeSec = timeSeconds;
        gameStatus.TimeMinu = timeMinute;
        gameStatus.TimeMinu10 = timeMinute10;

        gameClearObj.SetActive(true);

        AudioManager.Instance.FadeOutBGM(1f);

        AudioManager.Instance.ChangeVolumeSe(0.1f);

        AudioManager.Instance.PlaySE(gameClearSeName);

        yield return new WaitForSeconds(4.0f);

        AudioManager.Instance.ChangeVolumeSe(1f);
        AudioManager.Instance.PlaySE(gameClearBoiceSeName);

        yield return new WaitForSeconds(1.5f);

        GameObject.Find("LoadSceneObj").GetComponent<LoadScene>().ResultChange();

    }


    /// <summary>
    /// メニューの表示処理
    /// </summary>
    private void MenuSceneSelect()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (menuFrag == false)
            {
               
                AudioManager.Instance.PlaySE(menuOpenSeName);
                Player.GetComponent<Player>().CanMove = false;
                menuControl.MenuModeFrag = true;
                MenuSceneObj.SetActive(true);
                menuFrag = true;
            }
            else if (menuFrag)
            {
               
                AudioManager.Instance.PlaySE(menuCloseSeName);
                Player.GetComponent<Player>().CanMove = true;
                menuControl.MenuModeFrag = false;
                MenuSceneObj.SetActive(false);
                menuFrag = false;
            }
        }
    }
}
