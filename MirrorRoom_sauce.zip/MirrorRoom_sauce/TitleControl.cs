﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleControl : MonoBehaviour {

    [SerializeField]
    private string bgmName;
    [SerializeField]
    private string seName;

    private void Start()
    {
        AudioManager.Instance.ChangeVolume(0.5f, 1f);
        AudioManager.Instance.PlayBGM(bgmName);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            AudioManager.Instance.PlaySE(seName);
            LoadScene.Instance.KeyConChange();
        }
    }

}
