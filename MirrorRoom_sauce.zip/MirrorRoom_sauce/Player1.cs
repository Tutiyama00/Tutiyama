﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player1 : MonoBehaviour {

    [SerializeField]
    private bool upButton;
    [SerializeField]
    private bool downButton;
    [SerializeField]
    private bool leftButton;
    [SerializeField]
    private bool rightButton;
    [SerializeField]
    private bool flyButton;
    [SerializeField]
    private bool upButtonUp;
    [SerializeField]
    private bool downButtonUp;
    [SerializeField]
    private bool leftButtonUp;
    [SerializeField]
    private bool rightButtonUp;
    [SerializeField]
    private bool flyButtonUp;

    [SerializeField]
    private GameObject gameController;

    //private bool upButton;   
    //private bool downButton;
    //private bool leftButton;
    //private bool rightButton;
    //private bool flyButton;
    //private bool upButtonUp;
    //private bool downButtonUp;
    //private bool leftButtonUp;
    //private bool rightButtonUp;
    //private bool flyButtonUp;
    private bool flyfrag;

    [SerializeField]
    private bool holdItem = false;  //アイテムを持っているか？

    private Vector3 moveDirection;

    private Transform holdPosition;
    private GameObject Item;    //取得したアイテムの保存変数
    private Rigidbody _rigidbody;

    [SerializeField]
    private float Speed;

    private float x;
    [SerializeField]
    private float y;
    private float z;
    private float inputHorizontal;
    private float inputVertical;

    public bool CanMove = false;

    private void Start()
    {
        holdPosition = GameObject.Find("HoldPosition").transform;

        //このオブジェクトのrigidbodyの取得
        _rigidbody = GetComponent<Rigidbody>();
        flyfrag = false;
    }
    private void Update()
    {
        inputHorizontal = Input.GetAxisRaw("Horizontal");
        inputVertical = Input.GetAxisRaw("Vertical");
        InputGetKey();  //キー入力を変数に保存
        IsGroundRay();  //設置判定
        GetKeyButton(); //入力に対応した挙動を設定
        ForwardRay();   //前方に存在するアイテムの取得

        //取得したアイテムをプレイヤーの前に持ってくる
        if (Item != null && holdItem)
        {
            Item.transform.localPosition = holdPosition.position;
        }

    }

    void FixedUpdate()
    {
        if (CanMove)
        {
            // カメラの方向から、X-Z平面の単位ベクトルを取得
            Vector3 cameraForward = Vector3.Scale(Camera.main.transform.forward, new Vector3(1, 0, 1)).normalized;

            // 方向キーの入力値とカメラの向きから、移動方向を決定
            Vector3 moveForward = cameraForward * inputVertical + Camera.main.transform.right * inputHorizontal;

            // 移動方向にスピードを掛ける。ジャンプや落下がある場合は、別途Y軸方向の速度ベクトルを足す。
            _rigidbody.velocity = moveForward * Speed + new Vector3(0, _rigidbody.velocity.y, 0);

            // キャラクターの向きを進行方向に
            if (moveForward != Vector3.zero)
            {
                transform.rotation = Quaternion.LookRotation(moveForward);
            }
        }
    }

    private void InputGetKey()
    {
        if (CanMove)
        {
            upButton = Input.GetKey("w");
            downButton = Input.GetKey("s");
            leftButton = Input.GetKey("a");
            rightButton = Input.GetKey("d");
            flyButton = Input.GetKey("space");
            upButtonUp = Input.GetKeyUp("w");
            downButtonUp = Input.GetKeyUp("s");
            leftButtonUp = Input.GetKeyUp("a");
            rightButtonUp = Input.GetKeyUp("d");
        }
        else if (CanMove == false)
        {


            upButton = false;
            downButton = false;
            leftButton = false;
            rightButton = false;
            flyButton = false;
            upButtonUp = false;
            downButtonUp = false;
            leftButtonUp = false;
            rightButtonUp = false;
        }
        
    }

    private void GetKeyButton()
    {
        //キーを押している間velocityの変更
        if (upButton)
        {
            z = Input.GetAxis("Vertical");
            _rigidbody.velocity += new Vector3(0, 0, z * Speed);
        }

        if (downButton)
        {
            z = Input.GetAxis("Vertical");
            _rigidbody.velocity += new Vector3(0, 0, z * Speed);
        }

        if (leftButton)
        {
            x = Input.GetAxis("Horizontal");
            _rigidbody.velocity += new Vector3(x * Speed, 0, 0);
        }

        if (rightButton)
        {
            x = Input.GetAxis("Horizontal");
            _rigidbody.velocity += new Vector3(x * Speed, 0, 0);
        }

        if (flyButton)
        {
            if (flyfrag == false)
            {
                flyfrag = true;
                y = Input.GetAxis("Jump");
                _rigidbody.velocity = new Vector3(0, y * 9.81f, 0);
            }
        }


        //キーを上げたときvelocityの値を0にする
        if (upButtonUp)
        {
            _rigidbody.velocity = new Vector3(0, 0, 0);
        }

        if (downButtonUp)
        {
            _rigidbody.velocity = new Vector3(0, 0, 0);
        }

        if (leftButtonUp)
        {
            _rigidbody.velocity = new Vector3(0, 0, 0);
        }

        if (rightButtonUp)
        {
            _rigidbody.velocity = new Vector3(0, 0, 0);
        }
    }

    /// <summary>
    /// 設置判定
    /// </summary>
    private void IsGroundRay()
    {
        Ray ray = new Ray(transform.position, Vector3.down);
        RaycastHit hit;

        Debug.DrawRay(ray.origin, ray.direction * 5.0f, Color.red, 0.5f, false);

        if (Physics.Raycast(ray, out hit, 0.2f))
        {
            //地面に設置していればflyflagをfalseに設定し、飛べるようにする
            if (hit.transform.tag == "Ground")
            {
                flyfrag = false;
            }

            if (hit.transform.tag == "Item")
            {
                flyfrag = false;
            }
        }
    }

    private void ForwardRay()
    {
        

        //プレイヤーの前方にRayを飛ばす
        Ray ray = new Ray(new Vector3(transform.position.x,transform.position.y+0.25f,transform.position.z), transform.forward);
        RaycastHit hit;

        Debug.DrawRay(ray.origin, ray.direction * 5.0f, Color.red, 0.5f, false);

        //RayにObjectが当たったら
        if (Physics.Raycast(ray, out hit, 0.8f))
        {

            Item = hit.transform.gameObject;

            //TagがItemだったら
            if (hit.transform.gameObject.tag == "Item")
            {
                //アイテムを取得していない場合return
                if (Item == null)
                {
                    return;
                }

                //アイテムを取得し、かつEnterキーが押された場合
                if (Input.GetKeyDown(KeyCode.KeypadEnter) && !holdItem)
                {
                  
                    //持っている判定
                    holdItem = true;
                    hit.collider.isTrigger = true;
                }
                else if (Input.GetKeyDown(KeyCode.KeypadEnter) && holdItem)
                {

                    hit.collider.isTrigger = false;

                    Item.GetComponent<Item>().Judge();
                    gameController.GetComponent<GameControl>().AllJudge();

                    //何も持っていない判定
                    Item = null;
                    holdItem = false;


                }
            }
            
            
        }
    }
}
