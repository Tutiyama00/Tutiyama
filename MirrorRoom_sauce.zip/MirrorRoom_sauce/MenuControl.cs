﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuControl : MonoBehaviour {

    [SerializeField]
    private GameObject cursor;
    [SerializeField]
    private Vector3 cursorPosition1;
    [SerializeField]
    private Vector3 cursorPosition2;

    [SerializeField]
    private string cursorSeName;
    [SerializeField]
    private string okSeName;
    [SerializeField]
    private GameObject button1, button2;

    public bool MenuModeFrag;

    private LoadScene loadScene;

    private int cursorNamber;

    private Image buttonImage1, buttonImage2;

    //-----------------------------------------------
    private void Awake()
    {
        Initialization();
    }

    private void Update()
    {
        if (MenuModeFrag)
        {
            if (Input.GetKeyDown(KeyCode.W) && cursorNamber > 1)
            {
                buttonImage2.color = Color.white;
                buttonImage1.color = Color.yellow;

                //button1.GetComponent<Image>().color = Color.yellow;
                // button2.GetComponent<Image>().color = Color.white;

                AudioManager.Instance.PlaySE(cursorSeName);
                cursorNamber -= 1;
                //cursor.transform.position = cursorPosition1;
            }

            if(Input.GetKeyDown(KeyCode.S) && cursorNamber < 2)
            {
                buttonImage1.color = Color.white;
                buttonImage2.color = Color.yellow;

                //button2.GetComponent<Image>().color = Color.yellow;
                //button1.GetComponent<Image>().color = Color.white;

                AudioManager.Instance.PlaySE(cursorSeName);
                cursorNamber += 1;
                //cursor.transform.position = cursorPosition2;
            }

            if (Input.GetKeyDown(KeyCode.Return))
            {
                AudioManager.Instance.PlaySE(okSeName);

                switch (cursorNamber)
                {
                    case 1:
                        ReStart();
                        break;

                    case 2:
                        TitleSceneSelect();
                        break;
                }
            }
        }
    }

    //-----------------------------------------------


    private void ReStart()
    {
        AudioManager.Instance.FadeOutBGM(1f);
        loadScene.ManiChange();
    }

    private void TitleSceneSelect()
    {
        AudioManager.Instance.FadeOutBGM(1f);
        loadScene.TitleChange();
    }

    private void Initialization()
    {
        buttonImage1 = button1.GetComponent<Image>();
        buttonImage2 = button2.GetComponent<Image>();

        buttonImage1.color = Color.yellow;

        loadScene = GameObject.Find("LoadSceneObj").GetComponent<LoadScene>();
        MenuModeFrag = false;
        //cursor.transform.position = cursorPosition1;
        cursorNamber = 1;
    }
}
