﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    private float time = 0;

    private int M = 0;

    private int M10 = 0;

    private Text text;

    private bool timerStop = true;

    private bool C = true;

    void Start ()
    {
        text = GetComponent<Text>();
	}

    void TimerReset()
    {
        time = 0;
        timerStop = true;
    }
	
	
	void Update ()
    {
        if (timerStop)
        {
            time += Time.deltaTime;
            text.text = "Time "+ M10 + M +":"+ time.ToString("F0");
        }

        if(time >= 60)
        {
            time = 0;
            M += 1;
        }

        if (M >= 10)
        {
            M = 0;
            M10 += 1;
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            if (C)
            {
                timerStop = false;
                C = false;
            }
            else
            {
                timerStop = true;
                C = true;
            }

        }

    }

}
