﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UserName : MonoBehaviour {

    private string USER_NAME;

    public string Username { get {return USER_NAME;}
                             set { USER_NAME = value; } }

    void Start()
    {
        DontDestroyOnLoad(this);
    }
}
