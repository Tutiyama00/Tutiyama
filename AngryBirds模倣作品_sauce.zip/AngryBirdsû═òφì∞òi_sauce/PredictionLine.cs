﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PredictionLine : MonoBehaviour
{

    [SerializeField]
    GameObject predictionLineCopy,           //predictionLineのCopy用のオブジェクトを入れる
        　　　 CenterPoint;                         //CenterPointを入れる
    private BirdFiring2 　　 birdFiring2;    //BirdFiring2スクリプトの入れ物　　
    private List<GameObject> predictionLineList = new List<GameObject>(); //predictionLineのList
    private float  xPos, 
                   yPos,
                   zPos,
                   t;
    public  float  secInterval,　　　　　　　//弾道予測線の点の間隔
                　 correctionValue;          //弾道予測線の調整値
    public int  　 CopyAmount;               //コピー数
    public Vector3 v0;


    private void Awake()
    {
        for(int cnt = 1 ; cnt <= CopyAmount ; cnt++) //predictionLineCopyをCopyAmountの数分Instantiateしている
        {
            GameObject obj = Instantiate(predictionLineCopy); 
            predictionLineList.Add(obj);           
        }

        for (int cnt = 0; cnt < predictionLineList.Count; cnt++)　//predictionLineListをこのオブジェクトの子にする
        {
            predictionLineList[cnt].transform.parent = CenterPoint.transform;
        }

        birdFiring2 = this.GetComponent<BirdFiring2>();　　　//BirdFiring2をインスタンス化

    }


    public void PredictionLineUse()
    {
        
        for (int i = 0; i < predictionLineList.Count; i++)
        {
           v0   = birdFiring2.firingDirectionEnd;  //Birdの弾道を取得
            t   = i * secInterval;　　　　　　　　 //点と点の間隔をとっている
           xPos = t * v0.x;                        //点のｘ座標を計算

           yPos = (v0.y * t) - 0.5f * (-Physics.gravity.y + correctionValue) * Mathf.Pow(t, 2.0f);  //点のｙ座標を計算（鉛直投げ上げ）

            predictionLineList[i].SetActive(true);
           predictionLineList[i].transform.position = new Vector3(CenterPoint.transform.position.x + xPos, CenterPoint.transform.position.y + yPos);  //点に座標を代入

        }
    }

    private void PredictionLineFalse()　//PredictionLineを消す処理　
    {
        for(int i = 0; i < predictionLineList.Count; i++)
        {
            predictionLineList[i].SetActive(false);
        }
    }


    private void OnMouseDrag()
    {
        if (birdFiring2.firingCheck == false)
        {
            if (birdFiring2.predictionLineCheck)
            {
                PredictionLineUse();    //ドラッグしているときにPredictionLineを表示
            }
            else
            {
                PredictionLineFalse();
            }
        }
    }


}
