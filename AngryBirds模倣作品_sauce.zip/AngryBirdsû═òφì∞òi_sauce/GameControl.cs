﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameControl : MonoBehaviour {

    [SerializeField]
    GameObject enemy,
               block,
               bird,
               scoreControlobj,
               angryBirdsScene;
    [SerializeField]
    TextMeshProUGUI rabbitNamber,
                    scoreNamber,
                    highScoreNamber;
    [SerializeField]
    AudioClip BGM;

    public bool clearCheck;
    public bool changeBird;
    private BirdFiring2 birdFiring2;
    public int RemainingBird;
    private GameObject USER_NAME;
    private int hightScore;
    private bool SceneAddCheck = false;
    private HighScore highScore;
    private bool saveCheck = false;
    private MusicControlScr musicControlScr;
    private bool dontGameOverfag = false;

    void Start()
    {
        Time.timeScale = 1.5f;

        MusicControlScr1.MusicControl_Singleton.SetPlayBGM(BGM, 1.0f);

        //musicControlScr = GameObject.FindGameObjectWithTag("MusicControl").GetComponent<MusicControlScr>();
        //musicControlScr.SetPlayBGM(BGM, 1.0f);

        birdFiring2 = bird.GetComponent<BirdFiring2>();
        USER_NAME = GameObject.Find("UserName");
        
        clearCheck = false;
        changeBird = false;

        rabbitNamber.text = RemainingBird.ToString(); //birdの残機を表示
        highScore = new HighScore(USER_NAME.GetComponent<UserName>().Username);
    }

    void Update()
    {
        //ゲームクリアー処理
        if (clearCheck)
        {
            dontGameOverfag = true;

            if (SleepingCheck())
            {
                clearCheck = false;
                hightScore = int.Parse(highScoreNamber.text);
                SceneAddCheck = true;

                if (hightScore > scoreControlobj.GetComponent<ScoreControl>().firstHightScore)
                {
                    highScore.save(float.Parse(scoreNamber.text));
                    saveCheck = true;
                }
            }
        }

        if (SceneAddCheck)
        {
            if (saveCheck)
            {
                if (highScore.saveFrag)
                {
                    highScore.saveFrag = false;
                    SceneAddCheck = false;
                    angryBirdsScene.SetActive(false);
                    SceneManager.LoadScene("Game clear", LoadSceneMode.Additive);
                }
            }
            else
            {
                SceneAddCheck = false;
                angryBirdsScene.SetActive(false);
                SceneManager.LoadScene("Game clear", LoadSceneMode.Additive);
            }
        }
        


        //Birdを元に戻す処理
        if (changeBird && clearCheck == false && dontGameOverfag == false)
        {
            if (SleepingCheck())
            {
                if(RemainingBird > 0)
                {
                    RemainingBird -= 1;
                    rabbitNamber.text = RemainingBird.ToString();
                }
                else
                {
                    angryBirdsScene.SetActive(false);
                    SceneManager.LoadScene("Game over",LoadSceneMode.Additive);
                }

                birdFiring2.SetUp();

                changeBird = false;
            }
        }


       
    }

    /// <summary>
    /// 全てのオブジェクトの動きが止まったかの判定
    /// </summary>
    /// <returns>止まったらtrueで返す</returns>
    private bool SleepingCheck()
    {
        bool sleeping = false;

        List<GameObject> objectList = new List<GameObject>();
        objectList.AddRange(GameObject.FindGameObjectsWithTag("Enemy"));
        objectList.AddRange(GameObject.FindGameObjectsWithTag("block"));
        objectList.AddRange(GameObject.FindGameObjectsWithTag("Bird"));

        for (int i = 0; objectList.Count > i; i++)
        {
            if (objectList[i].GetComponent<Rigidbody>().IsSleeping() == false)
            {
                return sleeping;
            }
        }

        sleeping = true;
        return sleeping;
    }

    

}
