﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseDrag : MonoBehaviour {

    private Vector3     mousePositionInScreen, //マウスのポジションを格納する変数
                        mousePositionInWorld,  //ワールド座標になったマウスのポジションを格納する変数
                        activityRangeVector3;  //移動範囲上限でちゃんと守っている場合の座標
    public  float       ACTIVITY_RANGE;        //このオブジェクトが移動できる範囲
    private BirdFiring2 birdFiring2;
    public  bool        dragNaw;

    private void Awake()
    {
        birdFiring2 = GetComponent<BirdFiring2>();  //birdFiring2をインスタンス化
    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            dragNaw = false;
        }
    }

    private void OnMouseDrag()
    {
        if (birdFiring2.firingCheck == false)
        {
            dragNaw = true;

            mousePositionInScreen = Input.mousePosition;                                      //マウスのポジションを取得                                                                   
            mousePositionInScreen.z = -Camera.main.transform.position.z;                      //すまんここが謎、なんでマイナスつけてんの？後で調べてくれ
            mousePositionInWorld = Camera.main.ScreenToWorldPoint(mousePositionInScreen);     //マウスのポジションをスクリーン座標からワールド座標に変換

            this.transform.position = mousePositionInWorld;                                   //ワールド座標のマウスのポイントをこのスクリプトを入れているオブジェクトに入れている

            activityRangeVector3 = this.transform.localPosition.normalized * ACTIVITY_RANGE;  //移動範囲を設定

            if (this.transform.localPosition.magnitude >= activityRangeVector3.magnitude)     //移動範囲を出たら移動制限をかける
            {
                this.transform.localPosition = activityRangeVector3;
            }

        }

       
    }
}
