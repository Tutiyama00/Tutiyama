﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicControlScr1 : MonoBehaviour {

    //----------シングルトン---------------
    private static MusicControlScr1 musicControl_Singleton;

    public static MusicControlScr1 MusicControl_Singleton
    {
        get
        {
            if(musicControl_Singleton == null)
            {
                musicControl_Singleton = FindObjectOfType<MusicControlScr1>();
            }

            return musicControl_Singleton;
        }
    }

    private void Awake()
    {
        if(MusicControl_Singleton != this)
        {
            Destroy(gameObject);
        }

        audioSource = this.GetComponent<AudioSource>();
    }


    //----------コンポーネント------------
    private AudioSource audioSource;

    //----------定数定義------------------
    [SerializeField]
    private float DECREASE_POINT = 0.0f;
    private bool fadeOutFrag = false;

    void Start()
    {
        DontDestroyOnLoad(this);

        //audioSource = this.GetComponent<AudioSource>();
    }

    /// <summary>
    /// BGMをLOOPして流します。
    /// </summary>
    /// <param name="audioClip">流したいBGMを指定してください。</param>
    /// <param name="audioVolume">BGMの音量を指定してください。</param>
    public void SetPlayBGM(AudioClip audioClip, float audioVolume)
    {
        audioSource.clip = audioClip;
        audioSource.loop = true;
        audioSource.volume = audioVolume;
        audioSource.Play();
    }


    /// <summary>
    /// 一度だけaudioClipを流します。
    /// </summary>
    /// <param name="audioClip"></param>
    /// <param name="audioVolume"></param>
    public void MusicOneShotPlay(AudioClip audioClip, float audioVolume)
    {
        audioSource.volume = audioVolume;
        audioSource.PlayOneShot(audioClip);
    }


    /// <summary>
    /// 流れているaudioClipをフェードアウトさせます。
    /// </summary>
    /// <param name="fadeOutTime">フェードアウトの秒数</param>
    public void MusicFadeOut(float fadeOutTime)
    {
        DECREASE_POINT = fadeOutTime;
        fadeOutFrag = true;
    }


    private void Update()
    {
        if (fadeOutFrag)
        {
            if (audioSource.volume > 0.0f)
            {
                audioSource.volume -= Time.deltaTime / DECREASE_POINT;
            }
            else
            {
                fadeOutFrag = false;
            }
        }
    }
}
