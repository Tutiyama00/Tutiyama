﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameClearControl : MonoBehaviour {

    [SerializeField]
    AudioClip BGM;

    private GameObject USER_NAME;
    private HighScore highScoreScr;
    private Ranking ranking;
    private int HIGH_SCORE;
    private bool highScoreGetCheck = false,
                 rankGetCheck = false,
                 rankingGetCheck = false;
    private List<GameObject> RivalsNameList = new List<GameObject>();
    private List<GameObject> Top5NameList = new List<GameObject>();
    private List<GameObject> RivalsScoreList = new List<GameObject>();
    private List<GameObject> Top5ScoreList = new List<GameObject>();
    private List<GameObject> RivalsNamberList = new List<GameObject>();

    private void Start()
    {
        MusicControlScr1.MusicControl_Singleton.SetPlayBGM(BGM, 1.0f);
        
        for(int i = 1; 5 >= i; i++)
        {
            RivalsNameList.Add(GameObject.Find("RivalsName" + i));
            RivalsScoreList.Add(GameObject.Find("RivalsScore" + i));
            Top5NameList.Add(GameObject.Find("Top5Name" + i));
            Top5ScoreList.Add(GameObject.Find("Top5Score" + i));
            RivalsNamberList.Add(GameObject.Find("Rival" + i));

        }

        USER_NAME = GameObject.Find("UserName");
        highScoreScr = new HighScore(USER_NAME.GetComponent<UserName>().Username);
        ranking = new Ranking();
        highScoreScr.Get();
        ranking.Top5RankingGet();
    }

    private void Update()
    {
        //RankingGetができたら通る
        if (ranking.rankingGetCheck)
        {
            ranking.rankingGetCheck = false;
            rankingGetCheck = true;
        }


        //HighScoreGetができたら通る
        if (highScoreScr.Getfrag)
        {
            HIGH_SCORE = highScoreScr.Score1;
            ranking.RankGet(HIGH_SCORE);
            highScoreScr.Getfrag = false;
            highScoreGetCheck = true;
        }

        //RankGetができたら通る
        if (highScoreGetCheck && ranking.rankGetCheck)
        {
            ranking.rankGetCheck = false;
            ranking.RivalsGet();
            rankGetCheck = true;
        }

        //RivalsGet、RankingGetができたら通る
        if (ranking.rivalsGetCheck && rankingGetCheck)
        {
            int rivalsNameCount = ranking.RivalsName.Count;
            int rivalsScoreCount = ranking.RivalsScore.Count;
            int top5NameCount = ranking.Top5Name.Count;
            int top5ScoreCount = ranking.Top5Score.Count;
                 
            ranking.rivalsGetCheck = false;

            for(int i = 0;rivalsNameCount > i; i++)
            {
                RivalsNameList[i].GetComponent<TextMeshProUGUI>().text = ranking.RivalsName[i];
            }

           for(int i = 0;rivalsScoreCount > i; i++)
            {
                RivalsScoreList[i].GetComponent<TextMeshProUGUI>().text = ranking.RivalsScore[i].ToString();
            }

            for (int i = 0; top5NameCount > i; i++)
            {
                Top5NameList[i].GetComponent<TextMeshProUGUI>().text = ranking.Top5Name[i];
            }

            for (int i = 0; top5ScoreCount > i; i++)
            {
                Top5ScoreList[i].GetComponent<TextMeshProUGUI>().text = ranking.Top5Score[i].ToString();
            }

            for(int i = 0;rivalsNameCount > i; i++)
            {
                int namber = 0;

                switch (ranking.YOUR_RANK)
                {
                    case 1:
                    case 2:
                        namber = 1 + i;
                        break;
                    default:
                        namber = ranking.YOUR_RANK - 2 + i;
                        break;


                }

                RivalsNamberList[i].GetComponent<TextMeshProUGUI>().text = namber.ToString();
            }

        }

    }


    public void TitleSceneChenge()
    {
        SceneManager.UnloadSceneAsync("angrybirds");
        SceneManager.UnloadSceneAsync("Title");
        //SceneManager.UnloadSceneAsync("opening");
        SceneManager.LoadScene("Title"/*,LoadSceneMode.Additive*/);
        //SceneManager.UnloadSceneAsync("Game clear");

    }

}
