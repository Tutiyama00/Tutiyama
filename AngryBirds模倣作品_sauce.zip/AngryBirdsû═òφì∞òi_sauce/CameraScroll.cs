﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScroll : MonoBehaviour {

    [SerializeField]
    GameObject bird;
    private Vector3 mousePositionInScreen, //マウスのポジションを格納する変数
                       mousePositionInWorld,  //ワールド座標になったマウスのポジションを格納する変数
                     directionOfMovement;
    private float mouseScrollWheel,
                  amountOfMovement;
    public float movePointNear,
                 movePointAway;
    private MouseDrag mouseDrag;
    private Rigidbody thisGameObjectRigidbody;
    private Vector3 MAX_DEPTH;
    private Vector3 depthDirection;

    void Start()
    {
        MAX_DEPTH = new Vector3(176f, 68f, -210f);
        mouseDrag = bird.GetComponent<MouseDrag>();
        thisGameObjectRigidbody = this.GetComponent<Rigidbody>();
    }
    void Update()
    {
        mouseScrollWheel = Input.GetAxis("Mouse ScrollWheel");

        if (mouseScrollWheel != 0f || Input.GetMouseButton(0) && mouseDrag.dragNaw == false)
        {

            if (mouseScrollWheel < 0f)
            {
                depthDirection = (transform.position - MAX_DEPTH) * mouseScrollWheel * movePointNear;
                thisGameObjectRigidbody.velocity = depthDirection;

            }

            if(mouseScrollWheel > 0f && transform.position.z < -60)
            {
                thisGameObjectRigidbody.velocity = new Vector3(0, 0, mouseScrollWheel * movePointAway);
            }

            if (Input.GetMouseButton(0))
            {
                mousePositionInScreen = Input.mousePosition;                                      //マウスのポジションを取得                                                                   
                mousePositionInScreen.z = -Camera.main.transform.position.z;                      //すまんここが謎、なんでマイナスつけてんの？後で調べてくれ
                mousePositionInWorld = Camera.main.ScreenToWorldPoint(mousePositionInScreen);     //マウスのポジションをスクリーン座標からワールド座標に変換

                directionOfMovement = mousePositionInWorld - transform.position;
                thisGameObjectRigidbody.velocity = new Vector3(directionOfMovement.x, directionOfMovement.y, 0f);
                
            }

        }
        else
        {
            thisGameObjectRigidbody.velocity = new Vector3(0, 0, 0);
        }
    }

}
