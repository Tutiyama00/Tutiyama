﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour {

    [SerializeField]
    GameObject bird,  　　　　　　　　　　　　//birdを入れる
               ScoreCtl,
               effect;
    private Rigidbody collisionRiridbody;　　//blockにぶつかったオブジェクトのRiridbody
    private float collisionPower;　　　　　　//衝突した力
    public float destructionBlock;　　　　　　//耐久力
    private GameObject effectGameObject;
    private void Start()
    {
        effectGameObject = Instantiate(effect);
        effectGameObject.SetActive(false);
    }
    private void OnCollisionEnter(Collision collision)
    {
         if(collision.gameObject.tag != bird.tag)
        {
            CollisionPowerCalculation(collision.gameObject);
        }
      
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.tag == bird.tag)
        {
            CollisionPowerCalculation(collider.gameObject);
        }
    }

    private void CollisionPowerCalculation(GameObject collision2)
    {
        collisionRiridbody = collision2.gameObject.GetComponent<Rigidbody>();    //ぶつかったオブジェクトのRiridbodyを取得

        if (collision2.tag == bird.tag)
        {
            collisionPower = Mathf.Pow(Mathf.Pow(collisionRiridbody.velocity.x, 2) + Mathf.Pow(collisionRiridbody.velocity.y, 2), 0.5f) * collisionRiridbody.mass; //衝突力の計算
        }
        else
        {
            collisionPower = Mathf.Pow(Mathf.Pow(collisionRiridbody.velocity.x, 2) + Mathf.Pow(collisionRiridbody.velocity.y, 2), 0.5f) * (collisionRiridbody.mass / 2); //衝突力の計算
        }
        if (collisionPower > destructionBlock)  //衝突力が耐久力を上回っていたらブロックをfalseに、いなければ耐久力　―　衝突力する
        {
            if(collision2.tag == bird.tag)
            {
                collisionRiridbody.AddForce(collisionRiridbody.velocity*-500);
            }

            effectGameObject.transform.position = transform.position;
            effectGameObject.SetActive(true);
            ScoreCtl.GetComponent<ScoreControl>().AddScore(destructionBlock);
            this.gameObject.SetActive(false);
        }
        else
        {
            destructionBlock = destructionBlock - collisionPower;
        }
    }
}
