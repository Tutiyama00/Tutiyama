﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverControl : MonoBehaviour {

    [SerializeField]
    AudioClip BGM;
  
    private void Start()
    {
        MusicControlScr1.MusicControl_Singleton.SetPlayBGM(BGM, 1.0f);
    }

	public void TitleSceneChenge()
    {
        SceneManager.UnloadSceneAsync("angrybirds");
        SceneManager.UnloadSceneAsync("Title");
        //SceneManager.UnloadSceneAsync("opening");
        SceneManager.LoadScene("Title"/*,LoadSceneMode.Additive*/);
       // SceneManager.UnloadSceneAsync("Game over");
    }

}
