﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameObjectPool {

    private List<GameObject> GameObjectPoolList = new List<GameObject>(); //ObjectPoolに渡すリスト


    public int ObjectPool(List<GameObject> GameObjectList)
    {
        int objectCount = 0;       //使われていないオブジェクトを発見した時のListの配列番号

        foreach (GameObject Object in GameObjectList)
        {
            if (Object.GetComponent<Renderer>().enabled == false)
            {
                break;            //見つかったら文抜ける
            }

            objectCount++; 　　　 //カウントを増やす

        }

        return objectCount;  //見つけた配列番号をかえしている(見つからなかったら配列数+1が返ってくる)
     
    }
}
