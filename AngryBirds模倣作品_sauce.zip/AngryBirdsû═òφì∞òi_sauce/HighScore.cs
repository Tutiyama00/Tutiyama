﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NCMB;
using TMPro;

public class HighScore {

    public TextMeshProUGUI hihgScoreText;
    private int score1;
    private string name;
    private bool getfrag = false;
    public bool saveFrag = false;
    public bool Getfrag
    {
        get
        {
            return getfrag;
        }

        set
        {
            getfrag = value;
        }
    }
    
    public int Score1
    {
        get
        {
            return score1;
        }

        set
        {
            score1 = value;
        }
    }

    public HighScore(string _name)
    {
        name = _name;
    }

    public void save(float score)
    {
        NCMBQuery<NCMBObject> query = new NCMBQuery<NCMBObject>("HighScore");
        query.WhereEqualTo("Name", name);
        query.FindAsync((List<NCMBObject> objList,NCMBException e) =>
        {
            if (e == null)
            {
                objList[0]["Score"] = score;
                objList[0].SaveAsync((NCMBException e1) =>
                {
                    if(e1 == null)
                    {
                        saveFrag = true;
                    }
                });
                
            }
        });
    }


    public void Get()
    {
        NCMBQuery<NCMBObject> query = new NCMBQuery<NCMBObject>("HighScore");
        query.WhereEqualTo("Name", name);
        query.FindAsync((List<NCMBObject> objList, NCMBException e) =>
        {
            if(e == null)
            {
                if(objList.Count == 0)
                {
                    NCMBObject obj = new NCMBObject("HighScore");
                    obj["Name"] = name;
                    obj["Score"] = 0f;
                    obj.SaveAsync();
                }
                else
                {
                    Getfrag = true;
                    Score1 = System.Convert.ToInt32(objList[0]["Score"]);
                }
            }

           
        });

    }
}
