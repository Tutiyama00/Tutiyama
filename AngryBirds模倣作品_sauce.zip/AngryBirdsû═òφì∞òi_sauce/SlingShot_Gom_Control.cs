﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlingShot_Gom_Control : MonoBehaviour {

    [SerializeField]
    GameObject BIRD;
    [SerializeField]
    float Positiom_x1, Positiom_y1, Positiom_z1, Positiom_x2, Positiom_y2, Positiom_z2;
    private LineRenderer lineRenderer;
    private Vector3 linePosition1, linePosition2;
    public bool lineCheck = true;


    void Start()
    {
        BIRD = GameObject.FindGameObjectWithTag("Bird");
        lineRenderer = this.GetComponent<LineRenderer>();
    }

    void Update()
    {
        if (lineCheck)
        {
            lineRenderer.enabled = true;

            linePosition1 = new Vector3(BIRD.transform.position.x + Positiom_x1, BIRD.transform.position.y + Positiom_y1, BIRD.transform.position.z + Positiom_z1);
            linePosition2 = new Vector3(BIRD.transform.position.x + Positiom_x2, BIRD.transform.position.y + Positiom_y2, BIRD.transform.position.z + Positiom_z2);


            lineRenderer.SetPosition(1, linePosition1);
            lineRenderer.SetPosition(2, linePosition2);
        }
        else
        {
            lineRenderer.enabled = false;
        }
    }
}
