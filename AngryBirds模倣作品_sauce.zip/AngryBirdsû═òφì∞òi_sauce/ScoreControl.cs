﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreControl : MonoBehaviour {

    [SerializeField]
    TextMeshProUGUI scoreNamber,
                    highScoreNamber;
    private float Score = 0;
    private GameObject USER_NAME;
    private string initialText;
    HighScore highScore;
    public int firstHightScore;

    private void Start()
    {
        initialText = highScoreNamber.text;
        USER_NAME = GameObject.Find("UserName");
        highScore = new HighScore(USER_NAME.GetComponent<UserName>().Username);
        highScore.Get();


    }
    void Update()
    {
        if (highScore.Getfrag)
        {
            firstHightScore = highScore.Score1;
            highScoreNamber.text = highScore.Score1.ToString();
            highScore.Getfrag = false;
        }

    }
    

    public void AddScore(float addPoint)
    {
        addPoint = Mathf.Floor(addPoint);
        Score = Score + addPoint;

        if(Score > System.Convert.ToInt32(highScoreNamber.text))
        {
            highScoreNamber.text = Score.ToString();
        }

        scoreNamber.text = Score.ToString(); 
    }
}
