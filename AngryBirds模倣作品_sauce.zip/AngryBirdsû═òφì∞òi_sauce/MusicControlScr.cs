﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicControlScr : MonoBehaviour {

    //アタッチするGameObjectにはAudioSourceをコンポーネントに追加してください。

    private AudioSource audioSource;

    [SerializeField]
    float FadeOutPoint = 1.0f;
    private bool fadeOutFrag = false;
    private float DECREASE_POINT;

    // Use this for initialization
    void Start () {

        DontDestroyOnLoad(this);

	}

    /// <summary>
    /// BGMをLOOPして流します。
    /// </summary>
    /// <param name="audioClip">流したいBGMを指定してください。</param>
    /// <param name="audioVolume">BGMの音量を指定してください。</param>
    public void SetPlayBGM(AudioClip audioClip,float audioVolume)
    {
        audioSource = GameObject.FindGameObjectWithTag("MusicControl").GetComponent<AudioSource>();

        audioSource.clip = audioClip;
        audioSource.loop = true;
        audioSource.volume = audioVolume;
        audioSource.Play();
    }


    /// <summary>
    /// 一度だけaudioClipを流します。
    /// </summary>
    /// <param name="audioClip"></param>
    /// <param name="audioVolume"></param>
    public void MusicOneShotPlay(AudioClip audioClip,float audioVolume)
    {
        audioSource = GameObject.FindGameObjectWithTag("MusicControl").GetComponent<AudioSource>();

        audioSource.volume = audioVolume;
        audioSource.PlayOneShot(audioClip);
    }


    /// <summary>
    /// 流れているaudioClipをフェードアウトさせます。
    /// </summary>
    /// <param name="fadeOutTime">フェードアウトの秒数</param>
    public void MusicFadeOut(float fadeOutTime)
    {
        DECREASE_POINT = fadeOutTime;
        fadeOutFrag = true;
    }

   
    private void Update()
    {
        if (fadeOutFrag)
        {
            if (audioSource.volume > 0.0f)
            {
                audioSource.volume -= Time.deltaTime / DECREASE_POINT;
            }
            else
            {
                fadeOutFrag = false;
            }
        }

        //----------テスト用-----------------------

        //if (Input.GetKeyDown(KeyCode.A))
        //{ 

        //    audioSource.Play();
        //}

        //if (Input.GetKeyDown(KeyCode.B))
        //{
        //    MusicFadeOut(FadeOutPoint);
        //}
    }
}
