﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverRubbitControl : MonoBehaviour {

    [SerializeField]
    GameObject effect;

    public void GameOverRubbitEffect()
    {
        effect.SetActive(true);
        this.gameObject.SetActive(false);
    }


}
