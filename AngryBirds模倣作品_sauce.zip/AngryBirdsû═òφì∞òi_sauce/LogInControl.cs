﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using NCMB;
using UnityEngine.SceneManagement;

public class LogInControl : MonoBehaviour {


    [SerializeField]
    GameObject OpeningScene;
    [SerializeField]
    Canvas  logInCanvas,
            signUpCanvas;
    [SerializeField]
    Text logInText_ID,
        logInText_Password,
        signUpText_ID,
        signUpText_Password,
        signUpText_MailAddress,
        logInError;
    public string userName;

    private void Start()
    {
        logInCanvas.enabled = true;
        signUpCanvas.enabled = false;
    }


    public void LogInToSignUp()
    {
        logInCanvas.enabled = false;
        signUpCanvas.enabled = true;
    }

    public void SignUpToLogIn()
    {
        logInCanvas.enabled = true;
        signUpCanvas.enabled = false;
    }

    public void LogIn()
    {
        NCMBUser.LogInAsync(logInText_ID.text, logInText_Password.text, (NCMBException e) =>
        {

            if (e == null)
            {
                userName = logInText_ID.text;
                GameObject.Find("UserName").GetComponent<UserName>().Username = userName;
                OpeningScene.SetActive(false);
                //SceneManager.LoadScene("UserNameSave", LoadSceneMode.Additive);
                SceneManager.LoadScene("Title"/*, LoadSceneMode.Additive*/);
            }
            else
            {
                logInError.text = "ログインできませんでした。";
            }
        });
    }

    public void SignUp()
    {
        NCMBUser user = new NCMBUser();
        user.UserName = signUpText_ID.text;
        user.Password = signUpText_Password.text;
        user.Email = signUpText_MailAddress.text;
        user.SignUpAsync((NCMBException e) =>
        {
            if(e == null)
            {
                userName = signUpText_ID.text;
                GameObject.Find("UserName").GetComponent<UserName>().Username = userName;
                OpeningScene.SetActive(false);
               // SceneManager.LoadScene("UserNameSave", LoadSceneMode.Additive);
                SceneManager.LoadScene("Title"/*, LoadSceneMode.Additive*/);
            }


        });
        
    }

}
