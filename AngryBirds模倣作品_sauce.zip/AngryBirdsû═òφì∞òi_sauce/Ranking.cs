﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NCMB;

public class Ranking {

    public int YOUR_RANK;
    public bool rankGetCheck = false,
                rankingGetCheck = false,
                rivalsGetCheck = false;
    public List<string> Top5Name = new List<string>();
    public List<int> Top5Score = new List<int>();
    public List<string> RivalsName = new List<string>();
    public List<int> RivalsScore = new List<int>();
  
                
    

    public void RankGet(int highScore)
    {
        Debug.Log(rankGetCheck);

        NCMBQuery<NCMBObject> query = new NCMBQuery<NCMBObject>("HighScore");
        query.WhereGreaterThan("Score", highScore);
        query.CountAsync((int count,NCMBException e)=> 
        {
            if(e == null)
            {
                rankGetCheck = true;
                YOUR_RANK = count + 1;
            }
        });
    }

    public void Top5RankingGet()
    {
        Top5Name = new List<string>();
        Top5Score = new List<int>();

        NCMBQuery<NCMBObject> query = new NCMBQuery<NCMBObject>("HighScore");
        query.OrderByDescending("Score");
        query.Limit = 5;
        query.FindAsync((List<NCMBObject> objList,NCMBException e)=> 
        {
            if (e == null)
            {
                foreach (NCMBObject obj in objList)
                {
                    int highScore = System.Convert.ToInt32(obj["Score"]);
                    string name = System.Convert.ToString(obj["Name"]);

                    Top5Score.Add(highScore);
                    Top5Name.Add(name);
                }

                rankingGetCheck = true;
            }
        });
    }

    public void RivalsGet()
    {
        int skip = YOUR_RANK - 3;

        if(skip < 0)
        {
            skip = 0;
        }

        NCMBQuery<NCMBObject> query = new NCMBQuery<NCMBObject>("HighScore");
        query.OrderByDescending("Score");
        query.Skip = skip;
        query.Limit = 5;
        query.FindAsync((List<NCMBObject> list, NCMBException e)=>
        {
            if(e == null)
            {
                foreach(NCMBObject obj in list)
                {
                    int rivalsScore = System.Convert.ToInt32(obj["Score"]);
                    string rivalsName = System.Convert.ToString(obj["Name"]);

                    RivalsScore.Add(rivalsScore);
                    RivalsName.Add(rivalsName);
                }

                rivalsGetCheck = true;
            }
        });
    }

}
