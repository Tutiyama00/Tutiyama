﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    [SerializeField]
    GameObject bird,              //birdを入れる
              ScoreCtl,
               enemy,
              gameControl,
              effect;
    private Rigidbody collisionRiridbody;　　//blockにぶつかったオブジェクトのRiridbody
    private float collisionPower;　　　　　　//衝突した力
    public float destructionBlock;      //耐久力
    private GameObject effectGameObject;


    private void Start()
    {
        effectGameObject = Instantiate(effect);
        effectGameObject.SetActive(false);
    }


    private void OnCollisionEnter(Collision collision)
    {
        collisionRiridbody = collision.gameObject.GetComponent<Rigidbody>();    //ぶつかったオブジェクトのRiridbodyを取得

        collisionPower = Mathf.Pow(Mathf.Pow(collisionRiridbody.velocity.x, 2) + Mathf.Pow(collisionRiridbody.velocity.y, 2), 0.5f) * collisionRiridbody.mass; //衝突力の計算

        if (collisionPower > destructionBlock)  //衝突力が耐久力を上回っていたらブロックをfalseに、いなければ耐久力　―　衝突力する
        {
            effectGameObject.transform.position = this.transform.position;
            effectGameObject.SetActive(true);
            ScoreCtl.GetComponent<ScoreControl>().AddScore(800);   //破壊されたらスコア加算

            List<GameObject> enemyList = new List<GameObject>();
            enemyList.AddRange(GameObject.FindGameObjectsWithTag(this.tag));　　//ゲームクリア判定

            if(enemyList.Count == 1)
            {
                gameControl.GetComponent<GameControl>().clearCheck = true;
            }
           
            this.gameObject.SetActive(false);
        }
        else
        {
            destructionBlock = destructionBlock - collisionPower;
        }

    }


   
}
