﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdFiring2 : MonoBehaviour
{

    [SerializeField]
    GameObject CenterPoint,　　　　　            //中心点とするオブジェクト
                       GameCtl,
               Gom;
    private Vector3 firingDirection;                  //このオブジェクトが飛ぶ方向
    public Vector3     firingDirectionEnd;   //このオブジェクトが最終的に飛ぶ方向                
    private Rigidbody  thisObjectRigidbody;              //このオブジェクトのRigidbodyを格納する入れ物
    public  float      firingPower,              　　 　 //このオブジェクトの飛ぶ力
                       ReturnArea;                       //元に戻る範囲
    private float      thisObjectLocalPositionMagnitude; //このオブジェクトのローカルポジションのベクトルの長さ                               
    public  bool       firingCheck;              //このオブジェクトが飛んでいるかのチェック
    public bool predictionLineCheck;            // predictionLineを表示してよいのかのチェック
    private bool changeBird;
    private GameControl gameControl;

    // Use this for initialization
    void Start()
    {
        SetUp();

        gameControl = GameCtl.GetComponent<GameControl>();

      
       

    }

    void Update()
    {

         firingDirection　  = CenterPoint.transform.position - this.transform.position;  //飛ばす方向を求めている
         firingDirectionEnd = firingDirection * firingPower;                              //firingPowerをかけて最終的に飛ばす力を求めている
       
    }

    private void OnMouseDrag()
    {
        if (firingCheck == false)
        {
            thisObjectLocalPositionMagnitude = this.transform.localPosition.magnitude; //このオブジェクトのローカルポジションのベクトルの長さを取得

            if (thisObjectLocalPositionMagnitude <= ReturnArea)       //このオブジェクトがReturnArea内にいるかいないか
            {
                predictionLineCheck = false;                               //predictionLineを表示してもよいフラグをfalse

            }
            else
            {
                predictionLineCheck = true;
            }
            this.transform.LookAt(CenterPoint.transform); //このオブジェクトをCenterPointに向かせている
        }

    }

    private void OnMouseUp()
    {
        if (firingCheck == false)
        {
            Firing();
        }
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject == CenterPoint && firingCheck == true)  //このオブジェクトがCenterPointのColliderに入った時 and　このオブジェクトが飛んでいるとき
        {
            thisObjectRigidbody.useGravity = true;　　　　　　　　　    //このオブジェクトのuseGravityを有効にしている
        }
    }

    public void Firing()
    {
       
        if (predictionLineCheck == false) 　　　　　 //このオブジェクトがReturnArea内にいるかいないか
        {
            this.transform.position = CenterPoint.transform.position;  //ReturnArea内でマウスを離したら元の位置に戻る
        }
        else
        {
            thisObjectRigidbody.velocity = (firingDirectionEnd);  //ここでCenterPointのいる方向にこのオブジェクトを飛ばしている
            Gom.GetComponent<SlingShot_Gom_Control>().lineCheck = false;
            firingCheck = true;  //このオブジェクトを飛ばしたのでfiringCheckをtrueにしている
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        gameControl.changeBird = true;
    }


    public void SetUp()
    {
        firingCheck = false;
        predictionLineCheck = false;
        changeBird = false;
        Gom.GetComponent<SlingShot_Gom_Control>().lineCheck = true;
        thisObjectRigidbody = this.GetComponent<Rigidbody>(); 　　//このオブジェクトのRigidbodyを格納

        thisObjectRigidbody.useGravity = false;

        this.transform.position = CenterPoint.transform.position; //このオブジェクトを初期位置に配置　
    }

}
