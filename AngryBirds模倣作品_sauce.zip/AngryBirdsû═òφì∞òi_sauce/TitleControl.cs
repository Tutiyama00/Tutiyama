﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleControl : MonoBehaviour {

    [SerializeField]
    GameObject TitleScene;
    [SerializeField]
    AudioClip BGM, SELECT_SOUND;

    MusicControlScr musicControlScr;

    private void Start()
    {
        Time.timeScale = 1.0f;

        //musicControlScr = GameObject.FindGameObjectWithTag("MusicControl").GetComponent<MusicControlScr>();
        MusicControlScr1.MusicControl_Singleton.SetPlayBGM(BGM, 1.0f);
        //musicControlScr.SetPlayBGM(BGM, 1.0f);
    }
    public void Play()
    {
        //musicControlScr.MusicOneShotPlay(SELECT_SOUND, 1.0f);
        //musicControlScr.MusicFadeOut(3.0f);

        MusicControlScr1.MusicControl_Singleton.MusicOneShotPlay(SELECT_SOUND, 1.0f);

        //MusicControlScr1.MusicControl_Singleton.MusicFadeOut(3.0f);
        TitleScene.SetActive(false);
        SceneManager.LoadScene("angrybirds", LoadSceneMode.Additive);
    }


}
