﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterOpening : MonoBehaviour {

    private List<AudioSource> AudioList = new List<AudioSource>();


	// Use this for initialization
	void Start () {

        AudioList.AddRange(GetComponents<AudioSource>());
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void ranningAudio()
    {
        AudioList[0].Play();
    }

    private void junpingAudio()
    {
        AudioList[1].Play();
    }

    private void VoiceAudio()
    {
        AudioList[2].Play();
    }
}
