﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPbar : MonoBehaviour {

    [SerializeField]
    GameObject stageCtl;
    stegectl stageCtlScript;

    // Use this for initialization
    void Start () {
        stageCtlScript = stageCtl.GetComponent<stegectl>();

    }
	
	// Update is called once per frame
	void Update () {

        if (GetComponent<Image>().fillAmount == 0)
        {
            stageCtlScript.GameClearScene();
        }

	}

    /// <summary>
    /// HPゲージを減らすメソッド
    /// </summary>
    /// <param name="Damage"></param>ダメージ量
    public void HP(float Damage)
    {
        GetComponent<Image>().fillAmount -= Damage;
    }
}
