﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flashing : MonoBehaviour {
	
	public bool flashingSwich=true;
	public float nextTime;
	public float interval;

	// Use this for initialization
	void Start () {

		nextTime = Time.time;

	}
	
	// Update is called once per frame
	void Update () {

        

		if (nextTime < Time.time) {

			if (flashingSwich) {

				flashingSwich = false;
                this.gameObject.GetComponent<Renderer>().enabled = flashingSwich;
			}
			else
			{
				flashingSwich = true;
                this.gameObject.GetComponent<Renderer>().enabled = flashingSwich;
			}

			nextTime += interval;
		}
		
	}
}
