﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameClearMonster : MonoBehaviour {

    [SerializeField]
    private TextMeshProUGUI gameClearTxt, enterKeyTxt;
    [SerializeField]
    private GameObject gameControl;
    private List<AudioSource> monsterAudioList = new List<AudioSource>();
 
	// Use this for initialization
	void Start () {

        gameClearTxt.enabled = false;
        enterKeyTxt.enabled = false;
        monsterAudioList.AddRange(GetComponents<AudioSource>());

	}
	
	// Update is called once per frame
	void Update () {
		
	}


    private void MonsterVoice()
    {
        monsterAudioList[0].Play();
    }

    private void MonsterEarthquakeAudio()
    {
        monsterAudioList[1].Play();
    }

    private void GameClearAudio()
    {
        monsterAudioList[2].Play();
    }

    private void TextGet()
    {
        gameClearTxt.enabled = true;
        enterKeyTxt.enabled = true;
        enterKeyTxt.GetComponent<bombTxtFlashing>().enabled = true;
        gameControl.GetComponent<GameClearToMenu>().menuFlag = true;
    }
}
