﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class menuctl : MonoBehaviour {

    public bool enter_check;//enterkeyを押したかの判定
    private List<AudioSource> AudioList=new List<AudioSource>();

	// Use this for initialization
	void Start () {

        enter_check = true;

        AudioList.AddRange(gameObject.GetComponents<AudioSource>());

	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown("return")&&enter_check==true)
        {
            enter_check = false;
            GetComponent<Animator>().SetBool("OpenBackGround", true);
           
        }
		
	}


    void OpenAudio()
    {
        AudioList[0].enabled = false;
        AudioList[1].Play();
    }
}
