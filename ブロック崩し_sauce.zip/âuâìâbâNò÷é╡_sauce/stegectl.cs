﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class stegectl : MonoBehaviour {

    [SerializeField]
    private GameObject ball,field,clear;//ball,fieldを入れてね
	public bool gameOver = false,gameclr=false;

    void Start()
    {
        //ゲームの動きを元に戻す
        Time.timeScale = 1;
    }

	void  Update()
	{
		if (gameclr) 
		{
			gomenu ();
		}
    }


    public void GameClear()
    {
        clear.gameObject.SetActive(true);
    }


    public void gomenu()
    {
        //  エンターを押したらメニューに戻る
        if (Input.GetKeyDown("return"))
        {
            Time.timeScale = 1;
            SceneManager.LoadScene("Menu");
        }
    }


    public void gamefld()
    {

        //失敗の文字を表示する
        field.gameObject.SetActive(true);
       
    }
  
    public void gamestop()
    { 
        //ゲームの動きを止める
        Time.timeScale = 0;
    }

    //呼び出すアイテムの数字がでる
    public int Itemsc(int ram)
    {
        System.Random Itemran = new System.Random(ram);
        int Item = Itemran.Next(1000);

        return Item;
    }

    public void GameClearScene()
    {
        SceneManager.LoadScene("GameClearScene");
    }
}
