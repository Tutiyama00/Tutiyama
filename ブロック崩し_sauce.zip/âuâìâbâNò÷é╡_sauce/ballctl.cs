﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ballctl : MonoBehaviour {
   
    public float ballspeed,ballSpeedVelocity_z, ballSpeedVelocity_x;//ボールのスピード
    [SerializeField] private GameObject stgctl,bur,wKey, dleatzone,rock,fireBall,monster;//stgcltとburとwKeyを入れてね
    [SerializeField] private Image dltImage1, dltImage2;
    public bool ballStartCheck=true, gamefld=false; //ボールが発射していないか判定,ゲームオーバーか判定
    public int ballcnt;//何個目のボールか
    private const int BALL_MAX_COUNT = 3;//残機数
    private int dltImageCnt = 1;//消すballImageの番号
    private List<AudioSource> audioSources = new List<AudioSource>();

    // Use this for initialization
    void Start ()
    {
        audioSources.AddRange(GetComponents<AudioSource>());
        ballcnt = 1;
    }


    void Update()
    {
        //ボールのｚ加速度が５０をきらないようにする
        if (System.Math.Abs( this.GetComponent<Rigidbody>().velocity.z) <= ballSpeedVelocity_z && ballStartCheck==false)
        {
            if (this.GetComponent<Rigidbody>().velocity.z > 0)
            {
                this.GetComponent<Rigidbody>().velocity = new Vector3(this.GetComponent<Rigidbody>().velocity.x, 0, ballSpeedVelocity_z);
            }
            else
            {
                this.GetComponent<Rigidbody>().velocity = new Vector3(this.GetComponent<Rigidbody>().velocity.x, 0, -ballSpeedVelocity_z);
            }
        }

        if (System.Math.Abs(this.GetComponent<Rigidbody>().velocity.x) <= ballSpeedVelocity_x && ballStartCheck == false)
        {
            if (this.GetComponent<Rigidbody>().velocity.x > 0)
            {
                this.GetComponent<Rigidbody>().velocity = new Vector3(ballSpeedVelocity_x, 0, this.GetComponent<Rigidbody>().velocity.z);
            }
            else
            {
                this.GetComponent<Rigidbody>().velocity = new Vector3(-ballSpeedVelocity_x, 0, this.GetComponent<Rigidbody>().velocity.z);
            }
        }


        //burと同じ移動をする
        if (ballStartCheck)
        {
			//バーに追従する位置に行く
			this.transform.position = new Vector3 (bur.transform.position.x, bur.transform.position.y-2, bur.transform.position.z+5);

            //spaseキーを押したら発射
            if (Input.GetKeyDown(KeyCode.Space))
            {
                //wKeyテキストを非表示
                wKey.gameObject.SetActive(false);
				//ボール発射
                this.GetComponent<Rigidbody>().AddForce(ballspeed, 0, ballspeed, ForceMode.Acceleration);
                ballStartCheck = false;//ボールの発射判定
            }
        }

        if (gamefld)
        {
            //メニュー遷移の処理
            stgctl.GetComponent<stegectl>().gomenu();
        }

    }

    void OnCollisionEnter(Collision dltzone)
    {
        //何かにぶつかったら音を鳴らす
        if (dltzone.gameObject == dleatzone)
        {
            audioSources[1].Play();
         
        }
        else if(dltzone.gameObject.tag == rock.tag)
        {
            audioSources[2].Play();
         
        }
        else if(dltzone.gameObject.tag == fireBall.tag)
        {
            audioSources[3].Play();
           
        }
        else if(dltzone.gameObject.tag == monster.tag)
        {
            audioSources[4].Play();
        }
        else
        {
            audioSources[0].Play();
        }
        

        //ゲームオーバー
        if ((ballcnt >= BALL_MAX_COUNT) && (dltzone.gameObject.name == "dleatzone"))
        {
            //ゲームオーバー音をだす
            audioSources[5].Play();

            //ゲームの動きを止める
            stgctl.GetComponent<stegectl>().gamestop();

            //fieldを表示
            stgctl.GetComponent<stegectl>().gamefld();

            //gamefldのフラグを立てる
            gamefld = true;

        }

        //ボールリセット
        if ((ballcnt<BALL_MAX_COUNT) && (dltzone.gameObject.name == "dleatzone"))
        {
            //ボールが落ちた回数をカウント
            ballcnt = ballcnt+1;

            //ボールの動きを止める
            this.gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);

            //ballStartCheckのフラグを元に戻す
            ballStartCheck = true;

            //wKeyテキストを表示
            wKey.gameObject.SetActive(true);

            //ballImageを一つ非表示
            if (dltImageCnt == 1)
            {
                dltImage1.enabled = false;
            }
            else
            {
                dltImage2.enabled = false;
            }

            dltImageCnt += 1;


        }

        
    }

  

    }

    




