﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class operationDescriptionCtl : MonoBehaviour {
    [SerializeField]
    GameObject canvas;

    private GameObject MainCameraMenu;
    private int StageNomber;
    // Use this for initialization
    void Start () {

        //選択したステージの番号を取得している
        MainCameraMenu = GameObject.Find("MainCameraMenu");
        StageNomber = MainCameraMenu.GetComponent<cameraTrigger>().selectStageNomber;

        //Menuシーンを削除する
        SceneManager.UnloadSceneAsync(0);

        StartCoroutine("StageJump");


    }
	
	// Update is called once per frame
	void Update () {
		
	}

    /// <summary>
    /// 一定時間待ってからステージ追加
    /// </summary>
    /// <returns></returns>
    private IEnumerator StageJump()
    {
        yield return new WaitForSeconds(5f);
        canvas.gameObject.SetActive(false);
        switch (StageNomber)
        {
            case 1:
                SceneManager.LoadScene("stage2",LoadSceneMode.Additive);
                break;

            case 2:
                SceneManager.LoadScene("stage3_opening");
                break;

        }
    }
}
