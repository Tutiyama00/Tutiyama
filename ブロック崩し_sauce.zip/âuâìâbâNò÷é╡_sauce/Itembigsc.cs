﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Itembigsc : MonoBehaviour {

   
    private  GameObject bur,burCube,ball;
    public int Itemspeed;
    private float burx=25f,burx2=33f;
    private float bigcnt2;
    private bool boomSetFlag = false,ballSwich;

    // Use this for initialization
    void Start () {

        bur = GameObject.Find("bur");
        burCube = GameObject.Find("burCube");
        ball = GameObject.Find("ball");

    }
	
	// Update is called once per frame
	void Update () {

        ballSwich = ball.GetComponent<ballctl>().ballStartCheck;
        if (ballSwich)
        {
            Destroy(this.gameObject);
        }
        else
        {
            this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, Itemspeed);
        }
    }


    void OnTriggerEnter(Collider other)
    {
        if (boomSetFlag)
        {
            return;
        }

        if (other.gameObject.name== "dleatzone")
        {
            boomSetFlag = true;
            //デリートゾーンにぶつかったら消える
            Destroy(this.gameObject);
        }

        if (other.gameObject == bur)
        {
            boomSetFlag = true;

            if (bur.transform.localScale.x < 33)
            {
                Itembig();
       
                Destroy(this.gameObject);
            }
            else
            {
                Destroy(this.gameObject);
            }
        }

    }
    void Itembig()
    {
        bur.transform.localScale = new Vector3(bur.transform.localScale.x+5, bur.transform.localScale.y, bur.transform.localScale.z);
    }
}
