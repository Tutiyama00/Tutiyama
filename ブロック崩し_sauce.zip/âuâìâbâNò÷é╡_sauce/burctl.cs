﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class burctl : MonoBehaviour
{
    [SerializeField]
    private GameObject bur,meteor, SmallFiresParticleSystem;
    public float speed, slowTime, slowInterval;//burのスピード
    private bool slowCheck = false;

    // Use this for initialization
    void Start() {

    }

    // Update is called once per frame
    void Update() {

        burmove();
        
        //一定時間の経過で速度をもとに戻す
        if(slowCheck==true && Time.time > slowTime)
        {
            slowCheck = false;
            speed = speed * 4;
            SmallFiresParticleSystem.GetComponent<AudioSource>().enabled = false;
        }
    }

    //bur の動き
    public void burmove()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            this.GetComponent<Rigidbody>().velocity = new Vector3(speed, 0, 0);
        }

        if (Input.GetKeyUp(KeyCode.RightArrow))
        {
            this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        }


        if (Input.GetKey(KeyCode.LeftArrow))
        {
            this.GetComponent<Rigidbody>().velocity = new Vector3(-speed, 0, 0);
        }

        if (Input.GetKeyUp(KeyCode.LeftArrow))
        {
            this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        }

    }

    private void OnCollisionEnter(Collision collision)
    {
        //fireに当たったらスピードを/4する
        if (collision.gameObject.tag == meteor.tag && slowCheck==false)
        {
            slowCheck = true;
            slowTime = Time.time + slowInterval;
            speed = speed / 4;
            SmallFiresParticleSystem.GetComponent<AudioSource>().enabled = true;
            SmallFiresParticleSystem.SetActive(false);
            SmallFiresParticleSystem.SetActive(true);
            
        }
    }


}
     





