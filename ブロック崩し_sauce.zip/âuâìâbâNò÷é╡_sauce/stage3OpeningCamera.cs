﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PostProcessing;
using UnityEngine.SceneManagement;

public class stage3OpeningCamera : MonoBehaviour {

    private float LuminanceMax = -4f;
    private bool startCoroutineFlag = true;

    // Use this for initialization
    void Start () {

        var setting = GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings;
        setting.maxLuminance = LuminanceMax;
        GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings = setting;

	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown(KeyCode.Return) && startCoroutineFlag == true) 
        {
            startCoroutineFlag = false;
            StartCoroutine("sceneFadeout");
        }
		
	}

    private void CoroutineStart()
    {
        if (startCoroutineFlag)
        {
            startCoroutineFlag = false;
            StartCoroutine("sceneFadeout");
        }
    }

    private IEnumerator sceneFadeout()
    {
        LuminanceMax = GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings.maxLuminance;
        while(LuminanceMax <= 5f)
        {
            var setting = GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings;
            yield return new WaitForSeconds(0.1f);
            LuminanceMax += 0.2f;
            setting.maxLuminance = LuminanceMax;
            GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings = setting;
        }

        SceneManager.LoadScene("stage3",LoadSceneMode.Additive);
    }
}
