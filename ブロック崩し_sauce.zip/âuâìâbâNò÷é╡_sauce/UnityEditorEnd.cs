﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnityEditorEnd : MonoBehaviour {


    public void QuitEvents()
    {
        Application.Quit();
    }
}
