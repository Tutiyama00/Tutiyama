﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class bombTxtFlashing : MonoBehaviour
{

    public bool flashingSwich = true;
    public float nextTime;
    public float interval;


    // Use this for initialization
    void Start()
    {

        nextTime = Time.time;

    }

    // Update is called once per frame
    void Update()
    {



        if (nextTime < Time.time)
        {

            if (flashingSwich)
            {

                flashingSwich = false;
                GetComponent<TextMeshProUGUI>().enabled = false;
            }
            else
            {
                flashingSwich = true;
                GetComponent<TextMeshProUGUI>().enabled = true;
            }

            nextTime += interval;
        }

    }
}
