﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class burCube : MonoBehaviour {

    [SerializeField]
    private GameObject ball,itemNomal,itemBig,bombItem,bomb,bombTxt;//ballをいれてね
    public float bombCnt = 0;
    private List<AudioSource> audioList = new List<AudioSource>();

    // Use this for initialization
    void Start () {

        audioList.AddRange(GetComponents<AudioSource>());
		
	}
	
	// Update is called once per frame
	void Update () {

        if(bombCnt > 0 && Input.GetKeyDown(KeyCode.UpArrow))
        {
            bombCnt -= 1;
            Instantiate(bomb);
            bombTxt.SetActive(false);
        }
		
	}

    void OnTriggerEnter(Collider ball)
    {
        if (ball.gameObject.name == "ball")
        {
            burReflection();
        }

        if (ball.gameObject.tag == bombItem.gameObject.tag && bombCnt==0)
        {
            bombCnt += 1;
            audioList[2].Play();
            bombTxt.SetActive(true);
        }
        
        if(ball.gameObject.tag == itemBig.gameObject.tag)
        {
            audioList[0].Play();
        }

        if (ball.gameObject.tag == itemNomal.gameObject.tag)
        {
            audioList[1].Play();
        }
    }

    public void burReflection()
    {
        Vector3 ballpos = ball.transform.position;
        Vector3 burpos = this.transform.position;

        ball.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);

        float refpos = ballpos.x - burpos.x;
        float refper = refpos / (this.transform.localScale.x / 2);

        if (refper<=0.7&&refper>=-0.7)
        {
            ball.GetComponent<Rigidbody>().velocity = new Vector3(refper * 10, 0, 50);
        }
        else
        {
                ball.GetComponent<Rigidbody>().velocity = new Vector3(refper*3, 0, 40);  
        }

        
    }
}
