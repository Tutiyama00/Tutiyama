﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Itemnomal : MonoBehaviour {

   
    private  GameObject bur, burCube,ball;
    public int Itemspeed;
    private bool boomSetFlag = false, ballSwich;

    // Use this for initialization
    void Start()
    {

        bur     = GameObject.Find("bur");
        burCube = GameObject.Find("burCube");
        ball    = GameObject.Find("ball");

    }

    // Update is called once per frame
    void Update()
    {

        ballSwich = ball.GetComponent<ballctl>().ballStartCheck;
        if (ballSwich)
        {
            Destroy(this.gameObject);
        }
        else
        {
            this.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, Itemspeed);
        }
    }


   

    void OnTriggerEnter(Collider other)
    {
        if (boomSetFlag)
        {
            return;
        }

        if (other.gameObject.name == "dleatzone")
        {
            boomSetFlag = true;
            //デリートゾーンにぶつかったら消える
            Destroy(this.gameObject);
        }
        else if (other.gameObject == bur)//burにぶつかったらburの大きさを元に戻す
        {
            boomSetFlag = true;
            nomal();
          
            Destroy(this.gameObject);
        }

    }

    void nomal()
    {
        bur.transform.localScale = new Vector3(18f, bur.transform.localScale.y, bur.transform.localScale.z);
    }

}
