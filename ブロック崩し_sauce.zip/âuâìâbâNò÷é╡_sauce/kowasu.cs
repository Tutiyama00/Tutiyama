﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kowasu : MonoBehaviour {

    [SerializeField] private GameObject gameclear, stgctl,big,nextbig,nomal,bomb,bur,ball;//gameclear,stgctlを入れてね
	public bool gameclr=false; //ゲームクリア判定
    public AudioClip gameclearAudio;
    private GameObject mainCameraOperetion;

	void Start() {

        mainCameraOperetion = GameObject.FindGameObjectWithTag("MainCameraOperation");

    }

    void Update()
    {
        if (gameclr)
        {
            //メニューへの遷移処理
			stgctl.GetComponent<stegectl>().gomenu();
        }
    }

    //クリア処理
    void OnCollisionEnter(Collision Collision)
    {


        if (Collision.gameObject == ball) {
            //アイテムの数字をランダムで取得
            System.Random ran = new System.Random();
            int ranpas = ran.Next();
            int itemNam = stgctl.GetComponent<stegectl>().Itemsc(ranpas);
            

            if (itemNam <= 50 || itemNam >= 950)
            {
                big.transform.position = new Vector3(this.transform.position.x, this.transform.position.y + 3, this.transform.position.z);
                Instantiate(big);

            }
            else if (450 <= itemNam && itemNam <= 550)
            {
                  
                nomal.transform.position = new Vector3(this.transform.position.x, this.transform.position.y + 3, this.transform.position.z);
                Instantiate(nomal);

            }
            else if ((itemNam >= 95 && itemNam <= 100) || (itemNam >= 195 && itemNam <= 200) || (itemNam >= 295 && itemNam <= 300) || (itemNam >= 395 && itemNam <= 400) || (itemNam >= 595 && itemNam <= 600) || (itemNam >= 695 && itemNam <= 700) || (itemNam >= 795 && itemNam <= 800) || (itemNam >= 895 && itemNam <= 900))
            {
                bomb.transform.position = new Vector3(this.transform.position.x, this.transform.position.y + 3, this.transform.position.z);
                Instantiate(bomb);
            }

        }

        //blockタグの数だけ[]に格納
        GameObject[] gameObjects = GameObject.FindGameObjectsWithTag("block");
        if(gameObjects.Length == 1) {
            //最後のブロックを非表示にする
            this.GetComponent<Renderer>().enabled = false;
            // gameclearを表示
            gameclear.gameObject.SetActive(true);
            //ゲームの動きを止める
            stgctl.GetComponent<stegectl>().gamestop();
            //gameclrフラグを立てる
            gameclr = true;
            //元々流れていたBGMを止める
            mainCameraOperetion.gameObject.SetActive(false); 
            //ゲームクリア音をだす
            GetComponent<AudioSource>().PlayOneShot(gameclearAudio);
        }

		if (gameObjects.Length != 1) {
			Destroy (this.gameObject);
		}
    }

}
