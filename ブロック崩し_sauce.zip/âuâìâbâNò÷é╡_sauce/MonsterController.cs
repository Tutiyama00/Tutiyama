﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class MonsterController : MonoBehaviour {

    [SerializeField]
    GameObject ball,Green,FireBall_1, FireBall_2, FireBall_3,Rock;
    public float damage,bombDamage;
    private Vector3 fireBall2Pos;
    private bool spaceCheck;
    private GameObject[] Rockpositions;
    private GameObject[] Rocks;
    private int RocksLength, minAction=0, maxAction=1, rockMore=5,IdleAudioRan,fireBallNumber = 1;
    private List<GameObject> RockList = new List<GameObject>();
    private List<GameObject> ExplosionSpheres = new List<GameObject>();
    private float ranMin_x = -9.24f, ranMax_x = 35.44f, ranMin_z = 5017.07f, ranMax_z = 5030.9f;
    public AudioClip fireAudio, rockAudio, bombAudio, bombAudio2, idleAudio1, idleAudio2, idleAudio3;
    private AudioSource audioSource;

    // Use this for initialization
    void Start () {

      //Rockを生成してRockListに格納
        for(int i = 0; rockMore > i; i++)
        {
            Instantiate(Rock);
        }

        RockList.AddRange(GameObject.FindGameObjectsWithTag("Rock"));

        for (int i = 0; rockMore > i; i++)
        {
            RockList[i].gameObject.SetActive(false);
            ExplosionSpheres.Add(RockList[i].transform.Find("ExplosionSphere").gameObject);
        }

        //AudioSourceを取得
        audioSource = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update () {

        //ボールを発射していない状態では攻撃をしてこないようにしている
        spaceCheck =! ball.GetComponent<ballctl>().ballStartCheck;
        GetComponent<Animator>().SetBool("Actiontrigger", spaceCheck);

        if (Input.GetKeyDown(KeyCode.S))
        {
            GetComponent<Animator>().Play("Rock");
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            GetComponent<Animator>().Play("fire");
        }


       

    }


    private void OnCollisionEnter(Collision collision)
    {
        //ballに当たったらダメージを与えるメソッドを呼んでいる
        if (collision.gameObject == ball)
        {
            Green.GetComponent<HPbar>().HP(damage);
        }
    }

    /// <summary>
    /// 出すfireBallNumberを初期値に戻す
    /// </summary>
    private void FireBallNumberReset()
    {
        fireBallNumber = 1;
    }

    /// <summary>
    /// fireを3つ呼び出す
    /// </summary>
    private void FireBallInjection()
    {
        switch (fireBallNumber)
        {
            case 1:
                Instantiate(FireBall_1);
                break;

            case 2:
                Instantiate(FireBall_2, new Vector3(FireBall_1.transform.position.x - 14, FireBall_1.transform.position.y, FireBall_1.transform.position.z), Quaternion.identity);
                break;

            case 3:
                Instantiate(FireBall_3, new Vector3(FireBall_1.transform.position.x + 14, FireBall_1.transform.position.y, FireBall_1.transform.position.z), Quaternion.identity);
                break;
        }

        fireBallNumber += 1;
    }

    /// <summary>
    /// Rockをランダムのポジションに表示するコルーチンを呼び出している
    /// </summary>
    private void RockInjectionAction()
    {
        StartCoroutine("RockInjection");
    }

    IEnumerator RockInjection()
    {
        
        for(int i = 0; RockList.Count > i; i++)
        {
           
            RockList[i].SetActive(true);
            RockList[i].gameObject.GetComponent<BoxCollider>().isTrigger = true;
 

            float ran_x = Random.Range(ranMin_x, ranMax_x + 1);
            float ran_z = Random.Range(ranMin_z, ranMax_z + 1);

           

            RockList[i].gameObject.transform.position = new Vector3(ran_x, -181.17f, ran_z);


             yield return new WaitForSeconds(0.15f);


            bool flag = RockList[i].GetComponent<RockScript>().OverlapRock;

         //もしポジションが他のRockと被っていたらもう一度ランダムなポジションに表示
            while (flag)
            {
                ran_x = Random.Range(ranMin_x, ranMax_x + 1);
                ran_z = Random.Range(ranMin_z, ranMax_z + 1);
                RockList[i].gameObject.transform.position = new Vector3(ran_x, -181.17f, ran_z);

                yield return new WaitForSeconds(0.15f);

                flag = RockList[i].GetComponent<RockScript>().OverlapRock;
            }

            
            RockList[i].GetComponent<MeshRenderer>().enabled = true;
            RockList[i].GetComponent<BoxCollider>().isTrigger = false;
        }

       
        yield return new WaitForSeconds(5f);

        //ブロックを非表示にする処理をしている（内側の球の処理も）
        for (int i = 0; RockList.Count > i; i++)
        {
   
            ExplosionSpheres[i].GetComponent<Renderer>().enabled = true;

            while (ExplosionSpheres[i].gameObject.transform.localScale.x < 2f)
            {
                yield return new WaitForSeconds(0.01f);
                ExplosionSpheres[i].gameObject.transform.localScale = new Vector3(ExplosionSpheres[i].gameObject.transform.localScale.x + 0.05f, ExplosionSpheres[i].gameObject.transform.localScale.y + 0.05f, ExplosionSpheres[i].gameObject.transform.localScale.z + 0.05f);
            }
            
            RockList[i].gameObject.GetComponent<MeshRenderer>().enabled=false;

            while (ExplosionSpheres[i].gameObject.transform.localScale.x > 0f)
            {
                yield return new WaitForSeconds(0.01f);
                ExplosionSpheres[i].gameObject.transform.localScale = new Vector3(ExplosionSpheres[i].gameObject.transform.localScale.x - 0.05f, ExplosionSpheres[i].gameObject.transform.localScale.y - 0.05f, ExplosionSpheres[i].gameObject.transform.localScale.z - 0.05f);
            }

            ExplosionSpheres[i].GetComponent<Renderer>().enabled = false;
            RockList[i].SetActive(false);
        }



    }


    /// <summary>
    /// モンスターの攻撃をランダムで決めている
    /// </summary>
    private void LotteryAction()
    {
        int ran = Random.Range(minAction, maxAction + 1);

        GetComponent<Animator>().SetInteger("ActionNumber", ran);
       
    }


    /// <summary>
    /// ボムの受けた時のリアクションとダメージを与えている
    /// </summary>
    private void BombDamageAnimation()
    {
        GetComponent<Animator>().Play("BombDamage");
        Green.GetComponent<HPbar>().HP(bombDamage);
    }

    //ここから下はモンスターの声
    private void BombAudio()
    {
        audioSource.PlayOneShot(bombAudio);
    }

    private void BombAudio2()
    {
        audioSource.PlayOneShot(bombAudio2);
    }

    private void FireAudio()
    {
        audioSource.PlayOneShot(fireAudio);
    }

    private void RockAudio()
    {
        audioSource.PlayOneShot(rockAudio);
    }

    private void IdleAudio()
    {
        IdleAudioRan = Random.Range(0, 2);

        switch (IdleAudioRan)
        {
            case 0:
                audioSource.PlayOneShot(idleAudio1);
                break;
            case 1:
                audioSource.PlayOneShot(idleAudio2);
                break;
            case 2:
                audioSource.PlayOneShot(idleAudio3);
                break;
        }
    }
}
