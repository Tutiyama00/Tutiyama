﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PostProcessing;
using UnityEngine.SceneManagement;

public class cameraTrigger : MonoBehaviour
{
    [SerializeField]
    GameObject endButton;
    private bool ENTER_CHECK,STAGE_SELECT, STAGE_SELECT_AUDIO,STAGE_LOAD;
    private int  Stages=2;
    public int selectStageNomber;
    private float TIME, Interval=5, LuminanceMax = -5;
    public AudioClip AudioStage1Select, AudioStage2Select;
    private AudioSource AudioSource;
  
    // Use this for initialization
    void Start()
    {
        var settings = GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings;
        settings.maxLuminance = LuminanceMax;
        GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings = settings;
        AudioSource = GetComponent<AudioSource>();
        selectStageNomber = 1;
        ENTER_CHECK = false;
        STAGE_SELECT = false;
        STAGE_SELECT_AUDIO = true;
        STAGE_LOAD = false;

    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Return) && ENTER_CHECK == false)
        {
            endButton.SetActive(false);
            ENTER_CHECK = true;
            TIME = Time.time;
            GetComponent<Animator>().SetBool("caneraswi", true);
        }

        if (TIME + Interval < Time.time && ENTER_CHECK==true && STAGE_SELECT==false)
        {
            STAGE_SELECT = true;
        }

        if (STAGE_SELECT==true && STAGE_LOAD == false)
        {

            if (Input.GetKeyDown(KeyCode.RightArrow) && selectStageNomber<Stages)
            {
                
                selectStageNomber += 1;
                GetComponent<Animator>().SetInteger("StageSelect", selectStageNomber);
               
            }

            if (Input.GetKeyDown(KeyCode.LeftArrow) && selectStageNomber>1)
            {
                selectStageNomber -= 1;
                GetComponent<Animator>().SetInteger("StageSelect", selectStageNomber);

            }

        }

        if(Input.GetKeyDown("return") && STAGE_SELECT == true && STAGE_SELECT_AUDIO == true)
        {
            STAGE_SELECT_AUDIO = false;
            STAGE_LOAD = true;

            switch (selectStageNomber)
            {
                case 1 :
                    
                    AudioSource.PlayOneShot(AudioStage1Select);
                    StartCoroutine("FadeOutMethod");
                    StartCoroutine("LoadScene", "operationDescription");
                    break;

                case 2 :
                   
                    AudioSource.PlayOneShot(AudioStage2Select);
                    StartCoroutine("FadeOutMethod");
                    StartCoroutine("LoadScene", "operationDescription");
                    break;
            }

           
        }
       

       
    }

    void StageSelectAudio()
    {
        GetComponent<AudioSource>().Play();
    }

    private IEnumerator FadeOutMethod()
    {
        LuminanceMax = GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings.maxLuminance;
        while (LuminanceMax <= 5f)
        {
            var settings = GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings;
            settings.maxLuminance = LuminanceMax;
            yield return new WaitForSeconds(0.1f);
            LuminanceMax += 0.5f;
            GetComponent<PostProcessingBehaviour>().profile.eyeAdaptation.settings = settings;
        }
    }

    private IEnumerator LoadScene(string stageName)
    {
        yield return new WaitForSeconds(5f);
        SceneManager.LoadScene(stageName,LoadSceneMode.Additive);
    }
}
