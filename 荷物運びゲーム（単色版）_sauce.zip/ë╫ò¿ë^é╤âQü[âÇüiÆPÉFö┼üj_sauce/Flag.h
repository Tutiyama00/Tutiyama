#ifndef FLAG_H
#define FLAG_H

enum class FlagCode:unsigned char
{
	INPUT_ERRER = 1
};

class Flag
{
public:
	Flag();
	~Flag();

	bool Check(FlagCode);
	void Set(FlagCode);
	void ReSet(FlagCode);

private:
	unsigned char mFlags;
};

#endif // !FLAG_H
