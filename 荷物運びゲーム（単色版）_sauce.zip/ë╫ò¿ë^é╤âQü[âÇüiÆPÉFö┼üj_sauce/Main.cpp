#include<Windows.h>
#include"MainGameManeger.h"

int WINAPI WinMain(HINSTANCE h_instance, HINSTANCE h_prev_instance, PSTR str_cmd, int cmd_show)
{
	HWND hwnd;
	WNDCLASS winc;
	MSG msg;
	MainGameManeger* mgm = new MainGameManeger();

	winc.style = CS_HREDRAW | CS_VREDRAW;
	winc.lpfnWndProc = mgm->BaseWindProc;
	winc.cbClsExtra = 0;
	winc.cbWndExtra = 0;
	winc.hInstance = h_instance;
	winc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	winc.hCursor = LoadCursor(NULL, IDC_ARROW);
	winc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	winc.lpszMenuName = NULL;
	winc.lpszClassName = "WC_TUTIYAMA";

	if (!RegisterClass(&winc)) { return 0; }

	hwnd = CreateWindow(
		"WC_TUTIYAMA",
		"kouhei",
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		NULL,
		h_instance,
		NULL);

	if (hwnd == NULL) { return 0; }

	ShowWindow(hwnd, SW_SHOW);

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	delete mgm;
	return msg.wParam;
}