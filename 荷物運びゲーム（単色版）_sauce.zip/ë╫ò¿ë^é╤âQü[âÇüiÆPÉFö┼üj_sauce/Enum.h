#ifndef ENUM_H
#define ENUM_H

enum class GameState:unsigned char
{
	TITLE,
	STAGE_SELECT,
	PLAY,
	CLEAR,
	FAILED
};

enum class Object:unsigned char
{
	WALL,
	SPACE,
	BLOCK,
	BLOCK_ON_GOAL,
	PLAYER,
	PLAYER_ON_GOAL,
	GOAL
};

#endif // !ENUM_H

