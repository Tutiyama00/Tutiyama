﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SEAoudio : SingletonMonoBehaviour<SEAoudio>
{
    [SerializeField]
    private AudioClip mCanselSE;
    [SerializeField]
    private AudioClip mCursorMoveSE;
    [SerializeField]
    private AudioClip mChoiceSE;
    [SerializeField]
    private AudioClip mPointGetSE;
    [SerializeField]
    private AudioClip mSwitchSE;
    [SerializeField]
    private AudioClip mPlayerJumpSE;
    [SerializeField]
    private AudioClip mGrabMoveSE;
    [SerializeField]
    private AudioClip mCurtainSE;
    [SerializeField]
    private AudioClip mWalkSE;
    [SerializeField]
    private AudioClip mTutorialCheckPointSE;
    [SerializeField]
    private AudioClip mStampUISE;
    [SerializeField]
    private AudioClip mMakimonoUISE;
    [SerializeField]
    private AudioClip mStarGetUISE;
    [SerializeField]
    private AudioClip mCantSE;
    [SerializeField]
    private AudioClip mTextTypeSE;

    public AudioClip CanselSE { get { return mCanselSE; } }
    public AudioClip CursorMoveSE { get { return mCursorMoveSE; } }
    public AudioClip ChoiceSE { get { return mChoiceSE; } }
    public AudioClip PointGetSE { get { return mPointGetSE; } }
    public AudioClip SwitchSE { get { return mSwitchSE; } }
    public AudioClip PlayerJumpSE { get { return mPlayerJumpSE; } }
    public AudioClip GrabMoveSE { get { return mGrabMoveSE; } }
    public AudioClip CurtainSE { get { return mCurtainSE; } }
    public AudioClip WalkSE { get { return mWalkSE; } }
    public AudioClip TutorialCheckPointSE { get { return mTutorialCheckPointSE; } }
    public AudioClip StampSEUI { get { return mStampUISE; } }
    public AudioClip MakimonoUISE { get { return mMakimonoUISE; } }
    public AudioClip StarGetUISE { get { return mStarGetUISE; } }
    public AudioClip CantSE { get { return mCantSE; } }
    public AudioClip TextTypeSE { get { return mTextTypeSE; } }

    private string[] audioKey_array;
    private AudioClip[] audioValue_array;

    protected override void Awake()
    {
        base.Awake();

        audioKey_array = new string[]{ "Cansel","CursorMove","Choice","PointGet","Switch","PlayerJump","GrabMove","Curtain","Walk", "TutorialCheckPoint","Stamp" ,"Makimono","StarGet","Cant","TextType"};
        audioValue_array = new AudioClip[] { CanselSE, CursorMoveSE, ChoiceSE, PointGetSE, SwitchSE, PlayerJumpSE, GrabMoveSE, CurtainSE,WalkSE ,TutorialCheckPointSE,StampSEUI,MakimonoUISE,StarGetUISE,CantSE,mTextTypeSE};
    }


    /// <summary>
    /// 配列から対応するSEを探す
    /// </summary>
    /// <param name="sceneName"></param>
    public AudioClip FindSE(string sceneName)
    {
        //配列探索
        for (int i = 0; i < audioKey_array.Length; i++)
        {
            //対応するキーがあるか
            if (audioKey_array[i] == sceneName)
            {
                //あったら対応する曲を返す
                return audioValue_array[i];
            }
        }

        return null;
    }
}
