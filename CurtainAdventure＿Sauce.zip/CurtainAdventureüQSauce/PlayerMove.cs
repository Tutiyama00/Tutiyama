﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum PlayerState
{
    NONE = -1,

    ON_GROUND,
    JUMP,
    GRAB,

    MAX
}


[RequireComponent(typeof(PlayerCollisionEvent))]
public partial class PlayerMove : Overlap
{


    #region 定数
    /// <summary>重力</summary>
    private const float GRAVITY = 40.0f;
    /// <summary>摩擦の抵抗値</summary>
    private const float DUMPING = 0.5f;
    /// <summary>最高移動速度</summary>
    private const float MAX_SPEED = 4.0f;
    /// <summary>通常時の感度</summary>
    private const float DEFAULT_SENSITIVITY = 15.0f;
    /// <summary>ジャンプ時逆入力された際の感度</summary>
    private const float JUMP_INVERSE_SENSITIVITY = 5.0f;
    /// <summary>ジャンプ力</summary>
    private const float JUMP_FORCE = 500.0f;
    /// <summary>ジャンプの上昇速度の限界</summary>
    private const float MAX_RISING_SPEED = 50.0f;
    /// <summary>最大落下速度</summary>
    private const float MAX_FALL_SPEED = 12.0f;
    /// <summary>右方向を指す時に使用</summary>
    private const float RIGHT = 1.0f;
    /// <summary左方向を指す時に使用</summary>
    private const float LEFT = -1.0f;
    /// <summary>自分が振り向く速度</summary>
    private const float TURN_SPEED = 25.0f;
    /// <summary>プレイヤーの初期移動距離</summary>//金
    private const float PLAYER_MOVE_DISTANCE = 2.5f;
    /// <summary>プレイヤーの初期移動時間</summary>//金
    private const float PLAYER_MOVE_TIME = 0.4f;
    #endregion

    #region 接地判定用変数
    //[SerializeField, Header("SphereCast Parameter"), Space]
    //private float mSpheCastRadius = 0.5f;

    //Playerの足元に出る白い四角
    [SerializeField]
    private Vector3 mBoxCastSize = new Vector3(0.3f, 0.05f, 0.35f);
    #endregion

    #region 接地判定の共通変数
    [SerializeField]
    private float mGroundRayDistance = 0.33f;

    [SerializeField]
    private Vector3 mGroundRayOffset = new Vector3(0.0f, 0.1f, 0.0f);
    #endregion

    public bool mGrabCol;//金

    /// <summary> 長押し連続ジャンプ防止用フラグ</summary>
    private bool mIsJumpButtonPressing;
    /// <summary>接地判定用フラグ</summary>
    private bool mIsGrounded;
    /// <summary> 移動の最高速度に達するまでの加速度</summary>
    private float mSensitivity = 15.0f;
    /// <summary> Playerの方向を示す符号</summary> 
    private float mDirSign;
    /// <summary> ジャンプの大小を決めるときに使う</summary>
    private float mJumpTimer;
    private float mJumpInterval;
    /// <summary> 接地判定用のレイ</summary>
    private Ray mGroundRay = new Ray();
    /// <summary> ジャンプの方向と力ベクトル</summary>
    private Vector3 mJumpForce;
    private UserInput mUserInput;
    private GrabUI grabUI;//金
    private PlayerState mPlayerState;
    private PlayerAnimation mAnimation;
    private Vector3 mPlayerPosition;
    private Vector3 mPlayerMovePoint;//プレイヤーの初期移動後の位置
    private RaycastHit hitInfo;//金
    private GameController mGameController;//金
    //追記
    private CapsuleCollider mCapCol;
    private BoxCollider mBoxCol;

    //ツチヤマ0614
    private int mMoveAudioInterval = 10;　//左右移動のときにSEの間隔フレーム数
    private int mMoveAudioCounter = 0; //フレームカウンター
    //20180619
    /// <summary>土埃Particle</summary>
    private ParticleSystem mDustSmoke;

    //Curtainから参照される
    public PlayerState GetPlayerState { get { return mPlayerState; } }

    //0624グラブの失敗SE用変数（土）
    private bool mRightPullCantSE = true;
    private bool mRightPushCantSE = true;
    private bool mLeftPullCantSE = true;
    private bool mLeftPushCantSE = true;

    //0625tuti
    private bool mFreezePlayer = false;

    //0628tuti
    private bool mCanCheckGrabFrag = true;

    new void Awake()
    {
        base.Awake();

        //ジャンプ時のAddForce用のベクトル
        mJumpForce = new Vector3(0.0f, JUMP_FORCE, 0.0f);

        //接地判定用レイの方向
        mGroundRay.direction = Vector3.down;

        grabUI = FindObjectOfType<GrabUI>();//金

        mGameController = FindObjectOfType<GameController>();

        mUserInput = FindObjectOfType<UserInput>();

        mAnimation = new PlayerAnimation(GetComponent<Animator>());

        mCapCol = GetComponent<CapsuleCollider>();
        mDustSmoke = transform.Find("DustSmoke").GetComponent<ParticleSystem>();

        mRigidbody.useGravity = false;//0627金田追記
        mDirSign = 0.0f;
        mPlayerMovePoint = transform.position /*- new Vector3(0, 0, PLAYER_MOVE_DISTANCE)*/;/*new Vector3(transform.position.x,transform.position.y,transform.position.z)*/
        mPlayerPosition = transform.position;
        mPlayerPosition.z += PLAYER_MOVE_DISTANCE;
        transform.position = mPlayerPosition;
        transform.rotation = Quaternion.LookRotation(Vector3.back);
        mAnimation.Run(true);
        //mBoxCol = GetComponent<BoxCollider>();
    }

    
    private void FixedUpdate()
    {

        //接地判定結果を格納
        mIsGrounded = GroundRayCast();


        #region      /*■■■■■gameState■■■■■*/
        switch (mGameState)
        {
            case GameState.Ready:
                float margin = 0.1f;//閾値
                if (mPlayerPosition.z <= mPlayerMovePoint.z + margin)
                {
                    mGameController.Play();
                    mAnimation.Run(false);
                }
                else
                {
                    mPlayerPosition = transform.position;
                    mPlayerPosition.z = Mathf.Lerp(mPlayerPosition.z, mPlayerMovePoint.z, Time.deltaTime / PLAYER_MOVE_TIME);
                    transform.position = mPlayerPosition;
                    transform.rotation = Quaternion.LookRotation(Vector3.back);
                }
                break;
            /*ゲームプレイ中*/
            case GameState.Play:
                /*カーテンを動かしている最中*/
                if (mCurtainState == CurtainState.Changing)
                {
                    mAnimation.Stop();
                    return;
                }
                /*カーテンが開いているまたは閉じている時*/
                else
                {
                    mAnimation.Play();
                }

                break;
            case GameState.Menu:
                mAnimation.Stop();
                break;

            case GameState.Success:
                /*クリア演出*/
                //正面を向く処理
                Turn(Vector3.back);
                mRigidbody.velocity = Vector3.zero;
                mRigidbody.useGravity = true;
                mAnimation.QuitAllAnimation();
                //mAnimation.Jump(false);
                //成功Animation
                mAnimation.Salute(true);

                return;

            case GameState.Failure:
                mAnimation.QuitAllAnimation();
                mAnimation.Dead(true);
                break;

            default: break;
        }
        #endregion       /*■■■■■■■■■■■■■*/


        if (mFreezePlayer)
        {
            mRigidbody.velocity = Vector3.zero;
            //接地かつ動いていない場合のアニメーション再生
            mAnimation.QuitAllAnimation();
            mAnimation.Idle(true);
            return;
        }

        /*Play中の処理*/
        if (mGameState != GameState.Play) { return; }


        Vector3 velocity = mRigidbody.velocity;

        //左右に動いてるか
        bool isLOrRInput = (mUserInput.LeftButton || mUserInput.RightButton);



        /*■■■■■PlayerState■■■■■*/
        switch (mPlayerState)
        {
            #region    /*◇◇◇◇◇地上◇◇◇◇◇*/
            case PlayerState.ON_GROUND:

                //入力があったとき自分の向いている方向を符号でmDIrSignに設定
                /*JUMP Stateとの都合でmDirSignの符号代入はON_GROUNDで行う*/
                if (mUserInput.RightButton) { mDirSign = RIGHT; }
                else if (mUserInput.LeftButton) { mDirSign = LEFT; }
                else
                {
                    //摩擦処理
                    velocity.x = velocity.x * DUMPING;
                }

                //入力があるとき左右に動く処理
                if (isLOrRInput)
                {
                    //音流す
                    if (mMoveAudioInterval <= mMoveAudioCounter)
                    {
                        AudioManager.Instance.PlaySe(SEAoudio.Instance.WalkSE);
                        mMoveAudioCounter = 0;
                    }
                    else
                    {
                        mMoveAudioCounter++;
                    }

                    Move(mDirSign);
                }

                //動いていた場合アニメーション再生
                mAnimation.Run(isLOrRInput);

                //振り向く処理
                Turn(Vector3.right * mDirSign);

                //向いている方向
                DirectionVectorCheck();

                //ジャンプする処理
                if (mIsGrounded)
                {
                    //ジャンプボタンを押している かつ ジャンプボタンを押し続けていたわけではない場合
                    if (mUserInput.JumpButton && !mIsJumpButtonPressing)
                    {
                        //Animation終了
                        mAnimation.Run(false);
                        mAnimation.Jump(false);
                        //State変更
                        mPlayerState = PlayerState.JUMP;

                        //ジャンプ音流す
                        AudioManager.Instance.PlaySe(SEAoudio.Instance.PlayerJumpSE);

                        mRigidbody.AddForce(mJumpForce);

                        mIsJumpButtonPressing = true;
                    }
                    //長押しで連続ジャンプできないようにする

                    /*ジャンプしている間mIsJumpButtonPressing は true
                      着地してユーザーがもうジャンプボタンを押していなければfalseを入れる*/

                    if (!mUserInput.JumpButton && mIsJumpButtonPressing) { mIsJumpButtonPressing = false; }
                }
                else { AddGravity(GRAVITY); }

                //接地かつ動いていない場合のアニメーション再生
                mAnimation.Idle(mIsGrounded && !isLOrRInput);
                break;
            #endregion

            #region       /*◇◇◇◇◇ジャンプ◇◇◇◇◇*/
            case PlayerState.JUMP:
                //関係のないアニメーションの停止
                mAnimation.Idle(false);
                mAnimation.Run(false);

                //アニメーション切り替え
                mAnimation.Jump(true);

                //ジャンプ時向いている方向と逆の入力があった場合力を弱くする処理
                if (mPlayerDirectionState == PlayerDirectionState.Right)
                {
                    if (mUserInput.RightButton) { mSensitivity = DEFAULT_SENSITIVITY; }
                    else { mSensitivity = JUMP_INVERSE_SENSITIVITY; }
                }
                else if (mPlayerDirectionState == PlayerDirectionState.Left)
                {
                    if (mUserInput.LeftButton) { mSensitivity = DEFAULT_SENSITIVITY; }
                    else { mSensitivity = JUMP_INVERSE_SENSITIVITY; }
                }

                //左右に動く処理
                /*OnGround State のときみたいにMove(mDirSign)と書けるようにする(ON_GROUND state の外にmDirSignの代入処理を書く)
                 * と空中で左右に振り向くことが可能になってしまう為個別でMoveを呼ぶ*/
                if (mUserInput.LeftButton) { Move(LEFT); }
                if (mUserInput.RightButton) { Move(RIGHT); }

                //重力処理
                AddGravity(GRAVITY);

                //ジャンプの大小を決める処理。確認してない
                // velocity.y = CheckJumpButtonTime(velocity.y);

                //左右に振り向く処理
                /*横に振り向きながらジャンプした場合へんな方向を向いた状態で硬直してしまうので
                 ON_GROUND stateのときに指定した符号の方向は向く*/
                Turn(Vector3.right * mDirSign);

                //接地している場合PlayerStateを変更
                if (mIsGrounded)
                {
                    //Particleの表示
                    mDustSmoke.Play();
                    //着地音
                    AudioManager.Instance.PlaySe(SEAoudio.Instance.WalkSE);
                    //Animationを終了
                    mAnimation.Jump(false);
                    //感度を元に戻す
                    mSensitivity = DEFAULT_SENSITIVITY;
                    //Stateを変更
                    mPlayerState = PlayerState.ON_GROUND;
                }

                break;
            #endregion

            #region /*◇◇◇◇◇掴む◇◇◇◇◇*/
            case PlayerState.GRAB:

                //左右に振り向く処理
                Turn(Vector3.right * mDirSign);
                mAnimation.Run(false);

                //if(mPlayerDirectionState == PlayerDirectionState.Middle)
                //{
                //    mAnimation.Grab(false);
                //    mAnimation.BackwardWalk(false);
                //    mAnimation.ForwardWalk(false);

                //    grabUI.MoveOff();
                //    mPlayerState = PlayerState.ON_GROUND;
                //}

                mAnimation.Grab(true);
                //スティックで左右に入力してねUIを表示
                grabUI.MoveOn();//金


                //掴む対象が上下に移動してしまっているかのチェック
                if (GrabObjectUpDownCheck())
                {
                    mAnimation.Grab(false);
                    mAnimation.BackwardWalk(false);
                    mAnimation.ForwardWalk(false);

                    grabUI.MoveOff();


                    /*Grabテレポーテンションバグ修正0614shinya*/
                    mMoveSwicth = false;


                    mPlayerState = PlayerState.ON_GROUND;


                    //0628tutiyama
                    break;
                }


                //動いていないときアニメーションを停止
                if (!mMoveSwicth)
                {
                    mAnimation.BackwardWalk(false);
                    mAnimation.ForwardWalk(false);

                    //入力がないかつ動いていない場合
                    if (!mUserInput.GrabButton)
                    {
                        mAnimation.Grab(false);
                        grabUI.MoveOff();
                        mPlayerState = PlayerState.ON_GROUND;
                        return;
                    }
                }

                /*最後まで移動してほしい処理　shinya */
                mTargetRigidbody.useGravity = !mMoveSwicth;

                //以下土

                /*
                 mMoveSwicth -> StartMoveでTrueになりMoveObjectでfalseになる。mMoveSwicthがtrueの時は自分とGrabObjectが移動している。
                 MoveOvject  -> falseになるまでちまちま進み続ける処理。 s
                 */
                if (mMoveSwicth)
                {
                    MoveObject();
                    return;
                }

                //落ちているかどうか１フレーム待たせるので0628tutiyama
                if (!mCanCheckGrabFrag)
                {
                    mCanCheckGrabFrag = true;

                    if (mPlayerDirectionState == PlayerDirectionState.Right)
                    {
                        //Playerが右を向いている状態で左に入力されたとき(引く) s
                        if (mUserInput.LeftButton)
                        {
                            //引くことが可能か確認する
                            if (PullCheck(-GrabMoveAmount))
                            {
                                mAnimation.BackwardWalk(true);
                            }
                        }
                        else if (mUserInput.RightButton)
                        {
                            if (PushCheck(GrabMoveAmount))
                            {
                                mAnimation.ForwardWalk(true);
                            }
                        }

                    }
                    else if (mPlayerDirectionState == PlayerDirectionState.Left)
                    {
                        if (mUserInput.LeftButton)
                        {
                            if (PushCheck(-GrabMoveAmount))
                            {
                                mAnimation.ForwardWalk(true);
                            }
                        }
                        else if (mUserInput.RightButton)
                        {
                            if (PullCheck(GrabMoveAmount))
                            {
                                mAnimation.BackwardWalk(true);
                            }
                        }
                    }
   
                    break;
                }

                /*以下現在自分の向いている方向を判定してその方向から押し引き(どちらかはuserInputで判定)が可能か判定する処理
                  以下の処理で一度StartMoveが呼ばれるとmMoveSwicthがfalseになる(引数分動く)までここに到達できません
                 
                 PullCheckの引数で渡した変数をStartMoveの引数で使わなくいいの? s*/
                if (mPlayerDirectionState == PlayerDirectionState.Right)
                {
                    //Playerが右を向いている状態で左に入力されたとき(引く) s
                    if (mUserInput.LeftButton)
                    {
                        //引くことが可能か確認する
                        if (PullCheck(-GrabMoveAmount))
                        {
                            GrabCantSEFragAllTrue();

                            //音流す
                            //AudioManager.Instance.PlaySe(SEAoudio.Instance.GrabMoveSE);

                            mAnimation.BackwardWalk(true);
                            //mMoveSwicthをtrueにする s
                            StartMove(-1f, 1f);
                        }
                        else
                        {
                            if (mLeftPullCantSE)
                            {
                                mLeftPullCantSE = false;

                                //音流す
                                AudioManager.Instance.PlaySe(SEAoudio.Instance.CantSE);
                            }

                        }
                    }
                    else if (mUserInput.RightButton)
                    {
                        if (PushCheck(GrabMoveAmount))
                        {
                            GrabCantSEFragAllTrue();

                            ////音流す
                            //AudioManager.Instance.PlaySe(SEAoudio.Instance.GrabMoveSE);

                            mAnimation.ForwardWalk(true);
                            StartMove(1f, 1f);
                        }
                        else
                        {
                            if (mRightPushCantSE)
                            {
                                mRightPushCantSE = false;

                                //音流す
                                AudioManager.Instance.PlaySe(SEAoudio.Instance.CantSE);
                            }
                        }
                    }

                }
                else if (mPlayerDirectionState == PlayerDirectionState.Left)
                {
                    if (mUserInput.LeftButton)
                    {
                        if (PushCheck(-GrabMoveAmount))
                        {
                            GrabCantSEFragAllTrue();

                            //AudioManager.Instance.PlaySe(SEAoudio.Instance.GrabMoveSE);

                            mAnimation.ForwardWalk(true);
                            StartMove(-1f, 1f);
                        }
                        else
                        {
                            if (mLeftPushCantSE)
                            {
                                mLeftPushCantSE = false;

                                //音流す
                                AudioManager.Instance.PlaySe(SEAoudio.Instance.CantSE);
                            }
                        }
                    }
                    else if (mUserInput.RightButton)
                    {
                        if (PullCheck(GrabMoveAmount))
                        {
                            GrabCantSEFragAllTrue();

                            //AudioManager.Instance.PlaySe(SEAoudio.Instance.GrabMoveSE);

                            mAnimation.BackwardWalk(true);
                            StartMove(1f, 1f);
                        }
                        else
                        {
                            if (mRightPullCantSE)
                            {
                                mRightPullCantSE = false;

                                //音流す
                                AudioManager.Instance.PlaySe(SEAoudio.Instance.CantSE);
                            }
                        }
                    }
                }
                //以上土
                break;
            #endregion

            default: break;
        }
        /*■■■■■■■■■■■■■■■*/
        //重力の速度制限
        velocity.y = Mathf.Clamp(velocity.y, -MAX_FALL_SPEED, MAX_RISING_SPEED);

        mRigidbody.velocity = velocity;
    }



    private void Update()
    {
        if (mGameState == GameState.Success) { return; }
        if (mGameState == GameState.Ready) { return; }//0627 s
        OverlapStateCheck();
        UpdateWhileChanging();
        ReturnStateCheck();
    }



    private void OnCollisionStay(Collision collision)
    {
        //mAnimation.Jump(false);

        //角度を絶対座標にする処理
        //BlockMoveのときに親子関係にするなら必要
        if (transform.parent)
        {
            Vector3 eulerAng = transform.eulerAngles;
            eulerAng.z = 0.0f;
            eulerAng.x = 0.0f;
            transform.rotation = Quaternion.Euler(eulerAng);
        }


        //以下Grab関連の処理

        //空中の場合返す
        if (!mIsGrounded) { return; }
        //float harfHeight = mSize.y / 2;

        //20180617 
        //カーテンが動いている場合返す
        if (mCurtainState == CurtainState.Changing) { return; }

        float harfHeight = mCapCol.height / 2.0f;
        // float harfHeight = mBoxCol.size.y / 2.0f;

        ////足元の座標
        float foot = transform.position.y + mCapCol.center.y - harfHeight;
        // float foot = transform.position.y + mBoxCol.center.y - harfHeight;
        ////頭頂部の座標
        float head = transform.position.y + mCapCol.center.y + harfHeight;
        //float head = transform.position.y + mBoxCol.center.y + harfHeight;


        foreach (ContactPoint contact in collision.contacts)
        {
            //衝突位置が脚と頭の間の場合(横)
            //足元にGrabがある場合も反応してしまう為
            if (contact.point.y > foot + 0.1f && contact.point.y < head)
            {
                //横がGrabObjectでないといけない
                //衝突相手がGrabだった場合trueを入れてもらう
                if (mGrabCol == false) { return; }

                //一度掴んでから出ないと動かない(Grab入力を入れながらGrabObjectに衝突しても掴まない)
                //bool moveInput = mUserInput.LeftButton || mUserInput.RightButton;

                //逆入力を入れた瞬間にGrabButtonを押したとき回転しながら引くバグ回避
                //移動しているがGrabを押していない場合
                //if (moveInput)
                //{
                //grabUI.GrabOff();
                //return;
                //}
                //else
                //{
                //Grabの上に立っていない(階段状のGrab対策)

                if (mPlayerDirectionState == PlayerDirectionState.Middle) { return; }
                if (null == hitInfo.collider.gameObject.GetComponent<GrabObject>())
                {
                    grabUI.GrabOn();
                }
                //}
                if (mUserInput.GrabButton) { StartGrabCheck(collision.gameObject); }
            }
        }
    }



    #region Gizmosメソッド
    /*■■■■■exeにするとき消す■■■■■*/
    [SerializeField]
    private Color mGroundRayColor = Color.white;

    private float GizmosFoot;
    private float GizmosHead;
    private void OnDrawGizmos()
    {
        GroundCastGizmos();

        Vector3 center = new Vector3(transform.position.x + 0.95f, transform.position.y + checkBoxYPos, transform.position.z);
        Vector3 center2 = new Vector3(transform.position.x - 0.95f, transform.position.y + checkBoxYPos, transform.position.z);
        Vector3 size = new Vector3(checkBoxSideX, checkBoxSideY, checkBoxSideZ) * 2;
        Vector3 groundCheckCenter = new Vector3(transform.position.x + groundCheckBoxXPos, transform.position.y + groundCheckBoxYPos, transform.position.z);
        Vector3 groundCheckBoxSize = new Vector3(groundCheckBoxOneSide, groundCheckBoxOneSide, groundCheckBoxOneSide);

        Gizmos.DrawWireCube(groundCheckCenter, groundCheckBoxSize);
        Gizmos.DrawCube(center, size);
        Gizmos.DrawCube(center2, size);

        //横判定領域(実行中のみ表示)
        //if (mBoxCol == null) { return; }
        //float harfHeight = mBoxCol.size.y / 2.0f;
        //Vector3 footPos = transform.position;
        //Vector3 headPos = transform.position;

        //////足元の座標
        ////float foot = transform.position.y + mCapCol.center.y - harfHeight;
        //footPos.y = transform.position.y + mBoxCol.center.y - harfHeight;
        //////頭の座標
        ////float head = transform.position.y + mCapCol.center.y + harfHeight;
        //headPos.y = transform.position.y + mBoxCol.center.y + harfHeight;

        Gizmos.color = Color.blue;
        //Gizmos.DrawLine(footPos, headPos);
    }


    /// <summary>
    /// 接地判定用ray
    /// </summary>
    private void GroundCastGizmos()
    {
        Gizmos.color = mGroundRayColor;
        //    Gizmos.DrawWireSphere((transform.position + mGroundRayOffset) + (Vector3.down * mGroundRayDistance), mSpheCastRadius);
        Gizmos.DrawWireCube((transform.position + mGroundRayOffset) + (Vector3.down * mGroundRayDistance), mBoxCastSize);
    }
    /*■■■■■■■■■■■■■■■■■■*/
    #endregion

    //0627コメントアウト金田
    //private void Initialize()
    //{
    //    mRigidbody.useGravity = false;
    //    Turn(Vector3.back);
    //    mDirSign = RIGHT;    //PlayStateで最初に向く方向
    //}



    #region Moveメソッド
    /// <summary>
    /// 左右に動く処理。-が左,+が右
    /// AddForceする
    /// </summary>
    /// <param name="dirSign"></param>
    private void Move(float dirSign)
    {
        //範囲外の値入力を防止
        dirSign = dirSign < 0.0f ? LEFT : RIGHT;
        //MAXSPEEDに達した場合AddForceの量が0になる
        float xPow = (mSensitivity * dirSign) * (MAX_SPEED - (dirSign * mRigidbody.velocity.x));
        mRigidbody.AddForce(xPow, 0.0f, 0.0f);
    }



    /// <summary>
    /// 単位ベクトルの方向を向く処理
    /// Rotation をSlerpしてる。
    /// </summary>
    /// <param name="direction"></param>
    private void Turn(Vector3 direction)
    {
        //単位ベクトルでない場合正規化する処理
        if (Mathf.Approximately(Vector3.SqrMagnitude(direction), 0.0f)){ return; }//s
        if (direction.sqrMagnitude > 1.0f) { direction = direction.normalized; }
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), Time.deltaTime * TURN_SPEED);

    }
    #endregion

    #region jumpメソッド
    /// <summary>
    /// 下方向に力を加える処理。scale:重力の大きさ
    /// </summary>
    private void AddGravity(float scale)
    {
        mRigidbody.AddForce(Vector3.down * scale, ForceMode.Acceleration);
    }



    /// <summary>
    /// 接地判定用
    /// </summary>
    /// <returns></returns>
    private bool GroundRayCast()//変えます
    {

        mGroundRay.origin = transform.position + mGroundRayOffset;
        Vector3 harfSize = mBoxCastSize / 2.0f;
        return Physics.BoxCast(transform.position + mGroundRayOffset, harfSize, Vector3.down, out hitInfo, transform.rotation, mGroundRayDistance);
        //Sphere
        //return Physics.SphereCast(mGroundRay, mSpheCastRadius, out hitInfo, mGroundRayDistance);
    }



    /// <summary>
    /// ジャンプの大小を決める処理
    /// </summary>
    /// <param name="velY"></param>
    /// <returns></returns>
    private float CheckJumpButtonTime(float velY)
    {
        if (mUserInput.JumpButton)
        {
            mJumpTimer += Time.deltaTime * 15.0f;
        }
        else if (!mUserInput.JumpButton && velY > 0)
        {
            float dumping = Mathf.Clamp(mJumpTimer, 0.9f, 1.0f);
            velY *= dumping;
        }
        else
        {
            mJumpTimer = 0.0f;
        }
        return velY;
    }
    #endregion

    #region Grabメソッド
    private GameObject target;



    private const float CHECK_BOX_ONE_SIDE = 0.49f;

    [SerializeField]
    private float checkBoxSideX = 0.2f;
    [SerializeField]
    private float checkBoxSideY = 0.9f;
    [SerializeField]
    private float checkBoxSideZ = 0.2f;


    [SerializeField]
    private float checkBoxYPos = 0.45f;


    [SerializeField]
    private float groundCheckBoxYPos = -0.3f;
    [SerializeField]
    private float groundCheckBoxXPos = 1.25f;
    [SerializeField]
    private float groundCheckBoxOneSide = 0.5f;


    [SerializeField]
    private float GrabMoveAmount = 1.0f;
    private GameObject mGrabTarget;
    private Rigidbody mTargetRigidbody;
    private GrabObject mTargetGrabObject;
    private BoxCollider mBoxCollider;


    public enum PlayerDirectionState { Left, Middle, Right }
    public PlayerDirectionState mPlayerDirectionState;


    private bool mMoveSwicth = false;
    private float mRemainingMoveAmount;
    private float mRemainingMoveTime;
    private Vector3 mSaveGoalPos;
    private Vector3 mTargetGoalPos;
    [SerializeField]
    private float mPermissionPoint;

    [SerializeField]
    private float mgrabFallThreshold = 0.1f; //掴んでいるものが落ちた時に使用するしきい値
                                             //    private bool mgrabFallCheck = false; //掴んでいるものが落ちたかどうか

    //以下土

    /// <summary>
    /// つかめるかの判定(つかめたらTrue、つかめないならFalse)

    /// </summary>
    /// <param name="obj">つかむ対象</param>
    private void StartGrabCheck(GameObject obj)
    {
        /*
             引数で受け取ったGameObjectがGrabObjectを持っていた場合Stateを変更する。
             連続で同じGameObjectが渡された時GetComponentが走るのが無駄な為ローカル変数に
             直近で取得したGrabObjectとRigidbodyは保持する。既に保持していた場合はGetComponentを行わない。 s
         */

        //つかむ対象がつかめるオブジェクトだったら s
        if (obj.GetComponent<GrabObject>())
        {
            //その対象が前回つかんでいたものではない場合 s
            if (obj != mGrabTarget)
            {
                //対象の更新
                mGrabTarget = obj;

                //対象のGrabObjectの更新
                mTargetGrabObject = obj.GetComponent<GrabObject>();

                //対象のRigidbodyの更新
                mTargetRigidbody = mGrabTarget.GetComponent<Rigidbody>();

            }

            //PlayerStateをGrab状態に変える
            mPlayerState = PlayerState.GRAB;
        }
    }

    /// <summary>
    /// OnCollisionEnterしたのがPlayerだった場合True s
    /// OnCollisionExitしたのがPlayerだった場合false s
    /// </summary>
    /// <param name="frag"></param>
    public void GrabColChange(bool frag)//金田追記GrabObjectに触れているかどうか(GrabObjectから呼び出す)
    {
        mGrabCol = frag;
    }



    //1.0size用
    ///// <summary>
    ///// 押せるかのチェック(押せるのならTrue、押せないならFalse)
    ///// </summary>
    ///// <param name="amount">移動量</param>
    //private bool PushCheck(float amount)
    //{
    //    return mTargetGrabObject.TargetPushCheck(amount);
    //}



    //1.5size用
    /// <summary>
    /// 押せるかのチェック(押せるのならTrue、押せないならFalse)
    /// </summary>
    /// <param name="amount">移動量</param>
    private bool PushCheck(float amount)
    {
        /*CheckBox(Collisionとの衝突判定処理)を対象のGrabObjectをTriggerにした状態で
         * 自分の移動予定先に作成し何かとCollisionした場合falseを返す。
         * もし何とも衝突しなかった場合はGrabObjectが移動可能かを確認し返す s
         */

        //CheckBoxに使用する変数の作成 s

        //自分の移動予定先に作成するCheckBoxの中心を定義 s
        Vector3 center = new Vector3(transform.position.x + amount, transform.position.y + checkBoxYPos, transform.position.z);
        //何かを基に作成された値を使用しCheckBoxの大きさを定義 s
        Vector3 size = new Vector3(checkBoxSideX, checkBoxSideY, checkBoxSideZ);
        //恐らく接地判定用のCheckBoxの中心を定義 s
        Vector3 groundCheckCenter = new Vector3(transform.position.x + amount, transform.position.y + groundCheckBoxYPos, transform.position.z);
        //CheckBoxの大きさを謎の数値を基に作成 s
        Vector3 groundCheckBoxSize = Vector3.one * groundCheckBoxOneSide;

        //CheckBox(Colliderとの衝突判定処理)が対象のGrabObjectが持っているColliderに衝突するのを避ける為Triggerにする s
        mTargetGrabObject.TargetTriggerSet(true);

        //BoxCastが衝突 "しなかった" 場合 -> 自分の移動予定先に障害物が存在しない場合 s
        bool canMove = !Physics.CheckBox(center, size / 2f, Quaternion.identity, -1, QueryTriggerInteraction.Ignore);//s
        //BoxCastによる自分の接地判定 s
        bool isGround = Physics.CheckBox(groundCheckCenter, groundCheckBoxSize / 2, Quaternion.identity, -1, QueryTriggerInteraction.Ignore);//s


        if (canMove && isGround)
        {
            //以下"自分"がGrabObjectを操作できる状態である場合の処理 s

            //CheckBoxを用いた確認が終了した為Collisionに戻す s
            mTargetGrabObject.TargetTriggerSet(false);

            //ターゲットの押し引きチェック   
            //if (mTargetGrabObject.TargetPullPushCheck(amount))
            //{
            //    return true;
            //}
            //else
            //{
            //    return false;
            //}

            //s
            bool grabObjCanMove = mTargetGrabObject.TargetPullPushCheck(amount);
            return grabObjCanMove;


        }
        else
        {
            //自分が移動不可能な為GrabObjectをCollisionに戻す s
            mTargetGrabObject.TargetTriggerSet(false);

            return false;
        }
    }



    //1.0用
    ///// <summary>
    ///// 引けるのかのチェック（引けるならTrue、引けないならFalse）
    ///// </summary>
    ///// <param name="amount">移動量</param>
    ///// <returns></returns>
    //private bool PullCheck(float amount)
    //{
    //    Vector3 center = new Vector3(transform.position.x + amount, transform.position.y, transform.position.z);
    //    Vector3 size = new Vector3(CHECK_BOX_ONE_SIDE, CHECK_BOX_ONE_SIDE, CHECK_BOX_ONE_SIDE);

    //    mTargetGrabObject.TargetTriggerSet(true);

    //    //自分の後ろに障害物があるかないか
    //    if(!Physics.CheckBox(center, size, Quaternion.identity, -1, QueryTriggerInteraction.Ignore))
    //    {
    //        mCollider.isTrigger = true;

    //        //動かす対象の後ろに障害物がないかどうか
    //        if (mTargetGrabObject.TargetPullCheck(amount))
    //        {
    //            mCollider.isTrigger = false;
    //            return true;
    //        }
    //        else
    //        {
    //            mCollider.isTrigger = false;
    //            return false;
    //        }
    //    }
    //    else
    //    {
    //        return false;
    //    }
    //}



    //1.5用
    /// <summary>
    /// 引けるのかのチェック（引けるならTrue、引けないならFalse）
    /// </summary>
    /// <param name="amount">移動量</param>
    /// <returns></returns>
    private bool PullCheck(float amount)
    {
        Vector3 center = new Vector3(transform.position.x + amount, transform.position.y + checkBoxYPos, transform.position.z);
        Vector3 size = new Vector3(checkBoxSideX, checkBoxSideY, checkBoxSideZ);
        Vector3 groundCheckCenter = new Vector3(transform.position.x + Mathf.Sign(amount) * groundCheckBoxXPos, transform.position.y + groundCheckBoxYPos, transform.position.z);
        Vector3 groundCheckBoxSize = new Vector3(groundCheckBoxOneSide, groundCheckBoxOneSide, groundCheckBoxOneSide);

        mTargetGrabObject.TargetTriggerSet(true);

        //入らないS->障害物があることになっている

        //自分の後ろに障害物があるかないか
        if (!Physics.CheckBox(center, size / 2, Quaternion.identity, -1, QueryTriggerInteraction.Ignore) && Physics.CheckBox(groundCheckCenter, groundCheckBoxSize / 2, Quaternion.identity, -1, QueryTriggerInteraction.Ignore))
        {
            mCapCol.isTrigger = true;

            //動かす対象の後ろに障害物がないかどうか
            if (mTargetGrabObject.TargetPullPushCheck(amount))
            {
                mCapCol.isTrigger = false;
                
                return true;
            }
            else
            {
                mCapCol.isTrigger = false;

                return false;
            }
        }
        else
        {
            mTargetGrabObject.TargetTriggerSet(false);
            return false;
        }
    }



    /// <summary>
    /// grabに使用する。角度で判定する方法
    /// 現在使用していません20180614 sinya
    /// </summary>
    private void DirectionAngleCheck()
    {
        Vector3 EulerAngles = transform.eulerAngles;
        if (EulerAngles.y < 180.0f)
        {
            if (mPlayerDirectionState == PlayerDirectionState.Right) { return; }
            mPlayerDirectionState = PlayerDirectionState.Right;
        }
        else
        {
            if (mPlayerDirectionState == PlayerDirectionState.Left) { return; }
            mPlayerDirectionState = PlayerDirectionState.Left;
        }
    }

    /// <summary>
    /// 入力で向いている方向を判断する
    /// </summary>
    private void DirectionCheck()
    {
        if (mUserInput.RightButton)
        {
            if (mPlayerDirectionState == PlayerDirectionState.Right) { return; }
            mPlayerDirectionState = PlayerDirectionState.Right;
        }
        else if (mUserInput.LeftButton)
        {
            if (mPlayerDirectionState == PlayerDirectionState.Left) { return; }
            mPlayerDirectionState = PlayerDirectionState.Left;
        }
    }

    private void DirectionVectorCheck()
    {
        float forward = transform.forward.x;

        if (forward > 0.99f)
        {
            if (mPlayerDirectionState == PlayerDirectionState.Right) { return; }
            mPlayerDirectionState = PlayerDirectionState.Right;
        }
        else if (forward < -0.99f)
        {
            if (mPlayerDirectionState == PlayerDirectionState.Left) { return; }
            mPlayerDirectionState = PlayerDirectionState.Left;
        }
        else
        {
            if (mPlayerDirectionState == PlayerDirectionState.Middle) { return; }
            mPlayerDirectionState = PlayerDirectionState.Middle;
        }
    }




    //------------------------------------------------------

    /// <summary>
    /// 押し引きをさせる
    /// 移動量、移動時間、自分の目標位置、GrabObjectの目標位置を作成し、mMoveSwitchをtrueする処理(移動の準備)
    /// </summary>
    /// <param name="moveAmount">移動量</param>
    /// <param name="moveTime">移動時間</param>
    public void StartMove(float moveAmount, float moveTime)
    {
        //音流す
        AudioManager.Instance.PlaySe(SEAoudio.Instance.GrabMoveSE);

        //移動量を更新
        mRemainingMoveAmount = moveAmount;

        //移動時間を更新
        mRemainingMoveTime = moveTime;

        //目標のPositionを設定
        mSaveGoalPos = new Vector3(this.transform.position.x + moveAmount, this.transform.position.y, this.transform.position.z);
        mTargetGoalPos = new Vector3(mGrabTarget.transform.position.x + moveAmount, mGrabTarget.transform.position.y, mGrabTarget.transform.position.z);

        //移動中スイッチをONにする
        mMoveSwicth = true;
    }






    /// <summary>
    /// 移動させる
    /// </summary>
    private void MoveObject()
    {
        //残り時間がmPermissionPoint以上かどうか mPermissionPointを0以外にする場面っていつ s
        if (mRemainingMoveTime >= mPermissionPoint)
        {
            //次の移動量
            float moveAmount = mRemainingMoveAmount * Time.deltaTime / mRemainingMoveTime;

            //自分と対象を移動
            this.transform.position = new Vector3(this.transform.position.x + moveAmount, this.transform.position.y, this.transform.position.z);
            mGrabTarget.transform.position = new Vector3(mGrabTarget.transform.position.x + moveAmount, mGrabTarget.transform.position.y, mGrabTarget.transform.position.z);

            //残り移動時間を更新
            mRemainingMoveTime -= Time.deltaTime;

            //残り移動量を更新
            mRemainingMoveAmount -= moveAmount;
        }
        else
        {
            //移動中を解除
            mMoveSwicth = false;

            //目標のPositionに移動
            this.transform.position = mSaveGoalPos;
            mGrabTarget.transform.position = mTargetGoalPos;

            //0628tuti
            mCanCheckGrabFrag = false;

            // print("mTargetGoalPos" + mTargetGoalPos);
            //print("mGarbTarget" + mGrabTarget.transform.position);
        }
    }


    /// <summary>
    ///対象のY座標の加速度がしきい値より大きかったら
    /// </summary>
    private bool GrabObjectUpDownCheck()
    {

        if (Mathf.Abs(mTargetRigidbody.velocity.y) > mgrabFallThreshold)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// グラブ失敗用SEの再生フラグをすべてTrueにする
    /// </summary>
    private void GrabCantSEFragAllTrue()
    {
        mRightPullCantSE = true;
        mRightPushCantSE = true;
        mLeftPullCantSE = true;
        mLeftPushCantSE = true;
    }
    #endregion

    /// <summary>
    /// Playerの落下速度を取得する
    /// </summary>
    /// <returns></returns>
    //public float GetFallSpeed()
    //{
    //    return mRigidbody.velocity.y;
    //}

    /// <summary>
    /// プレイヤーの動きを止めるまたは動かす
    /// </summary>
    /// <param name="state">True＝止まる、False＝動く</param>
    public void FreezePlayer(bool state)
    {
        mFreezePlayer = state;
    }
}
#region メモ
/*
    Colliderに躓く処理

 Grabできない->Colliderのcenter y とsize y を調節してみる
 boxcol
 size 0.28,1.05,0.34
 center 0,0.55,0

    ジャンプしている間後ろを向く 済
    ->回転する処理がJump中働いていなかったため

    高所落下で貫通する           済
    ->降下速度が速すぎたため

    掴んだ状態になりgrabObjectがすり抜ける    済
      ->2で割ったら動いた。
      ->以前何故動いていたか不明

    スイッチ押せない
    ->接触はしている
    ->重力が0の為の可能性

    引いてPlayerが落下したときanimation変わらない  済
    ->animationを切っていなかった
    ->returnしていなかった

    押してgrabobjを落下させたときanimation変わらない  済
    ->animationを切っていなかった
    ->returnしていなかった

    躓くかも知れない
    ->躓くわ

    動くオブジェクトがずれる


    頭が大きくなるバグ
    ->動く床の大きさ変えたら直った

    初期状態が正面向いていない場合 済
    Initialize()に書いた
    始まった瞬間後ろ向きよる

    PlayerAnimatorの変更 済
    Mono消した
*/
#endregion