﻿public enum GameState
{
    Ready,
    Play,
    Menu,
    Success,
    Failure
}

public enum CurtainState
{
    Open,
    Changing,
    Close,
    STOP
}

public enum DeathPattern//死亡パターン
{
    Stabbing, FallingDeath,
}