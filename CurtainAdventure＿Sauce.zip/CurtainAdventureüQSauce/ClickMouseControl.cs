﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ClickMouseControl : MonoBehaviour
{
    private GameObject mOldSelectButton;

    private void Update()
    {
        if (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1) || Input.GetMouseButtonDown(2))
        {
            if (mOldSelectButton != null)
            {
                EventSystem.current.SetSelectedGameObject(mOldSelectButton);
            }
        }
        else
        {
            if (EventSystem.current.currentSelectedGameObject != null)
            {
                mOldSelectButton = EventSystem.current.currentSelectedGameObject;
            }
        }
    }
}
