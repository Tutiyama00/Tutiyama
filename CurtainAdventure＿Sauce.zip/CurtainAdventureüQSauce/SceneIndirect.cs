﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneIndirect : MonoBehaviour {//SceneLoadingとSceneのやり取りの補佐をする
    SceneLoading MasterSceneController;
	// Use this for initialization
	void Awake () {
        MasterSceneController = GameObject.FindObjectOfType<SceneLoading>();
        MasterSceneController.StartCoroutine("FedeIn");
    }
    private void Start()
    {
        MasterSceneController.UIfalse();
    }
    //SceneLoadingへ命令を渡す
    public void Transmission(string scene)
    {
        MasterSceneController.SceneChange(scene);
    }
}
