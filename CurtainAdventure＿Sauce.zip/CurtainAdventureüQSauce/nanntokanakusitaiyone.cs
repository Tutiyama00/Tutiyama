﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;
using UnityEngine.UI;

public class nanntokanakusitaiyone : MonoBehaviour {//ボタンを初期選択するだけなんとかなくしたいよね
    EventSystem mEventSystem;
    // Use this for initialization
    void Start () {
    }
    private void OnEnable()
    {
        mEventSystem = FindObjectOfType<EventSystem>();
        mEventSystem.SetSelectedGameObject(null);
        mEventSystem.SetSelectedGameObject(gameObject);
    }
}
