﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialFirstStageChange : MonoBehaviour
{
    [SerializeField]
    private string mNextStageName = "null"; //次のステージの名前
    [SerializeField]
    private bool mEndStageFrag = false; //最後のステージなのかどうか
    private const string mGoalTrigger = "Goal";//アニメーショントリガーの名前
    //何度も呼ばれるバグを避けるため、一回しか呼ばれないようにするのに使うフラグ
    private bool mOnce;

    private int mStageNamber;   //ステージの番号
    private int mTutorialDefaultPoint = 3;　　//チュートリアルステージのランクポイントを３にするため

    private ScoreDate mScoreDate;
    private GameObject mPlayer;
    private SceneLoading mSceneLoading;
    private PlayerCollisionEvent mPlayerCollisionEvent;
    private Animator mAnime;
    private void Start()
    {
        //アニメーターとったで
        mAnime = GetComponent<Animator>();

        //ScoreDateの取得
        mScoreDate = GameObject.FindObjectOfType<ScoreDate>();

        //ステージ番号を取得
        mStageNamber = GameObject.FindObjectOfType<GameController>().Stage;

        //SceneLoadingの取得
        mSceneLoading = GameObject.FindObjectOfType<SceneLoading>();

        //Playerを取得(PlayerがPlayerMoveを持っていると想定)
        mPlayer = GameObject.FindObjectOfType<PlayerMove>().gameObject;

        //PlayerCollisionEventの取得
        mPlayerCollisionEvent = GameObject.FindObjectOfType<PlayerCollisionEvent>();

        mOnce = false;
    }


    private void OnTriggerEnter(Collider collider)
    {
        //1回呼ばれている
        if (mOnce) { return; }
        //ぶつかったのがPlayerなのかどうか
        if(collider.gameObject == mPlayer)
        {
            //1回呼んだ
            mOnce = true;
            //チュートリアル最後のステージかどうか
            if (mEndStageFrag)
            {
                mPlayerCollisionEvent.PointGet(mTutorialDefaultPoint);
                mPlayerCollisionEvent.Goal();
                mAnime.SetTrigger(mGoalTrigger);
            }
            else
            {
                TutorialDateSave();
                mSceneLoading.SceneChange(mNextStageName);
            }
            
        }
        
    }

    /// <summary>
    /// チュートリアル用データを保存する
    /// </summary>
    private void TutorialDateSave()
    {
        mScoreDate.DateUpdate(mStageNamber, mTutorialDefaultPoint);
    }
    public void StageClear()
    {
       mPlayerCollisionEvent.GameClear();
    }

}
