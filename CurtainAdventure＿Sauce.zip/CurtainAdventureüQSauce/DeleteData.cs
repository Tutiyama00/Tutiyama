﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class DeleteData : EditorWindow
{

    [MenuItem("Custom/ResetPlayerPrefs'sData")]
    private static void ResetData()
    {
       Reset();
    }


    private static void Reset()
    {
        PlayerPrefs.DeleteAll();
    }
}
