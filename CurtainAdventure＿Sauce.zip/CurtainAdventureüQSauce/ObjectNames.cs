﻿public static class ObjectNames
{
    public const string PLAYER = "Player";
    public const string READY = "Ready";
    public const string PLAY = "Play";
    public const string TITLE = "TitleScene";
    public const string MENU = "Menu";
    public const string SUCCESS = "Success";
    public const string FAILURE = "Failure";
    public const string SCRIPTS = "Scripts";
    public const string STAR1= "Star1";
    public const string STAR2 = "Star2";
    public const string STAR3= "Star3";
    public const string STAGEIMAGE = "StageImage";
    public const string GRABHOLD = "GrabHold";
    public const string GRABMOVE = "GrabMove";
    public const string UICAMERA = "UI Camera";
    public const string BESECANVAS = "BaseCanvas";
}
