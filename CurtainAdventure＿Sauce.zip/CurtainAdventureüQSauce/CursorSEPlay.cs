﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class CursorSEPlay : MonoBehaviour
{

    private void Awake()
    {
        AddDeSelect();
    }

    /// <summary>
    /// DeSelectの追加
    /// </summary>
    private void AddDeSelect()
    {
        if (!this.gameObject.GetComponent<EventTrigger>())
        {
            EventTrigger currentTrigger = this.gameObject.AddComponent<EventTrigger>();
            currentTrigger.triggers = new List<EventTrigger.Entry>();
            //↑ここでAddComponentしているので一応、初期化しています。

            EventTrigger.Entry entry = new EventTrigger.Entry();
            entry.eventID = EventTriggerType.Deselect; //PointerClickの部分は追加したいEventによって変更してね
            entry.callback.AddListener((x) => SEPlay());  //ラムダ式の右側は追加するメソッドです。

            currentTrigger.triggers.Add(entry);
        }
    }

    /// <summary>
    /// SEを流す
    /// </summary>
    private void SEPlay()
    {
        AudioManager.Instance.PlaySe(SEAoudio.Instance.CursorMoveSE);
    }
}
