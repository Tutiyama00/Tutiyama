﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialImage : MonoBehaviour
{
    private RectTransform mrectTransform;

    [SerializeField]
    private float growingAmount = 0.1f;

    private Vector3 growingVec3;

    private Vector3 mimageSize;

    [SerializeField]
    private float Threshold = 0.9f; //しきい値
    private float ThresholdX;
    private float ThresholdY;


    private bool mstartCheck = false;　//スタートの準備中かのフラグ
    private bool mcanImage = false;　　//イメージのスタート準備が完了しているかのフラグ
    public bool mCanImage { get { return mcanImage; } }

    //-------------------------------------------------

    private void Awake()
    {
        //自分のRectTransformを取得
        mrectTransform = this.GetComponent<RectTransform>();

        //自分の最初のサイズを取得
        mimageSize = mrectTransform.localScale;

        //自分のスケールをゼロにする
        mrectTransform.localScale = Vector3.zero;

        //増加させる用のVector3型変数の作成
        growingVec3 = new Vector3(growingAmount, growingAmount, growingAmount);

        //しきい値の設定
        ThresholdX = mimageSize.x - Threshold;
        ThresholdY = mimageSize.y - Threshold;
    }

    private void Update()
    {
        if (mstartCheck)
        {
            //今の自分のXスケールかYスケールがしきい値以上かどうか
            if(mrectTransform.localScale.x > ThresholdX || mrectTransform.localScale.y > ThresholdY)
            {
                mstartCheck = false;

                //自分のスケールを目標サイズにする
                mrectTransform.localScale = mimageSize;

                //イメージの出現が完了したとフラグを立てる
                mcanImage = true;
            }
            else
            {
                //自分のスケールを増加分増やす
                mrectTransform.localScale += growingVec3;
            }
        }
    }

    //------------------------------------------------

    /// <summary>
    /// テキスト用のイメージを出現させる
    /// </summary>
    public void ImageStart()
    {
        //StartCheckをTrue
        mstartCheck = true;
    }
}
