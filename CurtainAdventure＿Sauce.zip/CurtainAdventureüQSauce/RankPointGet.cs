﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RankPointGet : MonoBehaviour {//評価点を増加させるクラス、メダル的なやつにつける
    private const string GET = "Get";
    private PlayerCollisionEvent mCollisionEvent;
    private GameObject mPlayer;
    private Animator mDiamondAnime;
    private bool one;

    //tutiyama0626
    private BoxCollider[] mBoxCollider_array;

    [SerializeField]
    int point;//オブジェクトで得られるポイント
	// Use this for initialization
	void Start () {
        one = false;
        mPlayer = GameObject.Find(ObjectNames.PLAYER);
        mDiamondAnime = GetComponent<Animator>();
        mCollisionEvent = mPlayer.GetComponent<PlayerCollisionEvent>(); ;
        mBoxCollider_array = this.GetComponents<BoxCollider>();
	}
    private void OnTriggerEnter(Collider ather)
    
    {
        if (one) { return; }
        if (ather.gameObject == mPlayer)
        {
            BoxColliderAllOff();
            RigidbodyOff();

            //音流す
            AudioManager.Instance.PlaySe(SEAoudio.Instance.PointGetSE);
            mCollisionEvent.PointGet(point);
            mDiamondAnime.SetTrigger(GET);
        }
        //後に後処理の実装
    }
    public void Activefalse()
    {
        gameObject.SetActive(false);
    }

    private void BoxColliderAllOff()
    {
        foreach(BoxCollider bcol in mBoxCollider_array)
        {
            bcol.enabled = false;
        }
    }

    private void RigidbodyOff()
    {
        if (GetComponent<Rigidbody>())
        {
            GetComponent<Rigidbody>().isKinematic = true;
        }
    }
}
