﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using RedBlueGames.Tools.TextTyper;

public class TutorialText : MonoBehaviour
{
    [SerializeField]
    private string[] text_array; //テキストの内容を入れる

    private int marrayPointer = 0;  //配列用のポインター
    public int mArrayPointer { get { return marrayPointer; } }

    private TextTyper mtextTyper; //自分のTextTyper

    private bool StartCheck = false;

    private float mNextTextInterval = 3.0f;  //二個目のテキストの変化間隔

    //----------------------------------------------

    private void Awake()
    {
        //自分のTextTyperの取得
        mtextTyper = GetComponent<TextTyper>();
    }

    private void Update()
    {
        if (StartCheck)
        {
            if (!mtextTyper.IsTyping)
            {
                StartCheck = false;
                StartCoroutine("SecondTextStart");
            }
        }
    }

    //---------------------------------------------

    /// <summary>
    /// 一個目のテキストを流す
    /// </summary>
    public void TextStart()
    {
        marrayPointer = 0;

        mtextTyper.TypeText(text_array[marrayPointer]);

        StartCheck = true;
    }

    /// <summary>
    /// 二個目のテキストを流す
    /// </summary>
    /// <returns></returns>
    private IEnumerator SecondTextStart()
    {
        yield return new WaitForSeconds(mNextTextInterval);

        //すでに次のテキストに移ってしまっているのかどうか
        if (marrayPointer == 0)
        {
            marrayPointer = 1;

            mtextTyper.TypeText(text_array[marrayPointer]);
        }
    }

    /// <summary>
    /// テキストを変える
    /// </summary>
    public void TextChange(int textNamber)
    {
        //指定されたテキストが存在するのかどうか
        if(textNamber >= text_array.Length)
        {
            return;
        }

        //今テキストが流れている状態かどうか
        if (!mtextTyper.IsTyping)
        {
            //ポインタの更新
            marrayPointer = textNamber;
            //指定のテキストを流す
            mtextTyper.TypeText(text_array[textNamber]);
        }
        else
        {
            //今流れているテキストをスキップ
            mtextTyper.Skip();

            //ポインタの更新
            marrayPointer = textNamber;
            //指定のテキストを流す
            mtextTyper.TypeText(text_array[textNamber]);
        }
    }

    /// <summary>
    /// 文字を出したときの音
    /// </summary>
    public void AudioPlay()
    {
        AudioManager.Instance.PlaySe(SEAoudio.Instance.TextTypeSE);
    }

    public void Stop()
    {
        mtextTyper.Stop();
    }

    public void ReStart()
    {
        mtextTyper.Restart();
    }


}
