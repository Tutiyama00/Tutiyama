﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*コライダーをカーテンにあわせて伸ばす処理。
 　ユーザからみて奥にあるブロックには大体アタッチします。

   BackObstacle用の長いColliderの付いているオブジェクトにアタッチします!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  */


//[RequireComponent(typeof(ColorChanger))]
public class BackObstacle : MonoBehaviour, ICurtainState
{

    CurtainState ICurtainState.SetCurtainState { set { mCurtainState = value; } }

    private List<ColorChanger> mColorChangers = new List<ColorChanger>();
    private CurtainState mCurtainState;
    private Collider mCollider;



    private void Awake()
    {
        mCollider = GetComponent<Collider>();
        /*
        自分　Renderer,ColorChanger,Collider,BackObstacle　パターン 
        自分　Renderer,ColorChanger　子 Colloder,BackObstacle パターン
        自分　Collider,BackObstacle　子 Renderer,ColorChanger　パターン
        自分　Renderer,ColorChanger,Collider,BackObstacle 子 Renderer,ColorChanger,Collider,BackObstacle パターン
         */


        //legacy

        //if (GetComponent<Renderer>()) { mColorChanger = GetComponent<ColorChanger>() ?? gameObject.AddComponent<ColorChanger>(); }

        //ほぼギア用20180617 shinya 
        //Gearの場合子供にBackObstacleがついて親にColorChangerがつく

        //else if (transform.parent)
        //{
        //    if (transform.parent.GetComponent<Renderer>()) { mColorChanger = transform.parent.GetComponent<ColorChanger>() ?? transform.parent.gameObject.AddComponent<ColorChanger>();  }
        //}

        //legacy

        //自分がRendererを持っている場合
        if (GetComponent<Renderer>())
        {
            //通常の奥Block
            var colorChanger = GetComponent<ColorChanger>() ?? gameObject.AddComponent<ColorChanger>();
            mColorChangers.Add(colorChanger);


            //子供がいない場合返す
            if (transform.childCount == 0) { return; }

            //自分がRendererを持っているかつ

            //子供がRendererのみを持っている場合(GrabObject)
            //子供がColliderのみを持っている場合(Gear)->子供にこれをアタッチする
            //子供がColliderもRendererも持っている場合(今のところなし)->子のColliderは自分のOnTriggerに反応するはず

            //親と子に別々のColliderとRendererがある場合(killトゲ)->両方につける

            //子供のColorChangerを操作する(Grab)
            var colorChangerInChildren = GetColorChangerInChildren(transform);
            mColorChangers.AddRange(colorChangerInChildren);
            

            //親子でBackObstacleとColorChangerを使用している場合
            if (transform.parent)
            {
                if (transform.parent.GetComponent<Renderer>())
                {
                    //親のColorChangerを取得する
                    mColorChangers.Add(transform.parent.GetComponent<ColorChanger>());
                }
            }
        }
        //自分がRendererを持ってない場合(Seesaw)
        else
        {
            if (!GetComponent<Collider>()) { return; }
            //自分がColliderだけ持っている場合

            //親がいる場合
            if (transform.parent)
            {
                if (transform.parent.GetComponent<Renderer>())
                {
                    //親のColorChangerを取得する(ギア)
                    mColorChangers.Add(transform.parent.GetComponent<ColorChanger>());
                }
            }

            if (transform.childCount == 0) { return; }

            mColorChangers.AddRange(GetColorChangerInChildren(transform));

        }

        if (!mCollider) { Debug.Log("Colliderが取得できませんでした"); }
    }

    /// <summary>
    /// 子供のColorChangerを全て取得して返す
    /// </summary>
    /// <param name="transform"></param>
    /// <returns></returns>
    private List<ColorChanger> GetColorChangerInChildren(Transform transform)
    {

        List<ColorChanger> colorChangers = new List<ColorChanger>();
        if (transform.childCount == 0) { return colorChangers; }

        foreach (Transform childTrans in transform)
        {
            if (childTrans.GetComponent<Renderer>())
            {
                var colorChanger = GetComponent<ColorChanger>() ?? childTrans.gameObject.AddComponent<ColorChanger>();
                colorChangers.Add(colorChanger);
            }
        }
        return colorChangers;
    }

    private void OnEnable()
    {
        mCollider.isTrigger = true;
    }



    private void Update()
    {
        if (mCurtainState != CurtainState.Close)
        {
            mCollider.isTrigger = true;
        }
        else
        {
            mCollider.isTrigger = false;
        }
    }

    /*Enter->Stay 
     * GrabObjがExitするとPlayerが重なっていても赤くならないから*/
    private void OnTriggerStay(Collider other)
    {
        if (mColorChangers != null)
            //mColorChangers.Play();
            foreach(ColorChanger colorChanger in mColorChangers)
            {
                colorChanger.Play();
            }
    }

    private void OnTriggerExit(Collider other)
    {
        if (mColorChangers != null)
            //mColorChangers.End();
            foreach(ColorChanger colorChanger in mColorChangers)
            {
                colorChanger.End();
            }
    }
}
