﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialManeger : MonoBehaviour,IGameState
{
    private TutorialText mtutorialText;

    private TutorialImage mtutorialImage;

    private GameState mgameState;

    private bool mCanStartText = true; //テキストの一回目の表示をできるか
    private bool mCanStartImage = true; //イメージの一回目の表示ができるか

    private bool mImageActive = false; //イメージのアクティブの状態

    public GameState SetGameState  { set { mgameState = value; } }
    public bool CanStartText { get { return mCanStartText; } }

    //--------------------------------------------------------

    private void Awake()
    {
        //TutorialTextの取得
        mtutorialText = GameObject.FindObjectOfType<TutorialText>();

        //TutorialImageの取得
        mtutorialImage = GameObject.FindObjectOfType<TutorialImage>();

        
    }

    private void Start()
    {
        //イメージをアクティブを切る
        mImageActive = false;
        mtutorialImage.gameObject.SetActive(mImageActive);
    }
    
    private void Update()
    {
        //イメージの表示が終わりったらテキストを表示させる
        if (mtutorialImage.mCanImage && mCanStartText)
        {
            //一回目の表示をするのでフラグを下す
            mCanStartText = false;
            mtutorialText.TextStart();
        }

        switch (mgameState)
        {
            case GameState.Play:

                //一回目のイメージの表示をしてよいか
                if (mCanStartImage)
                {
                    //イメージのアクティブをONにする
                    mImageActive = true;
                    mtutorialImage.gameObject.SetActive(mImageActive);

                    //一回目のイメージの表示をするのでフラグを下す
                    mCanStartImage = false;
                    mtutorialImage.ImageStart();
                }

                //表示されているかどうか
                if (!mImageActive)
                {
                    //表示されていない場合表示する
                    mImageActive = true;
                    mtutorialImage.gameObject.SetActive(mImageActive);
                }
                
                //テキストの流れ通常にする
                mtutorialText.ReStart();

                break;

            case GameState.Menu:

                //テキストの流れを止める
                mtutorialText.Stop();
                
                break;

            default:

                //表示されているかどうか
                if (mImageActive)
                {
                    //表示されていたら非表示にする
                    mImageActive = false;
                    mtutorialImage.gameObject.SetActive(mImageActive);
                }

                break;
        }

    }

    //------------------------------------------------------
}
