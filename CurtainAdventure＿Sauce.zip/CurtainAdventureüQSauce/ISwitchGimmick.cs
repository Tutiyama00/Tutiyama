﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISwitchGimmick
{
    bool IsGimmick { get; }
    int IsGimmickNamber { get; }
    bool CanCheck { get; }

    void PlayGimmick();
    void StopGimmick();
}
