﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitlePlayerAnimController : MonoBehaviour
{
    private PlayerAnimation mPlayerAnimation;
    private void Awake()
    {
        GameObject player = GameObject.Find("Player");
        mPlayerAnimation = new PlayerAnimation(player.GetComponent<Animator>());
    }

    public void Idle()
    {
        mPlayerAnimation.QuitAllAnimation();
        mPlayerAnimation.Idle(true);
    }

    public void Jump()
    {
        mPlayerAnimation.QuitAllAnimation();
        mPlayerAnimation.Jump(true);
    }

    public void Success()
    {
        mPlayerAnimation.QuitAllAnimation();
        mPlayerAnimation.Salute(true);
}
}
