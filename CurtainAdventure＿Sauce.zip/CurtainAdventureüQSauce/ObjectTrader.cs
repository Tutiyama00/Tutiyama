﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class ObjectTrader : EditorWindow
{
    
    public GameObject mNewObject;

    [MenuItem("Custom/ObjectTrader")]
    private static void OpenWindow()
    {
        GetWindow<ObjectTrader>();
    }



    private void OnGUI()
    {
        EditorGUILayout.Space();
        mNewObject = EditorGUILayout.ObjectField("new object", mNewObject, typeof(GameObject), true) as GameObject;
        EditorGUILayout.Space();
        if (GUILayout.Button("Change Objects", GUILayout.MaxWidth(100))) { ChangeObjects(); }
    }

    private void ChangeObjects()
    {
        if (!mNewObject) { return; }
        GameObject[] selectedGObj = Selection.gameObjects;
        foreach (GameObject gObj in selectedGObj)
        {
            Transform oldObjTrans = gObj.transform;
            Vector3 localPosition = oldObjTrans.position;
            Quaternion localRotation = oldObjTrans.rotation;

            //親がいる場合親を設定する
            if (oldObjTrans.parent)
            {
                GameObject newObj = Instantiate(mNewObject, localPosition, localRotation, oldObjTrans.parent);
                newObj.name = mNewObject.name;
            }
            else
            {
                GameObject newObj = Instantiate(mNewObject, localPosition, localRotation);
                newObj.name = mNewObject.name;
            }
            DestroyImmediate(oldObjTrans.gameObject);
        }
    }
}
