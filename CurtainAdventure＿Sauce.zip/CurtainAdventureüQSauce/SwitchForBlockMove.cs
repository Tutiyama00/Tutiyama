﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BlockMove), typeof(Rigidbody))]
public class SwitchForBlockMove : MonoBehaviour, ISwitchGimmick
{
    [SerializeField]
    private int mIsGimmickNumber;
    [SerializeField]
    private bool mCanOnly1Time;

    private bool mIsFirstTime;
    private bool mCanCheck = true;
    private bool mIsGimmick;

    private BlockMove mBlockMove;
    private Rigidbody mRigidbody;

    public int IsGimmickNamber { get { return mIsGimmickNumber; } }
    public bool CanCheck { get { return mCanCheck; } }
    public bool IsGimmick { get { return mIsGimmick; } }



    private void Awake()
    {
        mBlockMove = GetComponent<BlockMove>();
        mRigidbody = GetComponent<Rigidbody>();
    }



    public void PlayGimmick()
    {
        InverseEnable(mBlockMove);

    }

    public void StopGimmick()
    {
        InverseEnable(mBlockMove);
    }

    private void InverseEnable(Behaviour mono)
    {
        if (mCanOnly1Time && mIsFirstTime) { return; }
        mono.enabled = !mono.enabled;
        if (!mono.enabled) { mRigidbody.velocity = Vector3.zero; }
        if (mCanOnly1Time)
        {
            mIsFirstTime = true;
            mCanCheck = false;
        }
    }
}
