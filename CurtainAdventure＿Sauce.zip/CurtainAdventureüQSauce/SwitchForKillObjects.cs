﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchForKillObjects : MonoBehaviour
{
    [SerializeField]
    private List<GameObject> mKillObjects = new List<GameObject>();
    [SerializeField]
    private bool mIsSwitch = true;
    [SerializeField]
    private float PushAmount = 0.1f;

    private GameObject buttonParts;
    private void Start()
    {
        buttonParts = transform.Find("Button").gameObject;
    }

    private void OnCollisionEnter(Collision other)
    {
        //コライダーの衝突判定用のポジションの設定
        float contactPosY = this.transform.localPosition.y + (this.transform.localScale.y / 4.5f);

        foreach (ContactPoint point in other.contacts)
        {
            if (point.point.y >= contactPosY)
            {

                mIsSwitch = !mIsSwitch;

                ChangeStateGimmick(mIsSwitch);
                MoveButton(mIsSwitch);
            }
        }
    }

    /// <summary>
    /// ギミックのオンオフの効果を変える
    /// </summary>
    /// <param name="nextState"></param>
    private void ChangeStateGimmick(bool nextState)
    {
        foreach (GameObject iSwiGim in mKillObjects)
        {
            if (nextState)
            {
                iSwiGim.SetActive(true);
            }
            else
            {
                iSwiGim.SetActive(false);
            }
        }
    }

    /// <summary>
    /// スイッチが押される演出
    /// </summary>
    /// <param name="nextState"></param>
    private void MoveButton(bool nextState)
    {
        //音流す
        AudioManager.Instance.PlaySe(SEAoudio.Instance.SwitchSE);

        if (nextState)
        {
            buttonParts.transform.localPosition = new Vector3(buttonParts.transform.localPosition.x, buttonParts.transform.localPosition.y - PushAmount, buttonParts.transform.localPosition.z);
        }
        else
        {
            buttonParts.transform.localPosition = new Vector3(buttonParts.transform.localPosition.x, buttonParts.transform.localPosition.y + PushAmount, buttonParts.transform.localPosition.z);
        }
    }
}
