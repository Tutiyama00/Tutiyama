﻿public interface IGameState
{
    GameState SetGameState { set; }
}

public interface ICurtainState
{
    CurtainState SetCurtainState { set; }
}