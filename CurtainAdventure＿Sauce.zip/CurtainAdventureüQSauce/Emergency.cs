﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


/// <summary>
/// 画面に赤枠を点滅させる。
/// </summary>
public class Emergency : MonoBehaviour, IGameState
{
    private enum TimerState
    {
        Invisible,
        FadeIn,
        Display,
        FadeOut
    }

    private bool mInvokedPlayMethod;

    private bool mIsRunning;

    [SerializeField]
    private float mFadeInTime;  //フェードインにかかる時間
    [SerializeField]
    private float mDisplayTime;     //赤枠を完全に表示している時間
    [SerializeField]
    private float mFadeOutTime;     //フェードアウトにかかる時間

    private float timer = 0.0f;

    private Image mImage;
    private SpriteRenderer mSpriteRenderer;
    private TimerState mTimerState;
    private GameState mGameState;
    public GameState SetGameState { set { mGameState = value; } }

    private void Awake()
    {
        //singleton
        Emergency singleton = FindObjectOfType<Emergency>();
        if (singleton != this)
        {
            Debug.Log("EmergencyがScene内に二つあります");
            Destroy(singleton);
        }

        mImage = GetComponent<Image>();
        mSpriteRenderer = GetComponent<SpriteRenderer>();
        //null check
        if (!mImage && !mSpriteRenderer) { Debug.Log("SpriteRendererまたはImageがありません!"); }
    }

    private void OnEnable()
    {
        if (!mImage && !mSpriteRenderer) { return; }

        mInvokedPlayMethod = false;
        timer = 0.0f;

        //透明にする
        if (mImage) { mImage.color = InitializeColor(mImage.color); }
        else { mSpriteRenderer.color = InitializeColor(mSpriteRenderer.color); }

    }



    private void FixedUpdate()
    {
        //どちらも持っていない場合
        if (!mImage && !mSpriteRenderer) { return; }

        //GameStateがPlayでなかった場合
        if (mGameState != GameState.Play) { return; }

        //"Play()"が呼ばれたら処理を開始する
        if (mInvokedPlayMethod) { mIsRunning = true; }

        //IsRunningがfalseの場合処理を実行しない
        if (!mIsRunning) { return; }

        //imageが無い場合SpriteRendererを使う
        if (mImage) { mImage.color = UpdateDisplay(mImage.color); }
        else { mSpriteRenderer.color = UpdateDisplay(mSpriteRenderer.color); }
    }


    //------------PUBLIC☆METHOD--------------
    /// <summary>
    /// 枠を表示する
    /// </summary>
    public void Play()
    {
        mInvokedPlayMethod = true;
    }


    /// <summary>
    /// 枠の表示を中止する
    /// </summary>
    public void Stop()
    {
        mInvokedPlayMethod = false;
    }
    //------------PUBLIC☆METHOD--------------
    private Color InitializeColor(Color color)
    {
        color.a = 0.0f;
        return color;
    }



    private Color UpdateDisplay(Color color)
    {

        switch (mTimerState)
        {
            case TimerState.Invisible:

                color.a = 0.0f;
                timer = 0.0f;

                if (mInvokedPlayMethod) { mTimerState = TimerState.FadeIn; }

                break;

            case TimerState.FadeIn:
                //表示完了
                if (color.a >= 1.0f) { mTimerState = TimerState.Display; }

                //表示終了を受け取った場合
                if (!mInvokedPlayMethod) { mTimerState = TimerState.FadeOut; }

                color.a += Time.deltaTime / mFadeInTime;

                break;

            case TimerState.Display:

                //表示終了を受けとった場合
                if (!mInvokedPlayMethod) { mTimerState = TimerState.FadeOut; }

                //表示時間を経過した場合
                if (timer >= mDisplayTime) { mTimerState = TimerState.FadeOut; }

                timer += Time.deltaTime;

                break;

            case TimerState.FadeOut:

                //フェードアウト完了処理
                if (color.a <= 0.0f)
                {
                    mTimerState = TimerState.Invisible;
                    mIsRunning = false;
                }

                color.a -= Time.deltaTime / mFadeOutTime;

                break;

            default: break;
        }

        //a値の限界値超過エラー対策
        color.a = Mathf.Clamp01(color.a);

        return color;
    }
}
