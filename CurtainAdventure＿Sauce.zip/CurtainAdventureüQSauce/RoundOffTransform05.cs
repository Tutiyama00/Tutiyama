﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class RoundOffTransform05 : EditorWindow
{

    [MenuItem("Custom/RoundOffTransform05")]
    private static void OpenWindow()
    {
        //new RoundOffTransform05().RoundOffPos();
        GetWindow<RoundOffTransform05>();
    }



    private void OnGUI()
    {
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("0.5");
        EditorGUILayout.Space();
        if (GUILayout.Button("Round Off position !", GUILayout.MaxWidth(200))) { RoundOffPos(); }
    }

    private void RoundOffPos()
    {
        GameObject[] selectedGObjArr = Selection.gameObjects;
        foreach (GameObject gObj in selectedGObjArr)
        {
            Vector3 pos = gObj.transform.position;

            pos.x = Method(pos.x);
            pos.y = Method(pos.y);
            pos.z = Method(pos.z);

            gObj.transform.position = pos;
        }
    }

    private float Method(float num)
    {
        num *= 1000.0f;
        num = Mathf.Round(num);
        num /= 1000.0f;

        var a = Mathf.Abs(num) % 1.0f > 0.25 ? 0.5f : 0.0f;
        num = Mathf.Floor(num);
        return num += a;
    }
}
