﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class AddMatWindow : EditorWindow
{
    public Material mMaterial;

    [MenuItem("Custom/Material-Attach-kun")]
    private static void OpenWindow()
    {
        GetWindow<AddMatWindow>();
    }
 


    private void OnGUI()
    {
        EditorGUILayout.Space();
        mMaterial = EditorGUILayout.ObjectField("Shader Materal", mMaterial, typeof(Material), true) as Material;
        EditorGUILayout.Space();
        if (GUILayout.Button("Add Material", GUILayout.MaxWidth(100))) { AddMat(); }
    }

    private void AddMat()
    {
        if (!mMaterial) { return; }
        GameObject[] selectedGObjArr = Selection.gameObjects;
        foreach (GameObject gObj in selectedGObjArr)
        {
            Renderer renderer = gObj.GetComponent<Renderer>();
            Material[] materials = { renderer.material, mMaterial };
            renderer.materials = materials;
        }
    }
}
