﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaySE:MonoBehaviour
{
    /// <summary>
    /// SE流す
    /// </summary>
    /// <param name="seName">SEの名前（SEAudioで確認して）</param>
    public static void Play(string seName)
    {
        AudioManager.Instance.PlaySe(SEAoudio.Instance.FindSE(seName));
    }
}
