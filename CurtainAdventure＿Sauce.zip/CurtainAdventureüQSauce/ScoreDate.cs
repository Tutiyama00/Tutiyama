﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreDate : MonoBehaviour
{
    private int[,] Rank = new int[7, 7];
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void DateUpdate(int stage, int rank)
    {
        //int j = (stage % 10);//一のけた(ステージ)
        //int i = Mathf.FloorToInt(stage / 10);//十のけた(何面か)

        //   if (Rank[i,j]<rank) Rank[i, j] = rank;

        //データ保存処理
        //print(stage);
        //print(i);
        //print(j);
        //if (Rank[i, j] < rank)
        //{
        //    PlayerPrefs.SetInt(stage.ToString(), rank);
        //    PlayerPrefs.Save();
        //}
        if (rank > PlayerPrefs.GetInt(stage.ToString(), 0))
        {
            PlayerPrefs.SetInt(stage.ToString(), rank);
            PlayerPrefs.Save();
        }

    }
    public int GetDate(int stage)
    {
        //int j = (stage % 10);//一のけた(ステージ)
        //int i = Mathf.FloorToInt(stage / 10);//十のけた(何面か)
        //return Rank[i,j];
        
        //s
        //データ取得
        return PlayerPrefs.GetInt(stage.ToString(),0);
    }
}
