﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/*
 ギアが赤くならない
->ColorChangerを親につけた場合ColliderがないのでOnTriggerで色を変える処理が呼ばれない。
->子供にColorChangerをつけた場合Rendererがないので色を変えれない。
->結局子供でRendererがなければ親のを探しに行くようにした。
->後ろにあるギアは全ての子にBackObstacleとColorChangerがアタッチされてる
*/

/// <summary>
/// 配列の一つ目がSimpleTempleMateralで
/// 配列の二つ目がSilhouetteShaderでないと機能しないです
/// Emergencyと融合するのが理想
/// </summary>
[DisallowMultipleComponent]
public class ColorChanger : MonoBehaviour
{
    private enum ColorState
    {
        NONE = -1,

        NORMAL,
        FADE_OUT,
        CHANGE,
        FADE_IN,

        MAX
    }


    private bool mIsRunning;
    /// <summary>trueの間点滅処理が走る</summary>
    private bool mIsPlay;
    /// <summary>フェードの時間、表示時間を計測する</summary>
    private float mTimer;
    /// <summary>フェードアウトに使用する時間 ex.4->4秒</summary>
    private float mFadeOutTime = 0.1f;
    /// <summary>目標の色の状態でいる時間 ex.4->4秒</summary>
    private float mTargetColorTime = 10000.0f;
    /// <summary>フェードインに使用する時間 ex.4->4秒</summary>
    private float mFadeInTime = 0.1f;
    /// <summary>何もしていない通常時の色</summary>
    private Color mInitialColor;
    /// <summary>何色に変化するか</summary>
    private Color mTargetColor = Color.red;
    /// <summary>色の変更を加えるマテリアルへの参照</summary>
    private Material mMaterial;
    /// <summary>色の状態をステートで管理</summary>
    private ColorState mTimerState;

    /// <summary>フェードアウトに使用する時間 ex.4->4秒</summary>
    public float FadeOutTime { set { mFadeOutTime = value; } }
    /// <summary>目標の色の状態でいる時間 ex.4->4秒</summary>
    private float TargetColorTime { set { mTargetColorTime = value; } }
    /// <summary>フェードインに使用する時間 ex.4->4秒</summary>
    private float FadeInTime { set { mFadeInTime = value; } }

    /// <summary>何もしていない通常時の色</summary>
    public Color InitialColor { set { mInitialColor = value; } }
    /// <summary>何色に変化するか</summary>
    public Color TargetColor { set { mTargetColor = value; } }



    private void Awake()
    {
        if (GetComponent<Renderer>()) { mMaterial = GetComponent<Renderer>().material; }
        //20180617 shinya
        else if (transform.parent)
        {
            if (transform.parent.GetComponent<Renderer>()) { mMaterial = transform.parent.GetComponent<Renderer>().material; }
        }
        //通常時の色として取得
        mInitialColor = mMaterial.color;
    }

    private void OnEnable()
    {
        mIsRunning = false;
    }



    private void FixedUpdate()
    {
        if (mIsPlay) { mIsRunning = true; }
        if (!mIsRunning) { return; }
        mMaterial.color = UpdateChangeColor(mMaterial.color);
    }



    /// <summary>
    /// 現在の色から指定した色へ往復させる処理
    /// </summary>
    /// <param name="target"></param>
    public void Play()
    {
        mIsPlay = true;
    }



    public void End()
    {
        mIsPlay = false;
    }



    private Color UpdateChangeColor(Color currentColor)
    {
        switch (mTimerState)
        {
            case ColorState.NORMAL:

                if (mIsPlay) { mTimerState = ColorState.FADE_OUT; }
                break;

            case ColorState.FADE_OUT:
                //表示完了
                if (mTimer > 1.0f) { ChangeState(ColorState.CHANGE); }

                //時間計測処理
                mTimer += Time.deltaTime / mFadeOutTime;

                //表示終了を受け取った場合
                if (!mIsPlay) { ChangeState(ColorState.FADE_IN); }

                //色を変化させていく処理
                currentColor = Color.Lerp(currentColor, mTargetColor, Time.deltaTime / mFadeOutTime);
                break;

            case ColorState.CHANGE:
                //表示終了を受けとった場合
                if (!mIsPlay) { ChangeState(ColorState.FADE_IN); }

                mTimer += Time.deltaTime / mTargetColorTime;

                //表示時間を経過した場合
                if (mTimer > 1.0f) { mTimerState = ColorState.FADE_IN; }
                break;

            case ColorState.FADE_IN:
                //フェードアウト完了処理
                mTimer += Time.deltaTime / mFadeInTime;

                //指定した時間経過した場合
                if (mTimer > 1.0f)
                {
                    ChangeState(ColorState.NORMAL);

                    mIsRunning = false;
                    currentColor = mInitialColor;
                    return currentColor;
                }

                currentColor = Color.Lerp(currentColor, mInitialColor, Time.deltaTime / mFadeInTime);
                break;
            default: break;
        }

        return currentColor;
    }



    /// <summary>
    /// mColorStateの変更とmTimerの初期化
    /// </summary>
    /// <param name="colorState"></param>
    private void ChangeState(ColorState colorState)
    {
        mTimer = 0.0f;
        mTimerState = colorState;
    }
}
