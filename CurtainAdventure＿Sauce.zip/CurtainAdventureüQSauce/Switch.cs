﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Switch : MonoBehaviour
{
    [SerializeField]
    private int switchNamber;

    public bool mIsSwitch = false;
    private List<ISwitchGimmick> mGimmick_list = new List<ISwitchGimmick>();

    private GameObject buttonParts;
    private float PushAmount = 0.1f;
    private float mExitTime;

    // private PlayerMove mPlayerMove;//0619 s

    private void Awake()
    {
        GetISwitchGimmick();
        // mPlayerMove = FindObjectOfType<PlayerMove>();//0619 s
    }


    private float mPreEnterTime;

    private void Start()
    {
        buttonParts = transform.Find("Button").gameObject;
    }
    private void OnCollisionEnter(Collision other)
    {
        //連続で押し込めない処理

        //ExitしてすぐEnterしたときを防止する
        if (mExitTime > Time.time - 0.3f) { return; }
        

        //Playerに踏まれたか(絶妙な値を打ち込む)
        // if(mPlayerMove.GetFallSpeed() > 0.0f) { return; }//0619 s

        foreach (ISwitchGimmick iSwiGim in mGimmick_list)
        {
            //対応ギミックが変化可能かどうかのチェック
            if (!iSwiGim.CanCheck)
            {
                return;
            }
        }

        mIsSwitch = !mIsSwitch;

        ChangeStateGimmick(mIsSwitch);
        MoveButton(mIsSwitch);

    }
    private void OnCollisionExit(Collision collision)
    {
        mExitTime = Time.time;
    }



    /// <summary>
    /// ISwitchGimmickの取得、自分と対応しているギミック
    /// </summary>
    private void GetISwitchGimmick()
    {
        foreach (var v in FindObjectsOfType<Component>())
        {
            ISwitchGimmick switchGimmick = v as ISwitchGimmick;

            if (switchGimmick != null)
            {
                if (switchGimmick.IsGimmickNamber == switchNamber)
                {
                    mGimmick_list.Add(switchGimmick);
                }
            }
        }
    }

    /// <summary>
    /// ギミックのオンオフの効果を変える
    /// </summary>
    /// <param name="nextState"></param>
    private void ChangeStateGimmick(bool nextState)
    {
        foreach(ISwitchGimmick iSwiGim in mGimmick_list)
        {
            if (nextState)
            {
                iSwiGim.PlayGimmick();
            }
            else
            {
                iSwiGim.StopGimmick();
            }
        }
    }

    /// <summary>
    /// スイッチが押される演出
    /// </summary>
    /// <param name="nextState"></param>
    private void MoveButton(bool nextState)
    {
        //音流す
        AudioManager.Instance.PlaySe(SEAoudio.Instance.SwitchSE);

        if (nextState)
        {
            buttonParts.transform.localPosition = new Vector3(buttonParts.transform.localPosition.x, buttonParts.transform.localPosition.y - PushAmount, buttonParts.transform.localPosition.z);
        }
        else
        {
            buttonParts.transform.localPosition = new Vector3(buttonParts.transform.localPosition.x, buttonParts.transform.localPosition.y + PushAmount, buttonParts.transform.localPosition.z);
        }
    }
}
