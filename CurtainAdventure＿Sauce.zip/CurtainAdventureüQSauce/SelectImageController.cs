﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class SelectImageController : MonoBehaviour,ISelectHandler {
    Sprite stageSprit;
    Image image;
    
    [SerializeField]
    [Header("ステージの番号(後改良)")]
    string StageNumber;
    public void OnSelect(BaseEventData eventData)
    {
        image.sprite = stageSprit;
    }
    // Use this for initialization
    void Start () {
        image = GameObject.Find(ObjectNames.STAGEIMAGE).GetComponent<Image>();
        stageSprit = Resources.Load<Sprite>("Images/SelectScene/" + StageNumber);
    }	

}
