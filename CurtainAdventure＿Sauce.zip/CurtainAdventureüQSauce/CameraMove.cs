﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour, ICurtainState, IGameState
{
    public CurtainState SetCurtainState { set { mCurtainState = value; } }
    public GameState SetGameState { set { mGameState = value; } }

    [SerializeField]
    private Vector3 mSilhouettePos;
    [SerializeField]
    private float mMoveTime = 0.1f;     //移動にかかる時間


    private Vector3 mSavePos;
    private Quaternion mSaveRot;
    private CurtainState mCurtainState;
    private GameState mGameState;

    private CurtainState mPreFrameCurtainState;

    private void Awake()
    {
        mSavePos = transform.position;
        mSaveRot = transform.rotation;
    }

    bool close;
    bool open;
    float timer;
    private void OnEnable()
    {
        if (mCurtainState == CurtainState.Open) { open = true; }
        if (mCurtainState == CurtainState.Close) { close = true; }
    }
    private void FixedUpdate()
    {
        timer += Time.deltaTime / mMoveTime;

        //開いている状態から閉じた状態へ遷移した場合
        if (mPreFrameCurtainState == CurtainState.Open && mCurtainState == CurtainState.Changing)
        {
            close = true;
            timer = 0.0f;
        }

        //締まっている状態から開いた状態へ遷移した場合
        else if (mPreFrameCurtainState == CurtainState.Close && mCurtainState == CurtainState.Changing)
        {
            open = true;
            timer = 0.0f;
        }
        //クリアでカーテンが締まる為
        else if(mGameState == GameState.Success)
        {
            close = true;
            timer = 0.0f;
        }


        if (close)
        {
            open = false;
            if (timer >= 1.1f)
            {
                //土
                //きっちり移動させるために
                this.transform.position = mSilhouettePos;
                this.transform.rotation = Quaternion.identity;
                //end

                close = false;
            }
            else
            {
                transform.position = Vector3.Lerp(transform.position, mSilhouettePos, Time.deltaTime / mMoveTime);
                transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.identity, Time.deltaTime / mMoveTime);
            }
        }

        if (open)
        {
            close = false;
            if (timer >= 1.1f)
            {
                //土
                //きっちり移動させるために
                this.transform.position = mSavePos;
                this.transform.rotation = mSaveRot;
                //end

                open = false;
            }
            else
            {
                transform.position = Vector3.Lerp(transform.position, mSavePos, Time.deltaTime / mMoveTime);
                transform.rotation = Quaternion.Lerp(transform.rotation, mSaveRot, Time.deltaTime / mMoveTime);
            }
        }

        mPreFrameCurtainState = mCurtainState;
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(mSilhouettePos, 0.5f);
    }
}
