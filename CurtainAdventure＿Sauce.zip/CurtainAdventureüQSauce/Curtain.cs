﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Curtain : MonoBehaviour, IGameState
{
    [SerializeField]
    Transform rCurtain;
    [SerializeField]
    Transform lCurtain;

    //Easy,Normal,Hardで閉じたときの座標違うのでSerializeFieldにする
    //y,z軸は開始時のもので、openはAwake時の座標が使われる
    [SerializeField, Tooltip("実行するとxのScaleが少し変わり幅が狭くなるので気をつけてね"), Space]
    private float rClosePosX = 5.7f;
    [SerializeField, Tooltip("実行するとxのScaleが少し変わり幅が狭くなるので気をつけてね")]
    private float lClosePosX = -5.7f;


    /// <summary>Curtainが移動する速度。何秒で開け閉めするか</summary>
    private const float SPEED = 0.2f;
    /// <summary>Overlap状態からPermissionTime以内にOverlapが全てfalseになった場合Curtainが閉じれる</summary>
    private const float PERMISSION_TIME = 0.2f;
    /// <summary>Curtainが閉じたときの x Scaleの比率</summary>
    private const float CLOSE_SCALE_RATIO_X = 0.9f;//最初より小さくすることで皺がよる
    /// <summary>Curtainが開いたときの x Scaleの比率</summary>
    private const float OPEN_SCALE_RATIO_X = 0.4f;
    /// <summary>この定数倍して切り上げ処理を行い、この定数で割ると小数点第x位で切り上げができる。100->第二位</summary>
    private const int CEIL = 100;
    /// <summary>本来移動する量の残りがx%以下になるとCurtainStateが変更される。値が小さいほど静止時間がのびる</summary>
    private const float POS_MARGIN_RATIO_X = 0.05f;

    /// <summary>CurtainStateの遷移に少し余裕を持たせる為に使用</summary>
    private float mLPosMarginX = 0.0f;
    /// <summary>CurtainStateの遷移に少し余裕を持たせる為に使用</summary>
    private float mRPosMarginX = 0.0f;
    /// <summary>右Curtainが開いている時のScale</summary>
    private float mROpenScaleX;
    /// <summary>右Curtainが開いている時のScale</summary>
    private float mRCloseScaleX;
    /// <summary>左Curtainが開いている時のScale</summary>
    private float mLOpenScaleX;
    /// <summary>左Curtainが開いている時のScale</summary>
    private float mLCloseScaleX;
    /// <summary>左のカーテンが開いているときの座標。Awakeで取得する</summary>
    private float mLOpenPosX;
    /// <summary>右のカーテンが開いているときの座標。Awakeで取得する</summary>
    private float mROpenPosX;
    /// <summary>CurtainButtonが押されてから重なっている間、mTimerTriggerを経過するまで計測するのに使用する</summary>
    private float mOverlapTimer;
    /// <summary>移動先positionのx</summary>
    private float mLNextPosX;
    /// <summary>移動先positionのx</summary>
    private float mRNextPosX;
    /// <summary>開閉したときのそれぞれのScale</summary>
    private float mLNextScaleX;
    /// <summary>開閉したときのそれぞれのScale</summary>
    private float mRNextScaleX;
    /// <summary>Userからの入力受付</summary>
    private UserInput mUserInput;
    /// <summary>GRAB State のときCurtainを閉められなくする処理</summary>
    private PlayerMove mPlayerMove;
    /// <summary>Scene上にあるOverlapリスト</summary>
    private List<Overlap> mOverlaps = new List<Overlap>();
    /// <summary>Scene上全てのICurtainStateのList</summary>
    private List<ICurtainState> mCurtainStates = new List<ICurtainState>();
    /// <summary>現在のGameState</summary>
    private GameState mGameState;
    /// <summary>Curtainの現在のCurtainState</summary>
    private CurtainState mCurrentCurtainState;

    //PROPERTY
    public GameState SetGameState { set { mGameState = value; } }

    //0627tutiyama
    public CurtainState CurrentCurtainState { set { mCurrentCurtainState = value; } get{ return mCurrentCurtainState; } }

    private InnerCurtainState mInnerState;

    /// <summary>Curtainクラスの内部のみで使用するCurtaiのState</summary>
    private enum InnerCurtainState
    {
        NONE = -1,

        /// <summary>遷移した瞬間時間の計測を開始し、Overlapsがfalseになった時MOVEに遷移する</summary>
        AVOID_CHANCE,
        /// <summary>mCurrentCurtainStateを使用して次に開閉のどちらをするか判断しNextPos,NextScaleを設定する。一定量進むとNONEに遷移する</summary>
        MOVE,

        MAX
    }


    private void Awake()
    {
        //GRAB State 中にCurtainを閉められないようにするためPlayerMoveを取得する
        mPlayerMove = GameObject.FindObjectOfType<PlayerMove>();
        //UserInputの取得
        mUserInput = FindObjectOfType<UserInput>();
        //Oberlapをすべて取得する
        mOverlaps.AddRange(FindObjectsOfType<Overlap>());
        //ICurtainStatesを実装したコンポーネントを取得
        mCurtainStates = FindICurtainStates();
        //全てのCurtainStateの初期化。InnerStateも初期化
        SetCurtainStates(CurtainState.Open, InnerCurtainState.NONE);

        //初期化
        mLOpenPosX = lCurtain.position.x;
        mROpenPosX = rCurtain.position.x;
        //開閉したときのScaleを作成
        mLCloseScaleX = lCurtain.localScale.x * CLOSE_SCALE_RATIO_X;
        mLOpenScaleX = lCurtain.localScale.x * OPEN_SCALE_RATIO_X;
        mRCloseScaleX = rCurtain.localScale.x * CLOSE_SCALE_RATIO_X;
        mROpenScaleX = rCurtain.localScale.x * OPEN_SCALE_RATIO_X;

        //開いた状態から開始します
        mLNextPosX = mLOpenPosX;
        mRNextPosX = mROpenPosX;
        mLNextScaleX = mLOpenScaleX;
        mRNextScaleX = mROpenScaleX;

        //判定に余裕を持たせる為の変数を作成
        float lDistance = Mathf.Abs(mLOpenPosX - lClosePosX);
        mLPosMarginX = lDistance * Mathf.Clamp01(POS_MARGIN_RATIO_X);
        float rDistance = Mathf.Abs(rClosePosX - mROpenPosX);
        mRPosMarginX = rDistance * Mathf.Clamp01(POS_MARGIN_RATIO_X);

        //Scaleをopenに変更する
        lCurtain.localScale.Scale(new Vector3(mLOpenScaleX, 1.0f, 1.0f));
        rCurtain.localScale.Scale(new Vector3(mROpenScaleX, 1.0f, 1.0f));
    }



    private void FixedUpdate()
    {

        if (mPlayerMove.GetPlayerState == PlayerState.GRAB /*0627tutiyama*/ || mCurrentCurtainState == CurtainState.STOP) { return; }

        Vector3 lPos = lCurtain.position;
        Vector3 rPos = rCurtain.position;
        Vector3 lScale = lCurtain.localScale;
        Vector3 rScale = rCurtain.localScale;


        /*
        * 一定速度での移動だとカーテンっぽくなかった為、Lerpでの移動に変更しました。
        * 
        * カーテンっぽさを出すためにScaleを変更しています(皺がよる)。
        * 
        * 静止している時間が長いと操作性が悪かったので完全に開ききる前に動けるようにStateの変更とCurtainの移動を分けました。
        * Stageが変わってもカーテンは完全に開くまで動きます。
        * 
        * Clearのときは重なっていても閉められるようにした。
        * 
        * elseでreturnしたかったので上に書きました。
        */
        if (mGameState == GameState.Play || mGameState == GameState.Success)
        {
            lPos.x = Mathf.Lerp(lPos.x, mLNextPosX, Time.deltaTime / SPEED);
            rPos.x = Mathf.Lerp(rPos.x, mRNextPosX, Time.deltaTime / SPEED);

            lScale.x = Mathf.Lerp(lScale.x, mLNextScaleX, Time.deltaTime / SPEED);
            rScale.x = Mathf.Lerp(rScale.x, mRNextScaleX, Time.deltaTime / SPEED);


            //制限
            lPos.x = Mathf.Clamp(lPos.x, mLOpenPosX, lClosePosX);

            rPos.x = Mathf.Clamp(rPos.x, rClosePosX, mROpenPosX);

            //Lerpの結果を代入する
            lCurtain.position = lPos;
            rCurtain.position = rPos;
            lCurtain.localScale = lScale;
            rCurtain.localScale = rScale;
        }
        else { return; }

        //Successは以降の処理が関係ない為返す
        if (mGameState == GameState.Success) { return; }


        //ボタンが押された瞬間にカーテンを閉められるか確認しmInnerStateのswitchのどこに入るか振り分ける。
        if (mUserInput.CurtainButton)
        {

            if (mCurrentCurtainState == CurtainState.Changing) { return; }
            //何か重なっているものがあるか
            if (IsAnythingOverlap())
            {
                mOverlapTimer = 0.0f;
                //時間内にOverlapが全てfalseになればカーテンを閉められる処理
                mInnerState = InnerCurtainState.AVOID_CHANCE;
            }
            else
            {
                //誰も重なっていなければ移動処理に移る
                mInnerState = InnerCurtainState.MOVE;
            }
        }



        switch (mInnerState)
        {

            case InnerCurtainState.AVOID_CHANCE:
                //ガード句
                //Changingなら抜ける
                if (mCurrentCurtainState == CurtainState.Changing) { break; }

                mOverlapTimer += Time.deltaTime;

                //タイムオーバーした場合switchを抜ける
                if (mOverlapTimer > PERMISSION_TIME)
                {
                    //音流すカーテンできないSE
                    AudioManager.Instance.PlaySe(SEAoudio.Instance.CantSE);

                    mInnerState = InnerCurtainState.NONE;//0619 s
                    break;
                }

                //何も重なっていない状況に変わった場合
                if (!IsAnythingOverlap())
                {
                    //カーテンの移動処理に移る
                    mInnerState = InnerCurtainState.MOVE;
                }

                break;

            //CurtainButtonの入力がありOverlapが全てfalseだった場合、CurtainStateが変更されるまでMOVEに入ります。
            case InnerCurtainState.MOVE:

                //余裕を持った判定(mPosMarginXの加減算)にしておくことで完全に移動しきる前にオブジェクトの静止をやめ、カーテンの開け閉めが可能になる
                bool isLMarginOpen = lPos.x <= mLOpenPosX + mLPosMarginX;
                bool isRMarginOpen = rPos.x >= mROpenPosX - mRPosMarginX;
                bool isLMarginClose = lPos.x >= lClosePosX - mLPosMarginX;
                bool isRMarginClose = rPos.x <= rClosePosX + mRPosMarginX;



                /*
                 * 次の移動先をNextPosに代入する処理ex.Open -> Close
                 */
                //現在開いていた場合閉じる。Stateが変わり次フレームからChanging Stateに入る
                if (mCurrentCurtainState == CurtainState.Open) { Close(); }
                //現在閉じていた場合開く。Stateが変わり次フレームからChanging Stateに入る
                else if (mCurrentCurtainState == CurtainState.Close) { Open(); }
                //条件が揃うとMOVEから抜ける
                else if (mCurrentCurtainState == CurtainState.Changing)
                {
                    //Changingの場合

                    //次の挙動が開閉のどちらか。open -> true,close -> false
                    bool isNextOpen = Mathf.Approximately(mLNextPosX, mLOpenPosX);

                    /*
                     * カーテンが移動し終わったか。
                     * 完全に開いている状態で閉じようとしたときに開き終わった判定にならにようにisNextOpen/Closeフラグを使用する。
                     * CurtainStateが変更 Changing -> Open/Close。
                     * InnerState MOVE -> NONE
                     */
                    //カーテンが開いた判定になった場合全てのICurtainStateをChangingに変更する。静止してたオブジェクトが動きます。InnerStateも変更MOVE->NONE
                    if (isNextOpen && isLMarginOpen && isRMarginOpen) { SetCurtainStates(CurtainState.Open, InnerCurtainState.NONE); }
                    //カーテンが閉じた判定になった場合全てのICurtainStateをChangingに変更する。静止してたオブジェクトが動きます。InnerStateも変更MOVE->NONE
                    else if (!isNextOpen && isLMarginClose && isRMarginClose) { SetCurtainStates(CurtainState.Close, InnerCurtainState.NONE); }
                }


                break;
            default: break;
        }
    }

    //----------------------PUBLIC METHOD-------------------------

    /// <summary>
    /// Clear用のCloseメソッド。
    /// </summary>
    public void ClearClose()//金田追記カーテンをクリアに変えて閉じる
    {

        lCurtain = GameObject.Find("Curtain_Clear_L").GetComponent<Transform>();
        rCurtain = GameObject.Find("Curtain_Clear_R").GetComponent<Transform>();

        mLNextPosX = lClosePosX;
        mRNextPosX = rClosePosX;

        mLNextScaleX = mLCloseScaleX;
        mRNextScaleX = mRCloseScaleX;

        //FixedUpdate内にreturnがあるのでinnerCurtainState関係ない
        SetCurtainStates(CurtainState.Close, InnerCurtainState.NONE);
    }
    //----------------------PUBLIC METHOD-------------------------


    /// <summary>
    /// 自分とICurtainStateの全てを変更する。InnerStateも変更(変更しないと開くと閉じるを交互に繰り返し続けてしまうため)。
    /// </summary>
    /// <param name="curtainState">変えるState</param>
    private void SetCurtainStates(CurtainState curtainState, InnerCurtainState innerState)
    {
        mCurrentCurtainState = curtainState;
        mInnerState = innerState;

        foreach (ICurtainState iCurtainState in mCurtainStates)
        {
            iCurtainState.SetCurtainState = mCurrentCurtainState;
        }
    }



    private void Open()
    {
        if (IsAnythingOverlap()) { return; }

        //音流す
        AudioManager.Instance.PlaySe(SEAoudio.Instance.CurtainSE);

        mLNextPosX = mLOpenPosX;
        mRNextPosX = mROpenPosX;

        mLNextScaleX = mLOpenScaleX;
        mRNextScaleX = mROpenScaleX;

        SetCurtainStates(CurtainState.Changing, InnerCurtainState.MOVE);
    }



    private void Close()
    {
        if (IsAnythingOverlap()) { return; }

        //音流す
        AudioManager.Instance.PlaySe(SEAoudio.Instance.CurtainSE);

        mLNextPosX = lClosePosX;
        mRNextPosX = rClosePosX;

        mLNextScaleX = mLCloseScaleX;
        mRNextScaleX = mRCloseScaleX;

        SetCurtainStates(CurtainState.Changing, InnerCurtainState.MOVE);
    }



    /// <summary>
    /// 全てのOverlapの中で何かが重なっていた場合true。何も重なっていなかった場合falseを返す。
    /// </summary>
    /// <returns></returns>
    private bool IsAnythingOverlap()
    {
        foreach (Overlap overlap in mOverlaps)
        {
            if (overlap.IsOverlap) { return true; }
        }
        return false;
    }

    /// <summary>
    /// ICurtainStateをすべて取得
    /// </summary>
    private List<ICurtainState> FindICurtainStates()
    {
        List<ICurtainState> curtainStates = new List<ICurtainState>();
        foreach (var n in FindObjectsOfType<Component>())
        {
            ICurtainState curtainState = n as ICurtainState;

            if (curtainState != null)
            {
                curtainStates.Add(curtainState);
            }
        }
        return curtainStates;
    }


    /// <summary>
    /// 小数点以下第point位を切り上げして返す
    /// </summary>
    /// <param name="num"></param>
    /// <param name="point"></param>
    private float Ceil(float num, int point)
    {
        float work = Mathf.Ceil(num * CEIL);
        num = work / CEIL;
        return num;
    }
}

