﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class ColliderSizeChanger : EditorWindow {
    private float ZLength = 6.0f;

    [MenuItem("Custom/ColliderSizeChanger")]
    private static void OpenWindow()
    {
        GetWindow<ColliderSizeChanger>();
    }



    private void OnGUI()
    {
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Collider's z size");
        ZLength = EditorGUILayout.FloatField(ZLength);
        EditorGUILayout.Space();
        if (GUILayout.Button("Change size(length)", GUILayout.MaxWidth(200))) { ChangeColLength(); }
    }

    private void ChangeColLength()
    {
        GameObject[] selectedGObjArr = Selection.gameObjects;
        foreach (GameObject gObj in selectedGObjArr)
        {
            BoxCollider bCol = gObj.GetComponent<BoxCollider>();
            if (bCol)
            {
                Debug.Log("s");
                Vector3 size = bCol.size;
                size.z = ZLength;
                bCol.size = size;
                continue;
            }
            CapsuleCollider cCol = gObj.GetComponent<CapsuleCollider>();
            if (cCol)
            {
                cCol.height = ZLength;
                continue;
            }

            Debug.Log(gObj.name + ": Colliderの大きさを変えられませんでした。");
        }
    }
}
