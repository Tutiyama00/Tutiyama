﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



/*
 * ・ギアがエラーを吐きまくる
->ギアがBoxColloderを斜めにできないので親にRenderer,子にColliderという作りに
なってる。
親にSwitch Enabled Objをつけてクラス内で走るGetComponents<Collder>()でエラーを
吐きまくってたので子供のColliderがあればGetComponentするようにした。

 */
public class SwitchEnabledObj : MonoBehaviour, ISwitchGimmick
{
    private bool mIsGimmick = false;
    public bool IsGimmick { get { return mIsGimmick; } }

    [SerializeField]
    private int mIsGimmickNamber;
    public int IsGimmickNamber { get { return mIsGimmickNamber; } }

    private List<Collider> mCollider_list = new List<Collider>();

    private bool mcanCheck = true;
    public bool CanCheck { get { return mcanCheck; } }

    private List<GameObject> mChildObj_list = new List<GameObject>();

    [SerializeField,Tooltip("ゲーム開始時のActiveがfalseの場合チェックを入れる")] private bool mIsStartActiveFalse;
    //追記
    private BlockMove mBlockMove;

    public void Start()
    {
        gameObject.SetActive(!mIsStartActiveFalse);
        //0617shinya
        //if (GetComponent<BlockMove>()) { mBlockMove = GetComponent<BlockMove>(); }

        ////自分の子供の取得
        //foreach (Transform tra in this.gameObject.GetComponentsInChildren(typeof(Transform)))
        //{
        //    if (this.gameObject != tra.gameObject)
        //    {
        //        mChildObj_list.Add(tra.gameObject);

        //        //20180617shinya
        //        //Collider col = tra.GetComponent<Collider>();
        //        //if (col == null) { continue; }
        //        //mCollider_list.Add(col);
        //    }
        //}
        //print(mChildObj_list.Count);

        //if (GetComponent<Collider>())
        //{ mCollider_list.AddRange(this.gameObject.GetComponents<Collider>()); }
    }

    private void OnTriggerStay(Collider other)
    {
        mcanCheck = false;
    }

    private void OnTriggerExit(Collider other)
    {
        mcanCheck = true;
    }

    public void PlayGimmick()
    {
        //if (mcanCheck)
        //{
        //    EnableChange();
        //}
        InverseActive();
    }

    public void StopGimmick()
    {
        //EnableChange();
        InverseActive();
    }


    private void InverseActive()
    {
        gameObject.SetActive(!gameObject.activeSelf);
    }

    private void EnableChange()
    {
        //変えた--------------------
        foreach (Collider collider in mCollider_list)
        {
            //collider.isTrigger = !collider.isTrigger;

            //tutiyama0615Stage1のグラスBug解決の変更
            collider.enabled = !collider.enabled;
        }

        //foreach (Glass glass in GetComponents<Glass>())
        //{
        //    glass.enabled = !glass.enabled;
        //}
        //------------------

        foreach (Overlap ovlp in GetComponents<Overlap>())
        {
            ovlp.enabled = !ovlp.enabled;
        }

        //shinya
        //if (GetComponent<Renderer>())
        //{
        //    GetComponent<Renderer>().enabled = !GetComponent<Renderer>().enabled;
        //}


        if (mBlockMove) { mBlockMove.enabled = !mBlockMove.enabled; }

        //foreach (Renderer renderer in this.gameObject.GetComponentsInChildren<Renderer>())
        //{
        //    renderer.enabled = !renderer.enabled;
        //}

        if (mChildObj_list != null)
        {
            foreach (GameObject obj in mChildObj_list)
            {
                obj.SetActive(GetComponent<Collider>().enabled);
            }
        }
    }
}
