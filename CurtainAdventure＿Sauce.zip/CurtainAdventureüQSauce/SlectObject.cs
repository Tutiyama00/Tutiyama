﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SlectObject : MonoBehaviour {//セレクト画面のオブジェクトが自身の対応ステージの星を表示する。
    private ScoreDate dateBase;
    private int rank;
    [SerializeField]
    [Header("ステージの番号")]
    private string stageName;
    private Image image;
	// Use this for initialization
	void Start () {
        image=GetComponent<Image>();
        dateBase = FindObjectOfType<ScoreDate>();
        rank = dateBase.GetDate(int.Parse(stageName));
        image.fillAmount =((float)(rank) / 3f);
	}
}
