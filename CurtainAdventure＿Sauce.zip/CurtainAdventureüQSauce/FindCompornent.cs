﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindCompornent : MonoBehaviour {

	// Use this for initialization
	void Start ()
    {
		foreach(SwitchEnabledObj aa in GameObject.FindObjectsOfType<SwitchEnabledObj>())
        {
            print(aa.gameObject.name);
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
