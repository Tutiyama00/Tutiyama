﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIcontroller : MonoBehaviour, IGameState//ゲームのstateに応じてUIを操作するクラス
{
    public GameState SetGameState { set { NowUI((int)value); } }
    private GameState UIState;
    Animator UIanimator;
//    private int rank;//クリア時評価ポイント   
    private List<GameObject> UIlist;
    private Curtain mCurtain;
    private ParticleSystem mStarCenter;
    private ParticleSystem mStarLeft;
    private ParticleSystem mStarRight;


    // 配列にオブジェクトを探して黙らせぶち込みます  
    void Awake()//Start() -> Awake()
    {
        UIlist = new List<GameObject>() ;//UIオブジェクト格納リスト
        UIanimator = (GetComponent<Animator>());
        UIlist.Add(GameObject.Find(ObjectNames.READY));
        UIlist.Add(GameObject.Find(ObjectNames.PLAY));
        UIlist.Add( GameObject.Find(ObjectNames.MENU));
        UIlist.Add(GameObject.Find(ObjectNames.SUCCESS));
        UIlist.Add(GameObject.Find(ObjectNames.FAILURE));
        mCurtain = GameObject.FindObjectOfType<Curtain>();

        foreach (GameObject n in UIlist)
        {
            n.SetActive(false);
        }
    }


    /// <summary>
    /// UIのUIState別変化
    /// </summary>
    /// <param name="what">どのobjectがハツラツするか</param>
    void UIchanger(GameObject what)
    {
        foreach (GameObject n in UIlist)
        {
            if (n != what && n.activeSelf == true)
            {
                n.SetActive(false);
            }
               
            else if (n == what && n.activeSelf == false)
            {
                n.SetActive(true);
            }
           
        }
    }


    private void NowUI(int a)//UIStateに対応したオブジェクトを返す
    {
        UIchanger(UIlist[a]);
    }
    //メニューのアニメーション処理
    public void MenuAnimationOpen()
    {
        UIanimator.SetTrigger(ObjectNames.MENU);
    }
    public void MenuAnimationClose()
    {
        UIanimator.SetTrigger(ObjectNames.MENU+"Close"); ;
    }

    public void GameOver()
    {
        UIanimator.SetTrigger(ObjectNames.FAILURE);
    }


    //俗に言うCLEAR処理となろう
    public void Achievement(int RankPoint)//クリア時に評価に応じて星を与える?
    {
        //rank=RankPoint;
        switch (RankPoint)//gamecontrollerのゲーム評価点を見る
        {
            case 1:
                mCurtain.ClearClose();
                UIanimator.SetTrigger(ObjectNames.STAR1);
                //対応アニメかイベントをセット
                break;
            case 2:
                mCurtain.ClearClose();
                UIanimator.SetTrigger(ObjectNames.STAR2);
                //対応アニメかイベントをセット
                break;
            case 3:
                mCurtain.ClearClose();
                UIanimator.SetTrigger(ObjectNames.STAR3);
                //対応アニメかイベントをセット
                break;
        }
    }

}
