﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillObject : MonoBehaviour {

    private PlayerCollisionEvent collisionEvent;
    private GameObject player;
    private bool mOnce;
    public DeathPattern WhyDidIDie;//死に方
                // Use this for initialization
    void Start()
    {
        player = GameObject.Find("Player");
        collisionEvent = player.GetComponent<PlayerCollisionEvent>();
        mOnce = false;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (mOnce) { return; }
        if (other.gameObject == player)
        {
            mOnce = true;
            collisionEvent.Death(WhyDidIDie);
            //後に後処理の実装
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (mOnce) { return; }
        if (collision.gameObject == player)
        {
            mOnce = true;
            collisionEvent.Death(WhyDidIDie);
            //後に後処理の実装
        }
    }

}
