﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleScript : MonoBehaviour
{
    [SerializeField]
    private List<GameObject> mUI;     //ボタンが入力されたとき表示するUI
    private bool once;

    private void Awake()
    {
        foreach (GameObject ui in mUI)
        {
            ui.SetActive(false);
        }
    }



    private void Update()
    {
        if (once) { return; }
        if (AnyJoystickButton())
        {
            once = false;
            AudioManager.Instance.PlaySe(SEAoudio.Instance.ChoiceSE);
            foreach (GameObject ui in mUI)
            {
                ui.SetActive(true);
            }

            //           mUI[0].GetComponent<UnityEngine.UI.Button>().Select();


            gameObject.SetActive(false);
        }
    }

    public void Exit()//さよなら…(金田追記)
    {
        Application.Quit();
    }

    private bool AnyJoystickButton()
    {
        if(Input.GetKey(KeyCode.JoystickButton0)||
            Input.GetKey(KeyCode.JoystickButton1)||
            Input.GetKey(KeyCode.JoystickButton2)||
            Input.GetKey(KeyCode.JoystickButton3)||
            Input.GetKey(KeyCode.JoystickButton4)||
            Input.GetKey(KeyCode.JoystickButton5)||
            Input.GetKey(KeyCode.JoystickButton6)||
            Input.GetKey(KeyCode.JoystickButton7))
        {
            return true;
        }

        return false;
    }
}
