﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneLoading : MonoBehaviour {//ボタンが呼び出します
    private string nowScene;
    //　非同期動作で使用するAsyncOperation
    private AsyncOperation async;
    //　シーンロード中に表示するUI画面
    private GameObject loadUI;
    //　読み込み率を表示するスライダーとパーセントの表示
    private Image slider;
    private Text gagePercent;
    //読み込み中フェードインフェードアウト
    public Image fede;

    private void Awake()
    {
        SceneManager.LoadSceneAsync("TitleScene", LoadSceneMode.Additive);
        nowScene = "TitleScene";
        loadUI = GameObject.Find("LoadUI");
        fede = GameObject.Find("Fede").GetComponent<Image>();
        //マウスの操作を受け付けなくする＆見えなくする
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void Start()
    {
        gagePercent = GameObject.Find("GagePercent").GetComponent<Text>();
        slider = GameObject.Find("Gage").GetComponent<Image>();
        //曲流す
        AudioManager.Instance.PlayBgm(SceneAudio.Instance.FindBGM(nowScene));
    }
    
    /// <summary>
    /// ロードするシーンを受け取り現在のシーンを破棄後指定シーンをロードする
    /// </summary>
    /// <param name="loadScene">ロードするシーンを引数に受け取る(ボタンのinspectorにて指定)</param>
    public void SceneChange(string loadScene)
    {
        //音流す
        //AudioManager.Instance.PlaySe(SEAoudio.Instance.ChoiceSE);

        loadUI.SetActive(true);
        SceneManager.UnloadSceneAsync(nowScene);//現在のシーン破棄
        //AudioManager.Instance.PlaySe(SEAoudio.Instance.ChoiceSE);
        //　コルーチンを開始
        StartCoroutine("LoadData", loadScene);
    }


    // シーンをロードしその間マスターシーンのロード画面のUI処理を行う
    IEnumerator LoadData(string loadScene)
    {
        fede.color = Color.clear;
        while (fede.color.a <= 1)
        {
            fede.color = new Color(fede.color.r, fede.color.g, fede.color.b, fede.color.a + 0.05f);
            yield return null;
        }
        //　ロード画面UIをアクティブにする
        nowScene = loadScene;
        // シーンの読み込みをする
        async = SceneManager.LoadSceneAsync(loadScene, LoadSceneMode.Additive);

        //　読み込みが終わるまで進捗状況をスライダーの値に反映させる
        while (!async.isDone)
        {
            slider.fillAmount = async.progress;
            float progressVal = async.progress / 0.9f;
            if (progressVal == 0.9f)//99作戦
            {
                progressVal = 0.99f;
            }
            gagePercent.text = Mathf.Floor(progressVal * 100) + "%";
            yield return null;
        }

        //曲流す
        AudioManager.Instance.PlayBgm(SceneAudio.Instance.FindBGM(loadScene));
    }
    public void UIfalse()//誰かが呼んだほうがいい？
    {
        loadUI.SetActive(false);
    }

    public  IEnumerator FedeIn()
    {
        fede.color = Color.black;
        while (fede.color.a >= 0)
        {
            fede.color = new Color(fede.color.r, fede.color.g, fede.color.b, fede.color.a - 0.05f);
            yield return null;
        }
        GameController gameController = GameObject.FindObjectOfType<GameController>();
        if (gameController == null)
        {

        }
        else { /*gameController.Play(); */}
        
    }
}

