﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : SingletonMonoBehaviour<AudioManager>
{
    private const float permissionPoint = 0.1f;　//フェードアウトするときの許容値
    private const float DEFAULT_VOLUME = 1.0f;  //デフォルトのボリューム
    private const float DEFAULT_PITCH = 1.0f;　　//デフォルトのピッチ
    private AudioSource bgmSource;　　//BGM用のAudioSource
    private AudioSource seSource;　　　//SE用のAudioSource
    private AudioClip waitBgm;　　　　//次に流すBGM
    private float mWaitVolume;　　　　//次に流すBGMの音量
    private float mWaitPitch;　　　　　//次に流すBGMのピッチ
    private bool mIsFadeOut = false;　　//フェードアウトをするかのフラグ
    private float mOutTime;　　　　　　//フェードアウトの時間
    private float mWaitOutTime = 0.3f;　　　//次に流すBGMを流す間隔



    //---------------------------------------
    protected override void Awake()
    {
        base.Awake();
        Initialization();
    }

    private void Update()
    {
        if (mIsFadeOut)
        {
            FadeOutBgm();
        }
    }

    //--------------------------------------



    /// <summary>
    /// 初期化
    /// </summary>
    private void Initialization()
    {
        bgmSource = GetComponents<AudioSource>()[0];
        bgmSource.loop = true;
        seSource = GetComponents<AudioSource>()[1];
        seSource.loop = false;
    }

    public void PlayBgm(AudioClip bgm)
    {
        //今BGMが流れているか
        if (bgmSource.clip == null)
        {
            //流れていなかった場合そのまま流す
            bgmSource.clip = bgm;
            bgmSource.volume = DEFAULT_VOLUME;
            bgmSource.pitch = DEFAULT_PITCH;
            bgmSource.Play();
        }
        else
        {
            //流れていた場合フェードアウトさせて、新しく流す
            waitBgm = bgm;
            mWaitVolume = DEFAULT_VOLUME;
            mWaitPitch = DEFAULT_PITCH;
            StartFadeOutBgm(mWaitOutTime);
        }
    } 

    /// <summary>
    /// BGMを流す
    /// </summary>
    public void PlayBgm(AudioClip bgm, float volume,float pitch)
    {
        //今BGMが流れているか
        if (bgmSource.clip == null)
        {
            //流れていなかった場合そのまま流す
            bgmSource.clip = bgm;
            bgmSource.volume = volume;
            bgmSource.pitch = pitch;
            bgmSource.Play();
        }
        else
        {
            //流れていた場合フェードアウトさせて、新しく流す
            waitBgm = bgm;
            mWaitVolume = volume;
            mWaitPitch = pitch;
            StartFadeOutBgm(mWaitOutTime);
        }
        
    }

    /// <summary>
    /// SEを流す
    /// </summary>
    public void PlaySe(AudioClip se)
    {
        seSource.volume = DEFAULT_VOLUME;
        seSource.pitch = DEFAULT_PITCH;
        seSource.PlayOneShot(se);
    }

    /// <summary>
    /// SEを流す
    /// </summary>
    public void PlaySe(AudioClip se,float volume,float pitch)
    {
        seSource.volume = volume;
        seSource.pitch = pitch;
        seSource.PlayOneShot(se);
    }

    /// <summary>
    /// BGMのフェードアウトを始める
    /// </summary>
    /// <param name="outTime">フェードアウトの時間</param>
    public void StartFadeOutBgm(float outTime)
    {
        //時間の設定
        mOutTime = outTime;
        
        //開始のフラグを立てる
        mIsFadeOut = true;
    }

    /// <summary>
    /// フェードアウトの本処理
    /// </summary>
    private void FadeOutBgm()
    {
        //今のボリュームが消す許容値以上か
        if (bgmSource.volume > permissionPoint)
        {
            //以上の場合音量を減らす
            float minusPoint = bgmSource.volume * (Time.deltaTime / mOutTime);

            mOutTime -= Time.deltaTime;

            bgmSource.volume -= minusPoint;
        }
        else
        {
            //以下の場合音量を０にする
            mIsFadeOut = false;
            bgmSource.clip = null;
            bgmSource.volume = 0f;

            //次に流すBGMがセットされているか
            if(waitBgm != null)
            {
                //セットされていた場合流す
                PlayBgm(waitBgm, mWaitVolume, mWaitPitch);
                waitBgm = null;
            }
        }
    }
}
