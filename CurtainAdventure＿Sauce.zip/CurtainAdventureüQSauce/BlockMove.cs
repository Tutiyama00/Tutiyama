﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//自動移動させたいオブジェクトにつけるスクリプト。positionとrotationの固定に気を付ける
//velocityが0になったら折り返す処理もつける
[RequireComponent(typeof(Rigidbody))]
public class BlockMove : Overlap
{
    private const float INVERSE = -1.0f;

    [SerializeField]
    private bool mLoop;
    [SerializeField]
    private float mSpeed;           //移動速度
    [SerializeField]
    private Vector3 mDistance;      //目標地点までの距離

    [Space, SerializeField]
    private float mRotateSpeed;
    [SerializeField]
    private bool mRotationX;
    [SerializeField]
    private bool mRotationY;
    [SerializeField]
    private bool mRotationZ;

    private bool mNext;             //交互にベクトルを取り出すのに使用
    private Vector3 mVelocity;      //速度ベクトル
    private Vector3 mStartPos;      //初期位置
    private Vector3 mTargetPos;     //目標位置
    private Vector3 mNextPos;       //現在の目標位置

    private Vector3 mRot;

    protected new void Awake()
    {
        base.Awake();
        mStartPos = transform.position;
        mTargetPos = mStartPos + mDistance;
        mVelocity = mDistance.normalized * mSpeed;
        mNextPos = mTargetPos;

        if (mRigidbody)
        {
            mRigidbody.mass = 100.0f;
            mRigidbody.useGravity = false;
            mRigidbody.isKinematic = false;
        }

        mRot.x = mRotationX ? 1.0f : 0.0f;
        mRot.y = mRotationY ? 1.0f : 0.0f;
        mRot.z = mRotationZ ? 1.0f : 0.0f;
        mRot = mRot.normalized;
        mRot *= mRotateSpeed;
    }
    Vector3 an;
    private void FixedUpdate()
    {
        if (!mRigidbody) { return; }
        Move();
        Rotate();

    }

    private void Move()
    {
        Vector3 work = mNextPos - transform.position;
        float diff = work.sqrMagnitude;
        if (diff <= 0.001f)
        {
            if (mLoop)
            {
                mVelocity *= INVERSE;
                mNextPos = GetNextPos();
            }
        }
        mRigidbody.velocity = mVelocity;

    }

    private Vector3 GetNextPos()
    {
        if (mNext)
        {
            mNext = false;
            return mTargetPos;
        }
        else
        {
            mNext = true;
            return mStartPos;
        }
    }

    private void Rotate()
    {
        mRigidbody.angularVelocity = mRot;
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position + mDistance, 0.1f);
    }

    new void OnTriggerStay(Collider other)
    {
        base.OnTriggerStay(other);
        //if (other.name == ObjectNames.PLAYER) ;
    }


    private Rigidbody mPlayerRigid;
    private void Start()
    {
        mPlayerRigid = GameObject.Find("Player").GetComponent<Rigidbody>();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Player") { return; }
        //float velSqrMag = mRigidbody.velocity.sqrMagnitude;

        //if (velSqrMag <= 0.01f) { }

        //foreach (ContactPoint point in collision.contacts)
        //{
        //    if (point.point.y < transform.position.y)
        //    {
        //        if (mLoop)
        //        {
        //            if (mVelocity.y > 0.0f) { mVelocity.y *= INVERSE; print("1"); }
        //        }
        //    }

        //    if (point.point.y > transform.position.y)
        //    {
        //        if (mLoop)
        //        {
        //            if (mVelocity.y < 0.0f) { mVelocity.y *= INVERSE; print("2"); }
        //        }
        //    }
        //}

        foreach (ContactPoint point in collision.contacts)
        {
            if (point.point.y < transform.position.y)
            {
                if (mLoop)
                {
                    if (mVelocity.y <= 0.0f) { mVelocity.y *= INVERSE; }
                    return;
                }
            }
            else if (point.point.y > transform.position.y)
            {
                if (mLoop)
                {
                    if (mVelocity.y >= 0.0f) { mVelocity.y *= INVERSE; }
                    return;
                }
            }
        }

    }



    private void OnCollisionStay(Collision collision)
    {
        //Playerがすべらないようにする処理
        if (collision.gameObject.name == "Player")
        {
            if (Mathf.Abs(mRigidbody.velocity.x) < 0.001f) { return; }
            Vector3 vel = mPlayerRigid.velocity;
            vel.x = mRigidbody.velocity.x / 0.5f;
            mPlayerRigid.velocity = vel;
        }



    }


}
