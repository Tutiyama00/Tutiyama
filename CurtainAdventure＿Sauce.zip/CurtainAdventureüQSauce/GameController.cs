﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GameController : MonoBehaviour//ゲームのStateを管理するクラス、IgameStateを持つクラスのstateを一括管理する
{
    [SerializeField]
    int stage;
    //現在のGameControllerのState
    private List<IGameState> Obstacle_list = new List<IGameState>();
    private GameState nowState;
    private UserInput userInput;
    private UIcontroller mUIcontroller;
    private ScoreDate database;
    public int RankPoint { get { return rankPoint; } }
    public int Stage { get { return stage; } }
    public int rankPoint;
    private bool check;


    private void Awake()
    {
        database = FindObjectOfType<ScoreDate>();
        userInput = FindObjectOfType<UserInput>();
        mUIcontroller = FindObjectOfType<UIcontroller>();
        
        //リストにGameStateのあるオブジェクトを格納

    }
    private void Start()//他クラスの値を参照する処理をStart()に分けたナリ
    {
        foreach (var n in GameObject.FindObjectsOfType<Component>())
        {
            IGameState gameState = n as IGameState;

            if (gameState != null)
            {
                Obstacle_list.Add(gameState);
            }
        }
        //ステートをReadyにする
        Ready();
    }

    void Update()
    {
        switch (nowState)
        {
            case GameState.Play://StateがPlayの時
                if (userInput.MenuButton)
                {
                    //メニューステートへ移行
                    Menu();
                }
                break;

            //case GameState.Ready:
            //    break;
            case GameState.Menu:
                if (userInput.MenuButton)
                {
                    //プレイステートへ移行
                    mUIcontroller.MenuAnimationClose();
                    ChangeState(GameState.Play);
                }
                break;
                //case GameState.Success:
                //    break;
                //case GameState.Failure:
                //    break;
        }
    }

    private void ChangeState(GameState state)//全てのGameStateを持つオブジェクトのステートを変更する
    {
        nowState = state;
        foreach (IGameState iGameState in Obstacle_list)
        {
            iGameState.SetGameState = state;
        }
    }

    public void GetrankPoint(int point)//ゲームクリア時評価を上げる
    {
        rankPoint += point;
    }

    public void Menu() //ステートをMenuにする
    {
        ChangeState(GameState.Menu);
        mUIcontroller.MenuAnimationOpen();
    }

    public void Play()//ステートをPlayにする
    {
        ChangeState(GameState.Play);
    }

    public void Ready()//ステートをReadyにする 
    {
        if (rankPoint != 0)
        {
            rankPoint = 0;
        }
        ChangeState(GameState.Ready);
    }

    public void Failure()//ステートをFailureにする
    {
        //音流す
        AudioManager.Instance.PlayBgm(SceneAudio.Instance.FailedBGM);
        mUIcontroller.GameOver();
        ChangeState(GameState.Failure);
    }

    public void Success()//ステートをSuccessにする
    {
        //音流す
        AudioManager.Instance.PlayBgm(SceneAudio.Instance.ClearBGM);
        ChangeState(GameState.Success);
        database.DateUpdate(stage,RankPoint);
    }
    public void Achievement()
    {
        mUIcontroller.Achievement(RankPoint);
    }

    
}
