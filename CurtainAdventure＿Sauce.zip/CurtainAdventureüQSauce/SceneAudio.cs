﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneAudio : SingletonMonoBehaviour<SceneAudio>
{
    [SerializeField]
    private AudioClip mTitleBGM;
    [SerializeField]
    private AudioClip mStageSelectBGM;
    [SerializeField]
    private AudioClip mPlaySceneBGM;
    [SerializeField]
    private AudioClip mClearBGM;
    [SerializeField]
    private AudioClip mFailedBGM;
    [SerializeField]
    private AudioClip mDungeonSelectBGM;

    public AudioClip TitleBGM { get { return mTitleBGM; } }
    public AudioClip StageSelectBGM { get { return mStageSelectBGM; } }
    public AudioClip PlaySceneBGM { get { return mPlaySceneBGM; } }
    public AudioClip ClearBGM { get { return mClearBGM; } }
    public AudioClip FailedBGM { get { return mFailedBGM; } }
    public AudioClip DungeonSelectBGM { get { return mDungeonSelectBGM; } }

    private string[] audioKey_array;
    private AudioClip[] audioValue_array;

    protected override void Awake()
    {
        base.Awake();

        //検索用配列のインスタンス
        audioKey_array = new string[] { "TitleScene", "SelectScene", "TutorialSelectScene", "Clear", "Failed", "DungeonSelectScene", "EasySelectScene", "NomalSelectScene", "HardSelectScene" };
        audioValue_array = new AudioClip[] { mTitleBGM, mStageSelectBGM, mStageSelectBGM, mClearBGM, mFailedBGM ,mDungeonSelectBGM,mStageSelectBGM,mStageSelectBGM,mStageSelectBGM};
    }

    /// <summary>
    /// 配列から対応するBGMを探す
    /// </summary>
    /// <param name="sceneName"></param>
    public AudioClip FindBGM(string sceneName)
    {
        //配列探索
        for (int i = 0; i < audioKey_array.Length; i++)
        {
            //対応するキーがあるか
            if(audioKey_array[i] == sceneName)
            {
                //あったら対応する曲を返す
                return audioValue_array[i];
            }
        }

        //対応するキーがなかった場合プレイBGMと判断し、プレイ中の曲を返す
        return mPlaySceneBGM;
    }
}
