﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Overlap : MonoBehaviour, ICurtainState,IGameState
{
    public bool IsOverlap { get { return mIsOverlap; } }
    public CurtainState SetCurtainState { set { mCurtainState = value; } }
    
    private bool mIsOverlap;
    private Vector3 mSavePos;
    protected CurtainState mCurtainState;
    private Vector3 mSaveVelocity;
    protected Rigidbody mRigidbody;
    private  bool nowCheck = false;

    public GameState SetGameState { set { mGameState = value; } }
    protected GameState mGameState;

    private enum OverLapState { Freeze,Move }

    private OverLapState mOverLapState;

    protected void Awake()
    {
        mSavePos = transform.position;

        //このオブジェクトがRigidbodyをもっていたら取得
        if (GetComponent<Rigidbody>())
        {
            mRigidbody = this.GetComponent<Rigidbody>();
        }
    }


    //ここかえたよツチヤマ（0520）
    protected void OnTriggerStay(Collider other)
    {
        //if(other.gameObject.GetComponent<ISwitchGimmick>() == null)
        //{
            mIsOverlap = true;
        //}
        
    }



    protected void OnTriggerExit(Collider other)
    {
        mIsOverlap = false;
    }



    private void Update()
    {
        OverlapStateCheck();
        UpdateWhileChanging();
        ReturnStateCheck();
    }





    /// <summary>
    /// インスタンスがRigidBodyを持っていなかった場合positionを保存、持っていた場合positionとvelocityを保存する処理
    /// </summary>
    protected void UpdateWhileChanging()
    {
        if (mOverLapState == OverLapState.Freeze)
        {
            if (mRigidbody != null)
            {
                nowCheck = true;
            }
                
            transform.position = mSavePos;
        }
        else
        {
            //このオブジェクトのRigidbodyを取得できていたらvelocityを取得する
            if (mRigidbody != null)
            {
                mSaveVelocity = mRigidbody.velocity;
            } 
            
            mSavePos = transform.position;
        }
    }

    protected void ReturnStateCheck()
    {
        if (nowCheck)
        {
            if (mOverLapState == OverLapState.Move)
            {
                nowCheck = false;
                mRigidbody.velocity = mSaveVelocity;
            }
        } 
    }

    /// <summary>
    /// OverlapStateのチェック
    /// </summary>
    protected void OverlapStateCheck()
    {
        if(mCurtainState == CurtainState.Changing || mGameState != GameState.Play)
        {
            if (mOverLapState != OverLapState.Freeze)
            {
                mOverLapState = OverLapState.Freeze;
            }
        }
        else
        {
            if (mOverLapState != OverLapState.Move)
            {
                mOverLapState = OverLapState.Move;
            }
        }
    }
}
