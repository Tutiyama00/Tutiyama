﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshEffect : MonoBehaviour
{
    private const float SPEED = 1.0f;
    private const float INTERVAL = 4.0f;
    private Material material;

    private float mTimer;

    private void Awake()
    {
        material = GetComponent<Renderer>().material;
    }

    private void FixedUpdate()
    {
        mTimer += Time.deltaTime * SPEED;
        if (mTimer > INTERVAL * SPEED) { mTimer = 0.0f; }
        if (mTimer > 1.0f) { return; }

        mTimer = Mathf.Clamp01(mTimer);
        float scroll = Mathf.Repeat(mTimer, 1);
        Vector2 offset = new Vector2(-scroll, 0.4f);
        material.SetTextureOffset("_MainTex", offset);
    }
}
