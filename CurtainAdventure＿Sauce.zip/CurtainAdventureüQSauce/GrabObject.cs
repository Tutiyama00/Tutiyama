﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GrabObject : Overlap
{

    private const float COLLIDER_SIZE = 0.5f;
    private float mAdjustedValueForPosX;//調整値
    private List<BoxCollider> mBoxCllider_list = new List<BoxCollider>();
    private GrabUI grabUI;//金
    private PlayerMove playMove;
    public bool isOver;
    public bool canMove = false;
    public bool pushPullCheck = false;



    new void Awake()
    {
        base.Awake();
        Initialization();
    }

    private void Update()
    {

        OverlapStateCheck();
        UpdateWhileChanging();
        ReturnStateCheck();
        if (mGameState == GameState.Menu)
        {
            mRigidbody.useGravity = false;
            return;
        }
        if (mCurtainState == CurtainState.Changing) { mRigidbody.useGravity = false; }
        else { mRigidbody.useGravity = true; }

    }


    private void OnDrawGizmos()
    {
        Gizmos.color = Color.black;

        Vector3 scale = transform.lossyScale;
        scale.Scale(GetComponent<BoxCollider>().center);
        Vector3 center = transform.position + scale;
        center.x += 0.95f;

        Gizmos.DrawSphere(transform.position + scale, 0.2f);
        Gizmos.DrawWireCube(center, new Vector3(GetComponent<BoxCollider>().size.x * scale.x * 0.4f, GetComponent<BoxCollider>().size.y * scale.y * 0.4f, GetComponent<BoxCollider>().size.z * scale.z * 0.4f));

    }


    /// <summary>
    /// 初期化メソッド
    /// </summary>
    private void Initialization()
    {
        //自分のBoxClliderを取得
        playMove = FindObjectOfType<PlayerMove>();
        grabUI = FindObjectOfType<GrabUI>();//金
        mBoxCllider_list.AddRange(GetComponents<BoxCollider>());

        mAdjustedValueForPosX = transform.position.x % 1.0f;
    }

    /// <summary>
    /// 押し引きできるかチェック
    /// </summary>
    /// <param name="amount">移動量</param>
    /// <returns></returns>
    public bool TargetPullPushCheck(float amount)
    {
        TargetTriggerSet(true);
        //gameObjectが落下している場合無効
       // if(mRigidbody.velocity.y < -0.1f) { return false; }

        foreach (BoxCollider col in mBoxCllider_list)
        {
            Vector3 scale = transform.lossyScale;
            //local座標のColliderの中心を求める
            scale.Scale(col.center);
            //grobal座標にする
            Vector3 center = transform.position + scale;
            center.x += amount;

            //print(Physics.CheckBox(center, new Vector3(col.size.x * scale.x * 0.4f / 2, col.size.y * scale.y * 0.4f / 2, col.size.z * scale.z * 0.4f / 2), Quaternion.identity, -1, QueryTriggerInteraction.Ignore));
            // print(Physics.CheckBox(center, new Vector3(col.size.x * scale.x * 0.4f *100000, col.size.y * scale.y * 0.4f *1000000, col.size.z * scale.z * 0.4f*1000000), Quaternion.identity, -1, QueryTriggerInteraction.Ignore));


            //amount分Colliderをスライドして重なった場合falseを返す処理
            if (Physics.CheckBox(center, new Vector3(col.size.x * scale.x * 0.2f / 2, col.size.y * scale.y * 0.2f / 2, col.size.z * scale.z * 0.2f / 2), Quaternion.identity, -1, QueryTriggerInteraction.Ignore))
            {
                TargetTriggerSet(false);
                return false;
            }
        }

        TargetTriggerSet(false);
        return true;
    }

    public void TargetTriggerSet(bool set)
    {
        foreach (BoxCollider col in mBoxCllider_list)
        {
            col.isTrigger = set;
        }
        // mRigidbody.useGravity = !set;//(S)
    }


    //以下金田追記
    //private void OnCollisionEnter(Collision collision)
    //{


    //    if (mTopTrigger) { return; }
    //    if (collision.gameObject.name == ObjectNames.PLAYER)
    //    {
    //        playMove.GrabColChange(true);
    //    }
    //}

    private void OnCollisionEnter(Collision collision)
    {
        if (playMove.GetPlayerState != PlayerState.GRAB)
        {
            Vector3 position = transform.position;

            position.x = Mathf.Floor(position.x);
            position.x += mAdjustedValueForPosX;

            transform.position = position;
        }

    }


    //つかめないことが多々あった為追記 shinya
    private void OnCollisionStay(Collision collision)
    {
        if (playMove.mGrabCol) { return; }
        if (collision.gameObject.name == ObjectNames.PLAYER)
        {
            foreach (ContactPoint contact in collision.contacts)
            {
                if (contact.point.y > transform.position.y + 0.6f) { return; }
            }
            playMove.GrabColChange(true);
        }
    }
    private void OnCollisionExit(Collision collision)
    {

        if (collision.gameObject.name == ObjectNames.PLAYER)
        {
            playMove.GrabColChange(false);
            grabUI.GrabOff();
        }
    }
}

