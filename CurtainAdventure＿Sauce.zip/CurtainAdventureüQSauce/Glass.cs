﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Glass : Overlap, ICurtainState
{
    private GameObject mRedGlass;
    private Collider mCollider;
    new void Awake()
    {
        base.Awake();
        mCollider = GetComponent<Collider>();
        if (transform.childCount > 0)
        {
            mRedGlass = transform.GetChild(0).gameObject;
            mRedGlass.SetActive(false);
        }
    }

    private void Update()
    {
        if (mCurtainState == CurtainState.Close)
        {
            mCollider.isTrigger = true;
        }
        else
        {
            mCollider.isTrigger = false;
        }
    }


    new void OnTriggerStay(Collider other)
    {
        base.OnTriggerStay(other);
        mRedGlass.SetActive(true);
    }

    new void OnTriggerExit(Collider other)
    {
        base.OnTriggerExit(other);
        mRedGlass.SetActive(false);
    }
}
