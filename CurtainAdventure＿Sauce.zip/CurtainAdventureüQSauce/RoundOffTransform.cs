﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class RoundOffTransform : EditorWindow
{

    [MenuItem("Custom/RoundOffTransform &_g")]
    private static void OpenWindow()
    {
       new RoundOffTransform().RoundOffPos();
       // GetWindow<RoundOffTransform>();
    }



    private void OnGUI()
    {
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("1");
        EditorGUILayout.Space();
        if (GUILayout.Button("Round Off position !", GUILayout.MaxWidth(200))) { RoundOffPos(); }
    }

    private void RoundOffPos()
    {
        GameObject[] selectedGObjArr = Selection.gameObjects;
        foreach (GameObject gObj in selectedGObjArr)
        {
            Vector3 pos = gObj.transform.position;
            pos.x = Mathf.Round(pos.x);
            pos.y = Mathf.Round(pos.y);
            pos.z = Mathf.Round(pos.z);
            gObj.transform.position = pos;
        }
    }
}
