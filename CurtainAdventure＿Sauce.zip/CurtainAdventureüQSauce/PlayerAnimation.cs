﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimation
{
    private Animator mAnimator;
    private const string JUMP = "Jump";
    private const string IDLE = "Idle";
    private const string RUN = "Run";
    private const string GRAB = "Grab";
    private const string SALUTE = "Salute";
    private const string DEAD = "Dead";
    private const string FORWARD_WALK = "ForwardWalk";
    private const string BACKWARD_WALK = "BackwardWalk";

    private List<string> mAnimNames = new List<string> { JUMP, IDLE, RUN, GRAB, SALUTE, DEAD, FORWARD_WALK, BACKWARD_WALK };
    private bool mPlay = true;
    private bool mStop;

    public PlayerAnimation(Animator animator)
    {
        if (!animator) { Debug.Log("Animatorコンポーネントを取得できませんでした。"); }
        mAnimator = animator;
    }


    public void Jump(bool isJumpping)
    {
        //3つにわける
        mAnimator.SetBool(JUMP, isJumpping);
    }

    public void Idle(bool isIdle)
    {
        mAnimator.SetBool(IDLE, isIdle);
    }

    public void Run(bool isRunning)
    {
        mAnimator.SetBool(RUN, isRunning);
    }

    public void Grab(bool isGrabbing)
    {
        mAnimator.SetBool(GRAB, isGrabbing);
    }

    public void Salute(bool isClear)
    {
        mAnimator.SetBool(SALUTE, isClear);
    }

    public void Dead(bool isDead)
    {
        mAnimator.SetBool(DEAD, isDead);
    }

    public void ForwardWalk(bool isWalking)
    {
        mAnimator.SetBool(FORWARD_WALK, isWalking);
    }

    public void BackwardWalk(bool isWalking)
    {
        mAnimator.SetBool(BACKWARD_WALK, isWalking);
    }


    public void Stop()
    {
        if (mStop) { return; }
        mStop = true;
        mPlay = false;
        mAnimator.SetFloat("PlayStop", 0.0f);
    }

    public void Play()
    {
        if (mPlay) { return; }
        mPlay = true;
        mStop = false;
        mAnimator.SetFloat("PlayStop", 1.0f);
    }





    /// <summary>
    /// 全てのアニメーションの再生をやめる
    /// </summary>
    public void QuitAllAnimation()
    {
        foreach (string name in mAnimNames)
        {
            mAnimator.SetBool(name, false);
        }
    }
}
