﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorSEManeger : MonoBehaviour
{
    public void CursorSEPlay()
    {
        AudioManager.Instance.PlaySe(SEAoudio.Instance.CursorMoveSE);
    } 

    public void ChoiceSEPlay()
    {
        AudioManager.Instance.PlaySe(SEAoudio.Instance.ChoiceSE);
    }
}
