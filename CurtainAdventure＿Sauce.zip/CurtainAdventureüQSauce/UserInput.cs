﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UserInput : MonoBehaviour
{
    //PROPERTY
    public bool JumpButton { get { return mJumpButton; } }
    public bool MenuButton { get { return mMenuButton; } }
    public bool CurtainButton { get { return mCurtainButton; } }
    public bool LeftButton { get { return mLeftButton; } }
    public bool RightButton { get { return mRightButton; } }
    public bool UpButton { get { return mUpButton; } }
    public bool DownButton { get { return mDownButton; } }
    public bool GrabButton { get { return mGrubButton; } }

    //0625tutiヒント用のインプット追加
    private bool mHintButton;
    public bool HintButton { get { return mHintButton; } }

    private bool mJumpButton;
    private bool mMenuButton;
    private bool mCurtainButton;
    private bool mLeftButton;
    private bool mRightButton;
    private bool mUpButton;
    private bool mDownButton;
    private bool mGrubButton;
    //金田追記いたした
    private const float mAxisValue=0.5f;//左右入力を認めるしきい値

    private const float mThreeAxisValue = 0.5f;
    private bool mThreeAxisFrag = false;
    private bool mThreeAxisCheck = true;

    //private void OnEnable()
    //{
    //    UserInput singleton = FindObjectOfType<UserInput>();
    //    if (singleton != this)
    //    {
    //        Debug.Log("UserInputが二つ存在してますよ");
    //        Destroy(this);
    //    }
    //}

    //コントローラー対応させたと思う(金田)
    private void Update()
    {
        ThreeAxisCheck();

        mJumpButton = 
            //Input.GetKey(KeyCode.Space)/*こっから*/|| 
            Input.GetKey(KeyCode.JoystickButton0);

        mMenuButton = 
            //Input.GetKeyDown(KeyCode.M)/*こっから*/|| 
            Input.GetKeyDown(KeyCode.JoystickButton7);

        mCurtainButton = 
            //Input.GetKeyDown(KeyCode.C)/*こっから*/|| 
            Input.GetKeyDown(KeyCode.JoystickButton4) || Input.GetKeyDown(KeyCode.JoystickButton5) || mThreeAxisFrag;

        mLeftButton = 
            //(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) /*ここらへんなくていいかも…*/|| 
            (-mAxisValue>=Input.GetAxis("Horizontal"));

        mRightButton = 
            //(Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))/*ここらへんなくていいかも…*/|| 
            (mAxisValue<= Input.GetAxisRaw("Horizontal"));

        mUpButton = 
            //(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow));

        mDownButton = 
            //(Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow));

        mGrubButton = 
            //Input.GetKey(KeyCode.G)/*こっから*/ || 
            Input.GetKey(KeyCode.JoystickButton1);

        //0625tuti
        mHintButton = 
            //Input.GetKeyDown(KeyCode.H) || 
            Input.GetKeyDown(KeyCode.JoystickButton2);

        mThreeAxisFrag = false;
        
    }

    private void ThreeAxisCheck()
    {
        if(Mathf.Abs(Input.GetAxis("Curtain")) >= mThreeAxisValue && mThreeAxisCheck)
        {
            mThreeAxisFrag = true;
            mThreeAxisCheck = false;
        }

        if(Mathf.Abs(Input.GetAxis("Curtain")) <= mThreeAxisValue && !mThreeAxisCheck)
        {
            mThreeAxisCheck = true;
        }
    }
}
