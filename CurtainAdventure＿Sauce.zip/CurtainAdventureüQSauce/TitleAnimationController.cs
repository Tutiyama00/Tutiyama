﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleAnimationController
{
    private const string SPEED_NAME = "Speed";
    private const float SKIP_SPEED = 1000.0f;
    private Animator mAnimator;
    public TitleAnimationController(Animator animator)
    {
        mAnimator = animator;
    }

    public void SkipAnimation()
    {
        mAnimator.SetFloat(SPEED_NAME, SKIP_SPEED);
    }
}
