﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class TitleButtonSelectScript : MonoBehaviour {

    [SerializeField]
    private GameObject firstSelect;
    public void Select()
    {
        EventSystem.current.SetSelectedGameObject(firstSelect);
    }
}
