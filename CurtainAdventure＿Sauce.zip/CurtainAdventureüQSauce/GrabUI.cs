﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GrabUI : MonoBehaviour {//つかむと動かすのUIの表示非表示をつかさどる

    private GameObject mGrabUI;
    private GameObject mMoveUI;
    //使用するRectTransformの変数群
    private RectTransform mGrabRect;
    private RectTransform mMoveRect;
    private RectTransform mCanvasRect;
    //ここまで
    private Transform mPlayerTransform;
    private Camera mUIcamera;//UIのカメラ
    private Vector2 mScreenPos;
    private Vector2 mLocalPos;
    private const float mPositionDifferenceGrab=220;//プレイヤーのポジションとプレイヤーの頭の上のポジションの差分
    private const float mPositionDifferenceMove = 220/*250*/;//Move用
    // Use this for initialization
    void Start () {
        mUIcamera = GameObject.Find(ObjectNames.UICAMERA).GetComponent<Camera>();
        //移動させるUiを取得
        mGrabUI = GameObject.Find(ObjectNames.GRABHOLD);
        mMoveUI = GameObject.Find(ObjectNames.GRABMOVE);
    　　//使用するオブジェクトのRectTransformを取得       
        mCanvasRect = GameObject.Find(ObjectNames.BESECANVAS).GetComponent<RectTransform>();
        mGrabRect = mGrabUI.GetComponent<RectTransform>();
        mMoveRect = mMoveUI.GetComponent<RectTransform>();
        //プレイヤーのTransformを取得
        mPlayerTransform = GameObject.Find(ObjectNames.PLAYER).GetComponent<Transform>();       

        mGrabUI.SetActive(false);
        mMoveUI.SetActive(false);
    }
    private void Update()
    {
        //掴む関係のUIを移動させる処理//
        UIPosition(mGrabRect,mPositionDifferenceGrab);
        UIPosition(mMoveRect,mPositionDifferenceMove);
        //ここまで//
    }

    public void GrabOn()
    {       
       if(mGrabUI.activeSelf==false&&mMoveUI.activeSelf==false)mGrabUI.SetActive(true);
    }
    public void GrabOff()
    {
        if (mGrabUI.activeSelf==true)mGrabUI.SetActive(false);
    }
    public void MoveOn()
    {
        if (mMoveUI.activeSelf == false) mMoveUI.SetActive(true);
        mGrabUI.SetActive(false);
    }
    public void MoveOff()
    {
        mMoveUI.SetActive(false);
    }

    /// <summary>
    /// プレイヤーの頭の上にGrab関係のUIを移動させるメソッド
    /// </summary>
    /// <param name="UIRect">移動させるUIのRectTransform</param>
    /// <param name="positionDifference">移動させるY軸移動量</param>
    private void UIPosition(RectTransform UIRect ,float positionDifference)
    {
        mScreenPos = RectTransformUtility.WorldToScreenPoint(mUIcamera, mPlayerTransform.position);//World座標からスクリーンの座標へ変換
        RectTransformUtility.ScreenPointToLocalPointInRectangle(mCanvasRect, mScreenPos, mUIcamera, out mLocalPos);//カメラから見た座標に変換する
        UIRect.localPosition = new Vector2(mLocalPos.x, mLocalPos.y + positionDifference);//プレイヤーのPositionとの誤差を修正し移動
    }
}
