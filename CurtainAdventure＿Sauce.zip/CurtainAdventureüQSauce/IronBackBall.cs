﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IronBackBall : MonoBehaviour
{
    private Vector3 mPos;  //自分の位置

    void Start ()
    {
        //設定する
        mPos = this.transform.position;
	}

    void OnCollisionEnter(Collision other)
    {
        //落ちたら入る
     if(other.gameObject.name == "KillBlock")
        {
            //コルーチンが始まる
            StartCoroutine("one");
        }
    }

    IEnumerator one()
    {
        yield return new WaitForSeconds(1f);
        //元の場所へ
        transform.position = mPos;
    }
}
