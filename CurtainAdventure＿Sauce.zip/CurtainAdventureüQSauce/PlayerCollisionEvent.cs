﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCollisionEvent : MonoBehaviour {//プレイヤーが接触によって発生させるイベントをまとめたクラス
    float point;//評価ポイント
    private GameController gameController;

    // Use this for initialization
    void Start () {
        gameController = GameObject.Find(ObjectNames.SCRIPTS).GetComponent<GameController>(); //"GameController" --> Scripts
	}
	
    public void Goal()//ゴール処理
    {
        gameController.Success();
    }

    public void PointGet(int point)//評価ポイント上昇
    {
        gameController.GetrankPoint(point);
    }

    public void Death(DeathPattern death)//死にました
    {
        switch (death)
        {
            case DeathPattern.Stabbing:
                //串刺しアニメーション
                GameOver();
                break;
            case DeathPattern.FallingDeath:
                //転落死パーティクル？
                GameOver();
                break;
        }
        //対応アニメーションの再生
    }

    /// アニメーション後にアニメーション内からイベントとして呼び出し
    void GameOver()//死亡後三途の川を渡り切りました
    {
        gameController.Failure();
    }
    //上と同じく
    public void GameClear()//狂い喜び笑いを終えた後
    {
        gameController.Achievement();
    }

}
