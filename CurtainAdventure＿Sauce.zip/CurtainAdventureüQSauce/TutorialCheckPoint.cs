﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialCheckPoint : MonoBehaviour
{
    [SerializeField]
    private int mnextTextNamber = 0;　//対応するテキストの番号

    private TutorialText mtutorialText;
    private TutorialManeger mTutorialManeger;
    private GameObject mplayer;

    [SerializeField]
    private Vector3 moriginalBoxSize;

    private float moriginalBoxSizeMaxX;
    private float moriginalBoxSizeMaxY;
    private float moriginalBoxSizeMaxZ;
    private float moriginalBoxSizeMinX;
    private float moriginalBoxSizeMinY;
    private float moriginalBoxSizeMinZ;

    [SerializeField]
    private bool returnText = false;
    
    private bool playedText = false; //一度通ったらTrueにする

    private bool mBoxEnterFrag = false; //オリジナルボックスに入ったかどうかのフラグ
    
    private float mAnimMovePoint = 0.7f;  //合計移動量
    private float mAnimFlameMoveAmount = 0.02f;　//１フレームの移動量

    private float mAnimMoveThreshold = 0.01f;

    private float mOriginPositionY;
    private float mAnimMovePositionY;
    private bool mPlayAnim = false;
    private bool mReturnMove = false;
    private bool mEndAnimFrag = false;


    //-------------------------------------------------

    private void Awake()
    {
        //TutorialTextの取得
        mtutorialText = GameObject.FindObjectOfType<TutorialText>();

        //TutorialManegerの取得
        mTutorialManeger = GameObject.FindObjectOfType<TutorialManeger>();

        //Playerの取得(PlayerMoveをPlayerは確実に持っていると想定して)
        mplayer = GameObject.FindObjectOfType<PlayerMove>().gameObject;

        //OriginalBoxの作成
        MakeOriginalBox();
        
    }
    
    private void Update()
    {
        if (mTutorialManeger.CanStartText)
        {
            return;
        }

        if (CheckOriginalBox())
        {
            UpdateText();
        }

        if (mPlayAnim)
        {
            GetAnimation();
        }

        if (mEndAnimFrag)
        {
            EndGetAnimation();
        }

        if (mtutorialText.mArrayPointer == mnextTextNamber && !mPlayAnim && !mEndAnimFrag)
        {
            mPlayAnim = true;
            StartGetAnimation(mAnimFlameMoveAmount, mAnimMovePoint);
        }
        else if(mtutorialText.mArrayPointer != mnextTextNamber && mPlayAnim && !mEndAnimFrag)
        {
            mPlayAnim = false;
            mEndAnimFrag = true;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireCube(transform.position, moriginalBoxSize);
    }


    //------------------------------------------------


    /// <summary>
    /// テキストの更新
    /// </summary>
    private void UpdateText()
    {
        if (returnText)
        {
            //今のテキストが目的のテキストと違うテキストかどうか
            if (mtutorialText.mArrayPointer != mnextTextNamber)
            {
                //音流す
                AudioManager.Instance.PlaySe(SEAoudio.Instance.TutorialCheckPointSE);

                //目的のテキストに変更
                mtutorialText.TextChange(mnextTextNamber);
            }
        }
        else if (!playedText)
        {
            //今のテキストが目的のテキストと違うテキストかどうか
            if (mtutorialText.mArrayPointer != mnextTextNamber)
            {
                //目的のテキストに変更
                mtutorialText.TextChange(mnextTextNamber);
            }
        }
            //初回だけ通る
            if (!playedText)
            {
                playedText = true;
            }
    }


    /// <summary>
    ///　OriginalBox用の数値の初期化
    /// </summary>
    private void MakeOriginalBox()
    {
        moriginalBoxSizeMaxX = transform.localPosition.x + moriginalBoxSize.x / 2;
        moriginalBoxSizeMaxY = transform.localPosition.y + moriginalBoxSize.y / 2;
        moriginalBoxSizeMaxZ = transform.localPosition.z + moriginalBoxSize.z / 2;

        moriginalBoxSizeMinX = transform.localPosition.x - moriginalBoxSize.x / 2;
        moriginalBoxSizeMinY = transform.localPosition.y - moriginalBoxSize.y / 2;
        moriginalBoxSizeMinZ = transform.localPosition.z - moriginalBoxSize.z / 2;
    }


    /// <summary>
    /// OriginalBoxにプレイヤーが触れているのかチェック
    /// </summary>
    private bool CheckOriginalBox()
    {
        //プレイヤーのポジションの取得
        Vector3 playerPos = mplayer.transform.localPosition;

        //範囲内にいるかどうかのチェック
        if(playerPos.x >= moriginalBoxSizeMinX && playerPos.x <= moriginalBoxSizeMaxX)
        {
            if(playerPos.y >= moriginalBoxSizeMinY && playerPos.y <= moriginalBoxSizeMaxY)
            {
                if (playerPos.z >= moriginalBoxSizeMinZ && playerPos.z <= moriginalBoxSizeMaxZ)
                {
                    //初回Entryなのか
                    if (mBoxEnterFrag == false)
                    {
                        mBoxEnterFrag = true;
                    }
                    

                    return true;
                }
            }
        }

        //初回Exitなのか
        if(mBoxEnterFrag == true)
        {
            mBoxEnterFrag = false;
        }

        return false;
    }

    /// <summary>
    /// GetAnimationを開始させる関数
    /// </summary>
    /// <param name="moveAmount">１フレームの移動量</param>
    /// <param name="movePoint">今の地点からの移動量</param>
    private void StartGetAnimation(float moveAmount,float movePoint)
    {
        //目標地点の設定
        mAnimMovePositionY = this.gameObject.transform.localPosition.y + movePoint;

        //元のPositionYを保存
        mOriginPositionY = this.transform.localPosition.y;

        //1フレームの移動量の設定
        mAnimFlameMoveAmount = moveAmount;

        //PlayAnimのフラグを立てて、GetAnimationを使用する
        mPlayAnim = true;
    }


    /// <summary>
    /// GetAnimation本体
    /// </summary>
    private void GetAnimation()
    {
        //今どっちに向かって進んでいるのか
        if (mReturnMove)
        {
            //元の地点に戻る
            if (this.transform.localPosition.y <= mOriginPositionY + mAnimMoveThreshold)
            {
                this.transform.localPosition = new Vector3(this.transform.localPosition.x,mOriginPositionY, this.transform.localPosition.z);
                mReturnMove = false;
            }
            else
            {
                this.transform.localPosition = new Vector3(this.transform.localPosition.x, this.transform.localPosition.y - mAnimFlameMoveAmount, this.transform.localPosition.z);
            }
        }
        else
        {
            //目標地点に行く
            if(this.transform.localPosition.y >= mAnimMovePositionY - mAnimMoveThreshold)
            {
                this.transform.localPosition = new Vector3(this.transform.localPosition.x, mAnimMovePositionY, this.transform.localPosition.z);
                mReturnMove = true;
            }
            else
            {
                this.transform.localPosition = new Vector3(this.transform.localPosition.x, this.transform.localPosition.y + mAnimFlameMoveAmount, this.transform.localPosition.z);
            }
        }
    }

    /// <summary>
    /// GetAnimationの終了関数
    /// </summary>
    private void EndGetAnimation()
    {
        //もしプレイ中だったら切る
        if (mPlayAnim)
        {
            mPlayAnim = false;
        }

        //元のPositionに戻る
        if (this.transform.localPosition.y <= mOriginPositionY + mAnimMoveThreshold)
        {
            this.transform.localPosition = new Vector3(this.transform.localPosition.x, mOriginPositionY, this.transform.localPosition.z);
            mEndAnimFrag = false;
        }
        else
        {
            this.transform.localPosition = new Vector3(this.transform.localPosition.x, this.transform.localPosition.y - mAnimFlameMoveAmount, this.transform.localPosition.z);
        }

    }
}
