﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Linq;
using UnityEngine.UI;

public class ButtonSelect : MonoBehaviour {//ボタンを初期選択するだけなんとかなくしたいよね
    EventSystem mEventSystem;
    [SerializeField]
    List<GameObject> ButtonList = new List<GameObject>();
    // Use this for initialization
    private void Awake()
    {
        mEventSystem = FindObjectOfType<EventSystem>();
        //foreach (GameObject obj in GameObject.FindObjectsOfType(typeof(Button)))
        //{
        //    if (obj.name.Contains("☆")) { ButtonList.Add(obj);}
        //}
    }
    public void ButtonSelectObj()
    {
        foreach (GameObject obj in ButtonList)
        {
            if (!obj.activeInHierarchy) { continue; }
            mEventSystem.SetSelectedGameObject(null);
            mEventSystem.SetSelectedGameObject(obj);
        }
    }
}
