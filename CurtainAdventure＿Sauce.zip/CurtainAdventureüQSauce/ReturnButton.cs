﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ReturnButton : MonoBehaviour
{
    [SerializeField]
    string mReturnStage;
    UserInput singleton;
    private SceneIndirect sceneIn;

    private bool mCanReturn = true; //リターンボタンが有効かどうか

    /*読み込まれてからすぐ戻るとずっと読み込みが走ってしまう為、
     一定時間待ってから押せるようにする shinya*/
    private const float WAIT_TIME = 2.0f;
    private float mTimer;
    private void Start()
    {
        singleton = FindObjectOfType<UserInput>();
        sceneIn = FindObjectOfType<SceneIndirect>();
        mTimer = 0.0f;
    }

    void Update()
    {
        if (mTimer < WAIT_TIME)
        {
            mTimer += Time.deltaTime;
            return;
        }

        if (singleton.GrabButton) { mCanReturn = false; }

        if (singleton.JumpButton && mCanReturn)
        {
            AudioManager.Instance.PlaySe(SEAoudio.Instance.CanselSE);

            sceneIn.Transmission(mReturnStage);
        }
    }
}
