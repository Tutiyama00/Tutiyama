﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{//ゴールを検知するよゴールオブジェクトにつけてね

    private PlayerCollisionEvent collisionEvent;
    private Animator GoalAnime;
    private bool one;
    private const string mGoalTrigger = "Goal";
    // Use this for initialization
    void Start()
    {
        one = false;
        collisionEvent = FindObjectOfType<PlayerCollisionEvent>();
        GoalAnime = GetComponent<Animator>();
    }
    private void OnTriggerEnter(Collider other)
    {
        if (one) { return; }
        if (other.gameObject.name == ObjectNames.PLAYER)
        {
            one = true;
            GoalAnime.SetTrigger(mGoalTrigger);
            collisionEvent.PointGet(1);
            PlayerGoal();
        }
    }
    public void StageClear()//クリアした報告
    {
        collisionEvent.GameClear();
    }
    public void PlayerGoal()
    {
        collisionEvent.Goal();//ゴールした処理
    }
}
