﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace BLADE_DLL_VOL2
{
    //クラスは参照型、構造体は値型
    public unsafe struct BladeStruct
    {
        //配列数（足りなくなったら足しましょう）
        private const int ARRAY_LENGTH = 10000;

        /*mBladePointの順番
         *      1 
         *    3   4
         *      2 
         */

        private static Vector3 mBladePoint1;  //剣の４頂点の１つ目（対応する頂点は２）
        private static Vector3 mBladePoint2;　//剣の４頂点の２つ目（対応する頂点は１）
        private static Vector3 mBladePoint3;　//剣の４頂点の３つ目（対応する頂点は４）
        private static Vector3 mBladePoint4;　//剣の４頂点の４つ目（対応する頂点は３）

        /*targetのMesh*/
        private static Mesh mTargetMesh;

        /*対象のMesh情報を格納する配列群*/
        private static Vector3[]   mVerticeArray = new Vector3[ARRAY_LENGTH];  //頂点情報
        private static Vector3[]   mNormalArray  = new Vector3[ARRAY_LENGTH];　//法線情報
        private static Vector2[]   mUvArray      = new Vector2[ARRAY_LENGTH];　//UV座標情報
        private static int    [][] mSubIndiceArray;　　　　　　　　　　　　　　//SubMesh情報

        /*裏側のオブジェクトのMesh情報を格納する配列群*/
        private static Vector3[]   mReverseVerticeArray  = new Vector3[ARRAY_LENGTH * 2];  //頂点情報
        private static Vector3[]   mReverseNormalArray   = new Vector3[ARRAY_LENGTH * 2];　//法線情報
        private static Vector2[]   mReverseUvArray       = new Vector2[ARRAY_LENGTH * 2];　//UV座標情報
        private static int    []   mReverseTriangleArray = new int    [ARRAY_LENGTH * 2];　//トライアングル情報
        private static int    [][] mReverseSubIndiceArray;　　　　　　　　　　　　　　　　 //SubMesh情報

        /*表側のオブジェクトのMesh情報を格納する配列群*/
        private static Vector3[] 　mFrontVerticeArray  = new Vector3[ARRAY_LENGTH * 2];　//頂点情報
        private static Vector3[]   mFrontNormalArray   = new Vector3[ARRAY_LENGTH * 2];　//法線情報
        private static Vector2[]   mFrontUvArray       = new Vector2[ARRAY_LENGTH * 2];　//UV座標情報
        private static int    []   mFrontTriangleArray = new int    [ARRAY_LENGTH * 2];　//トライアングル情報
        private static int    [][] mFrontSubIndiceArray;　　　　　　　　　　　　　　　　 //SubMesh情報

        /*切断面を構成するMesh情報配列*/
        private static Vector3[] mNewVerticeArray = new Vector3[ARRAY_LENGTH * 2];  //新しい頂点情報
        private static Vector3[] mNewUvArray 　　 = new Vector3[ARRAY_LENGTH * 2];　//新しいUV座標情報

        /*配列の要素数*/
        private static int   mVerticeLength       　　 = 0;  //mVerticeArrayの要素数
        private static int   mSubIndiceLength      　　= 0;　//mSubIndiceArrayの要素数
        private static int   mFrontVerticeLength   　　= 0;  //mFrontVerticeArrayの要素数
        private static int[] mFrontSubIndiceLength; 　　     //mFrontSubIndiceArrayの中の配列の要素数
        private static int   mReverseVerticeLength 　　= 0;  //mReverseVerticeArrayの要素数
        private static int[] mReverseSubIndiceLength;　　    //mReverseSubIndiceArrayの中の配列の要素数
        private static int   mNewVerticeLength     　　= 0;  //mNewVerticeArrayの要素数

        /*------------------ローカル変数の取り出し------------------------
         * 今回は軽量化のため、あらかじめ変数の番地を確保している。
         * それを使いまわすためローカル変数をメンバ変数に出した。
         */

        //Cut()
        private static bool[]  polygonSide = new bool[3]; //取り出した３頂点（トライアングルポリゴン）がそれぞれ切断後に分かれるオブジェクトのどちら側になるのかをまとめるための配列
        private static Vector3 mBladeCenter;　　　　　　　//剣の中心点
        private static Vector3 mBladeNormal;　　　　　　　//剣の法線ベクトル
        private static int mP1;　　　　　　　　　　　　　 //取り出す３頂点（トライアングルポリゴン）の内の１つ目が入っている配列番号
        private static int mP2;　　　　　　　　　　　　　 //取り出す３頂点（トライアングルポリゴン）の内の２つ目が入っている配列番号
        private static int mP3;                           //取り出す３頂点（トライアングルポリゴン）の内の３つ目が入っている配列番号

        //CutPolygon()
        private static int mTrueCount       = 0;             //true（表）の数をカウントする
        private static int mFalseCount      = 0;             //false（裏）の数をカウントする
        private static int mMinorityVertex  = 0;             //表と裏の数を比べて少数派の頂点番号を格納
        private static Vector3 mNewVertex1  = Vector3.zero;  //切断でできた新しい２頂点の１つ目
        private static Vector3 mNewVertex2  = Vector3.zero;　//切断でできた新しい２頂点の２つ目
        private static Vector2 mNewUv1      = Vector2.zero;  //切断でできた新しい２頂点の１つ目のUV座標
        private static Vector2 mNewUv2      = Vector2.zero;　//切断でできた新しい２頂点の２つ目のUV座標
        private static Vector3 mNewNormal1  = Vector3.zero;　//切断でできた新しい２頂点の１つ目の法線ベクトル
        private static Vector3 mNewNormal2  = Vector3.zero;　//切断でできた新しい２頂点の２つ目の法線ベクトル
        private static float mNormalizedDis = 0;　　　　　　 //切断頂点までの距離／辺の長さ＝比率（辺の長さを１として、切断頂点までの距離はどれくらいなのか）
        private static float mTm;                            //切断頂点までの距離

        //MakeCutObject()
        private static Mesh 　     mFrontMesh;　　　　　//表側オブジェクトのMesh
        private static Mesh        mReverseMesh;　　　　//裏側オブジェクトのMesh
        private static Vector3[]   mMakeVerticeArray;　 //Mesh情報作成用の頂点情報
        private static Vector3[]   mMakeNormalArray;　　//Mesh情報作成用の法線情報
        private static Vector2[]   mMakeUvArray;        //Mesh情報作成用のUV座標情報
        private static int    []   mMakeTriangleArray;  //Mesh情報作成用のトライアングル情報
        private static int    [][] mMakeSubIndice;      //Mesh情報作成用のSubMesh情報
        private static Vector3     mSum;                //切断面の中心を求めるために一度切断面の頂点を合計する時に使用する
        private static Vector3     mNewFaceCenter;      //切断面の中心座標
        private static Vector3     mMaxUv;              //求めたUV座標の中の最大値
        private static Vector3     mMinUv;              //求めたUV座標の中の最小値
        private static bool        mMinPlusX;           //求めたUV座標の中の最小値のX値が正の値だった場合True
        private static bool        mMinPlusY;           //求めたUV座標の中の最小値のY値が正の値だった場合True
        private static Vector3     mUp;                 //切断面のUV座標を求めるために法線を利用した剣の表方向に延びるベクトル
        private static Vector3     mLeft;               //切断面のUV座標を求めるために剣の横軸に延びるベクトル
        private static Vector3     mDisplacement;       //切断面のある１頂点から中心までの距離
        private static Vector3     mUv1;                //新UV座標の１つ目
        private static Vector3     mUv2;                //新UV座標の２つ目
        private static Vector2     mUvCenter = new Vector2(0.5f, 0.5f);
        private static GameObject  mTargetSub;

        //BladeNormalGet()
        private static Vector3 mVec1;
        private static Vector3 mVec2;
        private static Vector3 mNormal;

        //CutPointGet()
        private static Vector3 mM;
        private static float mH;
        private static float mT;
        private static Vector3 mX;

        //SideCheck()
        private static Vector3 mVector;
        private static float mInnerProduct;

       
       


        /// <summary>
        /// 対象オブジェクトを分割する
        /// </summary>
        /// <param name="target">対象オブジェクト</param>
        public void Cut(GameObject target, GameObject blade, GameObject point1, GameObject point2, GameObject point3, GameObject point4, Material cutMaterial)
        {
            //targetのMesh情報の取得
            TargetMeshGet(target);

            //剣の四点の設定
            PointAdjust(target, blade, point1, point2, point3, point4);

            //切断面の中心ポジ
            mBladeCenter = (mBladePoint1 + mBladePoint2 + mBladePoint3 + mBladePoint4) / 4;

            //切断面の法線
            mBladeNormal = BladeNormalGet(mBladePoint1, mBladePoint2, mBladePoint3, mBladePoint4, mBladeCenter);

            //ポリゴンごとに表裏に分ける
            for (int sub = 0; sub < mSubIndiceLength; sub++)
            {
                for (int index = 0; (index + 2) < mSubIndiceArray[sub].Length; index += 3)
                {
                    mP1 = mSubIndiceArray[sub][index];
                    mP2 = mSubIndiceArray[sub][index + 1];
                    mP3 = mSubIndiceArray[sub][index + 2];

                    polygonSide[0] = SideCheck(mVerticeArray[mP1], mBladeNormal, mBladeCenter);
                    polygonSide[1] = SideCheck(mVerticeArray[mP2], mBladeNormal, mBladeCenter);
                    polygonSide[2] = SideCheck(mVerticeArray[mP3], mBladeNormal, mBladeCenter);

                    //１ポリゴンの頂点が同じ方向にあるかどうか
                    if (polygonSide[0] == polygonSide[1] && polygonSide[0] == polygonSide[2] && polygonSide[1] == polygonSide[2])
                    {
                        //三角ポリゴンンの追加
                        AddTriangle(mP1, mP2, mP3, sub, polygonSide[0]);
                    }
                    else
                    {
                        //ポリゴンを切断する
                        CutPolygon(mP1, mP2, mP3, sub, polygonSide, mBladeNormal,mBladeCenter);
                    }
                }
            }

            MakeCutObject(target, mBladeNormal, cutMaterial,mBladeCenter);
        }

        /// <summary>
        /// 剣の四点の設定
        /// </summary>
        /// <param name="target">切断する対象</param>
        private static void PointAdjust(GameObject target, GameObject blade, GameObject point1, GameObject point2, GameObject point3, GameObject point4)
        {
            //pointごとに対象オブジェクトの相対位置（ワールド座標）を求める
            mBladePoint1 = blade.transform.TransformPoint(point1.transform.localPosition) - target.transform.position;
            mBladePoint2 = blade.transform.TransformPoint(point2.transform.localPosition) - target.transform.position;
            mBladePoint3 = blade.transform.TransformPoint(point3.transform.localPosition) - target.transform.position;
            mBladePoint4 = blade.transform.TransformPoint(point4.transform.localPosition) - target.transform.position;
        }

        /// <summary>
        /// 法線を取得する
        /// </summary>
        /// <param name="pos1">面の頂点</param>
        /// <param name="pos2">pos1に対応する面の頂点</param>
        /// <param name="pos3">面の頂点</param>
        /// <param name="pos4">pos3に対応する面の頂点</param>
        /// <returns>法線</returns>
        private static Vector3 BladeNormalGet(Vector3 pos1, Vector3 pos2, Vector3 pos3, Vector3 pos4, Vector3 center)
        {
            mVec1 = pos1 - pos2;
            mVec2 = pos3 - pos4;

            mNormal = Vector3.Cross(mVec1, mVec2);

            return mNormal;
        }

        /// <summary>
        /// 対象オブジェクトのMesh情報の取得
        /// </summary>
        /// <param name="target">対象オブジェクト</param>
        private static void TargetMeshGet(GameObject target)
        {
            //配列の長さのリセット
            mVerticeLength = 0;
            mSubIndiceLength = 0;
            mFrontVerticeLength = 0;
            mReverseVerticeLength = 0;
            mNewVerticeLength = 0;

            //mTargetMeshの取得
            if (target.GetComponent<MeshFilter>())
            {
                mTargetMesh = target.GetComponent<MeshFilter>().mesh;
            }
            else if (target.GetComponent<SkinnedMeshRenderer>())
            {
                mTargetMesh = target.GetComponent<SkinnedMeshRenderer>().sharedMesh;
            }

            //Vertice,normal,uvの取得
            mVerticeLength = mTargetMesh.vertexCount;


            //各Mesh情報の取得（ポインターで取得することにより激軽量化）
            fixed (Vector3* arrayPointerToX = mTargetMesh.vertices)
            {
                fixed (Vector3* arrayPointerFromX = mVerticeArray)
                {
                    Vector3* arrayPointerFrom;
                    Vector3* arrayPointerTo;

                    for (int i = 0; i < mTargetMesh.vertexCount; i++)
                    {
                        arrayPointerFrom = arrayPointerFromX + i;
                        arrayPointerTo = arrayPointerToX + i;

                        *arrayPointerFrom = *arrayPointerTo;
                    }
                }
            }

            fixed (Vector2* arrayPointerToX = mTargetMesh.uv)
            {
                fixed (Vector2* arrayPointerFromX = mUvArray)
                {
                    Vector2* arrayPointerFrom;
                    Vector2* arrayPointerTo;
                    for (int i = 0; i < mTargetMesh.vertexCount; i++)
                    {
                        arrayPointerFrom = arrayPointerFromX + i;
                        arrayPointerTo = arrayPointerToX + i;

                        *arrayPointerFrom = *arrayPointerTo;
                    }
                }
            }

            fixed (Vector3* arrayPointerToX = mTargetMesh.normals)
            {
                fixed (Vector3* arrayPointerFromX = mNormalArray)
                {
                    Vector3* arrayPointerFrom;
                    Vector3* arrayPointerTo;
                    for (int i = 0; i < mTargetMesh.vertexCount; i++)
                    {
                        arrayPointerFrom = arrayPointerFromX + i;
                        arrayPointerTo = arrayPointerToX + i;

                        *arrayPointerFrom = *arrayPointerTo;
                    }
                }
            }

            //subMesh配列のインスタンス化（モデルによって違いが出てくるため、最大モデルが決められない）
            mSubIndiceArray = new int[mTargetMesh.subMeshCount][];
            mFrontSubIndiceArray = new int[mTargetMesh.subMeshCount + 1][];
            mReverseSubIndiceArray = new int[mTargetMesh.subMeshCount + 1][];
            mFrontSubIndiceLength = new int[mTargetMesh.subMeshCount + 1];
            mReverseSubIndiceLength = new int[mTargetMesh.subMeshCount + 1];
            mSubIndiceLength = mTargetMesh.subMeshCount;
            for (int sub = 0; sub < mTargetMesh.subMeshCount; sub++)
            {
                mSubIndiceArray[sub] = mTargetMesh.GetIndices(sub);
                mFrontSubIndiceArray[sub] = new int[mTargetMesh.triangles.Length * 2];
                mReverseSubIndiceArray[sub] = new int[mTargetMesh.triangles.Length * 2];
            }
            mFrontSubIndiceArray[mTargetMesh.subMeshCount] = new int[mTargetMesh.triangles.Length * 2];
            mReverseSubIndiceArray[mTargetMesh.subMeshCount] = new int[mTargetMesh.triangles.Length * 2];
        }

        /// <summary>
        /// 頂点が切断面の表裏どちらにあるのか調べる
        /// </summary>
        /// <param name="vertex">調べる頂点</param>
        /// <param name="normal">法線</param>
        /// <param name="pos">切断面の中心ポジ</param>
        /// <returns>true = 表,false = 裏</returns>
        private static bool SideCheck(Vector3 vertex, Vector3 normal, Vector3 centerPos)
        {
            //方向ベクトルの計算
            mVector = vertex - centerPos;

            //方向ベクトルと法線の内積をとる
            mInnerProduct = mVector.x * normal.x + mVector.y * normal.y + mVector.z * normal.z;

            //内積が0以下だった場合は表面判定
            if (mInnerProduct <= 0.0f)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        /// <summary>
        /// 三角ポリゴンの追加
        /// </summary>
        /// <param name="vertexNamber1">頂点番号１</param>
        /// <param name="vertexNamber2">頂点番号２</param>
        /// <param name="vertexNamber3">頂点番号３</param>
        /// <param name="subMeshNamber">subMesh番号</param>
        /// <param name="side">true=表,false=裏</param>
        private static void AddTriangle(int vertexNamber1, int vertexNamber2, int vertexNamber3, int subMeshNamber, bool side)
        {
            //表か裏で追加する配列を変える
            if (side)
            {
                mFrontSubIndiceArray[subMeshNamber][mFrontSubIndiceLength[subMeshNamber]] = mFrontVerticeLength;
                mFrontSubIndiceArray[subMeshNamber][mFrontSubIndiceLength[subMeshNamber] + 1] = mFrontVerticeLength + 1;
                mFrontSubIndiceArray[subMeshNamber][mFrontSubIndiceLength[subMeshNamber] + 2] = mFrontVerticeLength + 2;

                mFrontTriangleArray[mFrontVerticeLength] = mFrontVerticeLength;
                mFrontTriangleArray[mFrontVerticeLength + 1] = mFrontVerticeLength + 1;
                mFrontTriangleArray[mFrontVerticeLength + 2] = mFrontVerticeLength + 2;

                mFrontVerticeArray[mFrontVerticeLength] = mVerticeArray[vertexNamber1];
                mFrontVerticeArray[mFrontVerticeLength + 1] = mVerticeArray[vertexNamber2];
                mFrontVerticeArray[mFrontVerticeLength + 2] = mVerticeArray[vertexNamber3];

                mFrontNormalArray[mFrontVerticeLength] = mNormalArray[vertexNamber1];
                mFrontNormalArray[mFrontVerticeLength + 1] = mNormalArray[vertexNamber2];
                mFrontNormalArray[mFrontVerticeLength + 2] = mNormalArray[vertexNamber3];

                mFrontUvArray[mFrontVerticeLength] = mUvArray[vertexNamber1];
                mFrontUvArray[mFrontVerticeLength + 1] = mUvArray[vertexNamber2];
                mFrontUvArray[mFrontVerticeLength + 2] = mUvArray[vertexNamber3];

                mFrontVerticeLength += 3;
                mFrontSubIndiceLength[subMeshNamber] += 3;
            }
            else
            {
                mReverseSubIndiceArray[subMeshNamber][mReverseSubIndiceLength[subMeshNamber]] = mReverseVerticeLength;
                mReverseSubIndiceArray[subMeshNamber][mReverseSubIndiceLength[subMeshNamber] + 1] = mReverseVerticeLength + 1;
                mReverseSubIndiceArray[subMeshNamber][mReverseSubIndiceLength[subMeshNamber] + 2] = mReverseVerticeLength + 2;

                mReverseTriangleArray[mReverseVerticeLength] = mReverseVerticeLength;
                mReverseTriangleArray[mReverseVerticeLength + 1] = mReverseVerticeLength + 1;
                mReverseTriangleArray[mReverseVerticeLength + 2] = mReverseVerticeLength + 2;

                mReverseVerticeArray[mReverseVerticeLength] = mVerticeArray[vertexNamber1];
                mReverseVerticeArray[mReverseVerticeLength + 1] = mVerticeArray[vertexNamber2];
                mReverseVerticeArray[mReverseVerticeLength + 2] = mVerticeArray[vertexNamber3];

                mReverseNormalArray[mReverseVerticeLength] = mNormalArray[vertexNamber1];
                mReverseNormalArray[mReverseVerticeLength + 1] = mNormalArray[vertexNamber2];
                mReverseNormalArray[mReverseVerticeLength + 2] = mNormalArray[vertexNamber3];

                mReverseUvArray[mReverseVerticeLength] = mUvArray[vertexNamber1];
                mReverseUvArray[mReverseVerticeLength + 1] = mUvArray[vertexNamber2];
                mReverseUvArray[mReverseVerticeLength + 2] = mUvArray[vertexNamber3];

                mReverseVerticeLength += 3;
                mReverseSubIndiceLength[subMeshNamber] += 3;
            }
        }

        /// <summary>
        /// 三角ポリゴンの追加(新規)
        /// </summary>
        /// <param name="verteces">新しい頂点群</param>
        /// <param name="uvs">新しいUV情報群</param>
        /// <param name="normals">新しい法線群</param>
        /// <param name="subMeshNamber">subMeshの番号</param>
        /// <param name="side">表側か裏側か</param>
        private static void AddTriangle(Vector3[] verteces, Vector2[] uvs, Vector3[] normals, int subMeshNamber, bool side)
        {
            if (side)
            {
                //表面の切断面の作成

                for (int i = 0; i < verteces.Length; i++)
                {
                    mFrontVerticeArray[mFrontVerticeLength + i] = verteces[i];
                }

                for (int i = 0; i < uvs.Length; i++)
                {
                    mFrontUvArray[mFrontVerticeLength + i] = uvs[i];
                }

                for (int i = 0; i < normals.Length; i++)
                {
                    mFrontNormalArray[mFrontVerticeLength + i] = normals[i];
                }

                mFrontSubIndiceArray[subMeshNamber][mFrontSubIndiceLength[subMeshNamber]] = mFrontVerticeLength;
                mFrontSubIndiceArray[subMeshNamber][mFrontSubIndiceLength[subMeshNamber] + 1] = mFrontVerticeLength + 1;
                mFrontSubIndiceArray[subMeshNamber][mFrontSubIndiceLength[subMeshNamber] + 2] = mFrontVerticeLength + 2;

                mFrontTriangleArray[mFrontVerticeLength] = mFrontVerticeLength;
                mFrontTriangleArray[mFrontVerticeLength + 1] = mFrontVerticeLength + 1;
                mFrontTriangleArray[mFrontVerticeLength + 2] = mFrontVerticeLength + 2;

                mFrontVerticeLength += 3;
                mFrontSubIndiceLength[subMeshNamber] += 3;
            }
            else
            {
                //裏面の切断面の作成

                for (int i = 0; i < verteces.Length; i++)
                {
                    mReverseVerticeArray[mReverseVerticeLength + i] = verteces[i];
                }

                for (int i = 0; i < uvs.Length; i++)
                {
                    mReverseUvArray[mReverseVerticeLength + i] = uvs[i];
                }

                for (int i = 0; i < normals.Length; i++)
                {
                    mReverseNormalArray[mReverseVerticeLength + i] = normals[i];
                }

                mReverseSubIndiceArray[subMeshNamber][mReverseSubIndiceLength[subMeshNamber]] = mReverseVerticeLength;
                mReverseSubIndiceArray[subMeshNamber][mReverseSubIndiceLength[subMeshNamber] + 1] = mReverseVerticeLength + 1;
                mReverseSubIndiceArray[subMeshNamber][mReverseSubIndiceLength[subMeshNamber] + 2] = mReverseVerticeLength + 2;

                mReverseTriangleArray[mReverseVerticeLength] = mReverseVerticeLength;
                mReverseTriangleArray[mReverseVerticeLength + 1] = mReverseVerticeLength + 1;
                mReverseTriangleArray[mReverseVerticeLength + 2] = mReverseVerticeLength + 2;

                mReverseVerticeLength += 3;
                mReverseSubIndiceLength[subMeshNamber] += 3;
            }
        }

        /// <summary>
        /// 三角ポリゴンをカットする
        /// </summary>
        /// <param name="vertexNamber1">三角ポリゴンの頂点１</param>
        /// <param name="vertexNamber2">三角ポリゴンの頂点２</param>
        /// <param name="vertexNamber3">三角ポリゴンの頂点３</param>
        /// <param name="subMeshNamber">subMeshの番号</param>
        /// <param name="sideArray">表側か裏側か分けた配列</param>
        /// <param name="normal">法線</param>
        private static void CutPolygon(int vertexNamber1, int vertexNamber2, int vertexNamber3, int subMeshNamber, bool[] sideArray, Vector3 normal,Vector3 center)
        {
            mTrueCount = 0;  //true（表）の数をカウントする
            mFalseCount = 0; //false（裏）の数をカウントする
            mMinorityVertex = 0;  //表と裏の数を比べて少数派の頂点番号を格納
            mNewVertex1 = Vector3.zero;
            mNewVertex2 = Vector3.zero;
            mNewUv1 = Vector2.zero;
            mNewUv2 = Vector2.zero;
            mNewNormal1 = Vector3.zero;
            mNewNormal2 = Vector3.zero;
            mNormalizedDis = 0;
            mTm = 0;

            //表か裏かカウントする
            foreach (bool bol in sideArray)
            {
                if (bol)
                {
                    mTrueCount++;
                }
                else
                {
                    mFalseCount++;
                }
            }

            //どちらが少数派か調べて少数派の頂点番号を探索
            if (mTrueCount < mFalseCount)
            {
                for (int i = 0; i < sideArray.Length; i++)
                {
                    if (sideArray[i])
                    {
                        mMinorityVertex = i;
                    }
                }
            }
            else
            {
                for (int i = 0; i < sideArray.Length; i++)
                {
                    if (!sideArray[i])
                    {
                        mMinorityVertex = i;
                    }
                }
            }

            switch (mMinorityVertex)
            {
                case 0:
                    mNewVertex1 = CutPointGet(mVerticeArray[vertexNamber1], mVerticeArray[vertexNamber2], normal,center);
                    mNewVertex2 = CutPointGet(mVerticeArray[vertexNamber1], mVerticeArray[vertexNamber3], normal,center);

                    //切断頂点までの距離
                    mTm = TMget(mVerticeArray[vertexNamber1], mVerticeArray[vertexNamber2], normal,center);
                    //切断頂点までの距離／辺の長さ＝比率（辺の長さを１として、切断頂点までの距離はどれくらいなのか）
                    mNormalizedDis = mTm / (mVerticeArray[vertexNamber1] - mVerticeArray[vertexNamber2]).magnitude;
                    //比率分、Lerpで補間させる
                    mNewNormal1 = Vector2.Lerp(mNormalArray[vertexNamber1], mNormalArray[vertexNamber2], mNormalizedDis);
                    mNewUv1 = Vector2.Lerp(mUvArray[vertexNamber1], mUvArray[vertexNamber2], mNormalizedDis);

                    mTm = TMget(mVerticeArray[vertexNamber1], mVerticeArray[vertexNamber3], normal,center);
                    mNormalizedDis = mTm / (mVerticeArray[vertexNamber1] - mVerticeArray[vertexNamber3]).magnitude;

                    mNewNormal2 = Vector2.Lerp(mNormalArray[vertexNamber1], mNormalArray[vertexNamber3], mNormalizedDis);
                    mNewUv2 = Vector2.Lerp(mUvArray[vertexNamber1], mUvArray[vertexNamber3], mNormalizedDis);

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber1], mNewVertex1, mNewVertex2 },
                    new Vector2[] { mUvArray[vertexNamber1], mNewUv1, mNewUv2 },
                    new Vector3[] { mNormalArray[vertexNamber1], mNewNormal1, mNewNormal2 },
                    subMeshNamber,
                    sideArray[0]
                    );

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber3], mNewVertex2, mNewVertex1 },
                    new Vector2[] { mUvArray[vertexNamber3], mNewUv2, mNewUv1 },
                    new Vector3[] { mNormalArray[vertexNamber3], mNewNormal2, mNewNormal1 },
                    subMeshNamber,
                    sideArray[1]
                    );

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber3], mNewVertex1, mVerticeArray[vertexNamber2] },
                    new Vector2[] { mUvArray[vertexNamber3], mNewUv1, mUvArray[vertexNamber2] },
                    new Vector3[] { mNormalArray[vertexNamber3], mNewNormal1, mNormalArray[vertexNamber2] },
                    subMeshNamber,
                    sideArray[1]
                    );
                    break;

                case 1:
                    mNewVertex1 = CutPointGet(mVerticeArray[vertexNamber2], mVerticeArray[vertexNamber3], normal,center);
                    mNewVertex2 = CutPointGet(mVerticeArray[vertexNamber2], mVerticeArray[vertexNamber1], normal,center);



                    mTm = TMget(mVerticeArray[vertexNamber2], mVerticeArray[vertexNamber3], normal,center);
                    mNormalizedDis = mTm / (mVerticeArray[vertexNamber2] - mVerticeArray[vertexNamber3]).magnitude;

                    mNewNormal1 = Vector2.Lerp(mNormalArray[vertexNamber2], mNormalArray[vertexNamber3], mNormalizedDis);
                    mNewUv1 = Vector2.Lerp(mUvArray[vertexNamber2], mUvArray[vertexNamber3], mNormalizedDis);



                    mTm = TMget(mVerticeArray[vertexNamber2], mVerticeArray[vertexNamber1], normal,center);
                    mNormalizedDis = mTm / (mVerticeArray[vertexNamber2] - mVerticeArray[vertexNamber1]).magnitude;

                    mNewNormal2 = Vector2.Lerp(mNormalArray[vertexNamber2], mNormalArray[vertexNamber1], mNormalizedDis);
                    mNewUv2 = Vector2.Lerp(mUvArray[vertexNamber2], mUvArray[vertexNamber1], mNormalizedDis);


                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber2], mNewVertex1, mNewVertex2 },
                    new Vector2[] { mUvArray[vertexNamber2], mNewUv1, mNewUv2 },
                    new Vector3[] { mNormalArray[vertexNamber2], mNewNormal1, mNewNormal2 },
                    subMeshNamber,
                    sideArray[1]
                    );

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber1], mNewVertex2, mNewVertex1 },
                    new Vector2[] { mUvArray[vertexNamber1], mNewUv2, mNewUv1 },
                    new Vector3[] { mNormalArray[vertexNamber1], mNewNormal2, mNewNormal1 },
                    subMeshNamber,
                    sideArray[2]
                    );

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber1], mNewVertex1, mVerticeArray[vertexNamber3] },
                    new Vector2[] { mUvArray[vertexNamber1], mNewUv1, mUvArray[vertexNamber3] },
                    new Vector3[] { mNormalArray[vertexNamber1], mNewNormal1, mNormalArray[vertexNamber3] },
                    subMeshNamber,
                    sideArray[2]
                    );
                    break;

                case 2:
                    mNewVertex1 = CutPointGet(mVerticeArray[vertexNamber3], mVerticeArray[vertexNamber1], normal,center);
                    mNewVertex2 = CutPointGet(mVerticeArray[vertexNamber3], mVerticeArray[vertexNamber2], normal,center);



                    mTm = TMget(mVerticeArray[vertexNamber3], mVerticeArray[vertexNamber1], normal,center);
                    mNormalizedDis = mTm / (mVerticeArray[vertexNamber3] - mVerticeArray[vertexNamber1]).magnitude;

                    mNewNormal1 = Vector2.Lerp(mNormalArray[vertexNamber3], mNormalArray[vertexNamber1], mNormalizedDis);
                    mNewUv1 = Vector2.Lerp(mUvArray[vertexNamber3], mUvArray[vertexNamber1], mNormalizedDis);



                    mTm = TMget(mVerticeArray[vertexNamber3], mVerticeArray[vertexNamber2], normal,center);
                    mNormalizedDis = mTm / (mVerticeArray[vertexNamber3] - mVerticeArray[vertexNamber2]).magnitude;

                    mNewNormal2 = Vector2.Lerp(mNormalArray[vertexNamber3], mNormalArray[vertexNamber2], mNormalizedDis);
                    mNewUv2 = Vector2.Lerp(mUvArray[vertexNamber3], mUvArray[vertexNamber2], mNormalizedDis);

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber3], mNewVertex1, mNewVertex2 },
                    new Vector2[] { mUvArray[vertexNamber3], mNewUv1, mNewUv2 },
                    new Vector3[] { mNormalArray[vertexNamber3], mNewNormal1, mNewNormal2 },
                    subMeshNamber,
                    sideArray[2]
                    );

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber2], mNewVertex2, mNewVertex1 },
                    new Vector2[] { mUvArray[vertexNamber2], mNewUv2, mNewUv1 },
                    new Vector3[] { mNormalArray[vertexNamber2], mNewNormal2, mNewNormal1 },
                    subMeshNamber,
                    sideArray[0]
                    );

                    AddTriangle(
                    new Vector3[] { mVerticeArray[vertexNamber2], mNewVertex1, mVerticeArray[vertexNamber1] },
                    new Vector2[] { mUvArray[vertexNamber2], mNewUv1, mUvArray[vertexNamber1] },
                    new Vector3[] { mNormalArray[vertexNamber2], mNewNormal1, mNormalArray[vertexNamber1] },
                    subMeshNamber,
                    sideArray[0]
                    );
                    break;
            }

            //切断面を構成する頂点として新頂点を追加
            mNewVerticeArray[mNewVerticeLength] = mNewVertex1;
            mNewVerticeArray[mNewVerticeLength + 1] = mNewVertex2;

            mNewVerticeLength += 2;
        }

        /// <summary>
        /// 切断点を取得する
        /// </summary>
        /// <param name="vertex1">頂点１</param>
        /// <param name="vertex2">頂点２</param>
        /// <param name="normal">法線</param>
        /// <returns>切断点の座標ベクトル</returns>
        private static Vector3 CutPointGet(Vector3 vertex1, Vector3 vertex2, Vector3 normal,Vector3 center)
        {
            /*
             *  ☆切断点の求め方☆
             *　t = ( h - ( n * x0 ) ) / ( n * m )  →　x0 + tm = x
             *
             *  t...媒介変数
             *  h...位置ベクトルと法線の内積
             *  n...法線←切断面の法線
             *  x0..始点←対象オブジェクトの頂点
             *  m...始点からの方向ベクトル←対象オブジェクトの頂点　―　対応する対象オブジェクトの頂点
             *  x...点の位置ベクトル←切断面上の点（切断点）
             */

            mM = vertex1 - vertex2;

            mH = Vector3.Dot(center, normal);

            mT = (mH - Vector3.Dot(normal, vertex1)) / Vector3.Dot(normal, mM);

            mX = vertex1 + mT * mM;

            return mX;
        }

        /// <summary>
        /// tmを取得する（時間あったら名前とか変えたい気分）
        /// </summary>
        /// <param name="vertex1">頂点１</param>
        /// <param name="vertex2">頂点２</param>
        /// <param name="normal">法線</param>
        /// <returns>tm</returns>
        private static float TMget(Vector3 vertex1, Vector3 vertex2, Vector3 normal,Vector3 center)
        {
            /*
             *  ☆切断点の求め方☆
             *　t = ( h - ( n * x0 ) ) / ( n * m )  →　x0 + tm = x
             *
             *  t...媒介変数
             *  h...位置ベクトルと法線の内積←今回はこの内積が０になった場合切断面上にあるので＝０とする。
             *  n...法線←切断面の法線
             *  x0..始点←対象オブジェクトの頂点
             *  m...始点からの方向ベクトル←対象オブジェクトの頂点　―　対応する対象オブジェクトの頂点
             *  x...点の位置ベクトル←切断面上の点（切断点）
             */

            mM = vertex1 - vertex2;

            mH = Vector3.Dot(center, normal);

            mT = (mH - Vector3.Dot(normal, vertex1)) / Vector3.Dot(normal, mM);

            return (mT * mM).magnitude;
        }


        /// <summary>
        /// 切断後の分かれたオブジェクトを生成する
        /// </summary>
        /// <param name="targetObj">分割するオブジェクト</param>
        /// <param name="normal">法線</param>
        private static void MakeCutObject(GameObject targetObj, Vector3 normal, Material cutMaterial,Vector3 center)
        {
            //切断面の中心点の取得
            mSum = Vector3.zero;
            for (int i = 0; i < mNewVerticeLength; i++)
            {
                mSum += mNewVerticeArray[i];
            }
            mNewFaceCenter = mSum / mNewVerticeLength;
            //end切断面の中心点の取得

            //UV座標計算用の変数（ベクトルとしては使わないから注意）
            mMaxUv = Vector3.zero;
            mMinUv = Vector3.zero;
            mMinPlusX = false;
            mMinPlusY = false;

            /*UV座標を求めるために使う変数*/
            mUp           = new Vector3(normal.y, -normal.x, normal.z) + center + center;
            mLeft         = Vector3.Cross(normal + center + center, mUp + center + center);
            mDisplacement = Vector3.zero;

            //切断面の作成
            for (int i = 0; (i + 1) < mNewVerticeLength; i += 2)
            {
                mDisplacement = mNewVerticeArray[i] - mNewFaceCenter;
                
                mUv1 = new Vector3(0.5f + Vector3.Dot(mDisplacement, mLeft), 0.5f + Vector3.Dot(mDisplacement, mUp), 0.5f + Vector3.Dot(mDisplacement, normal));


                if (mMaxUv.x < mUv1.x)
                {
                    mMaxUv.x = mUv1.x;
                }
                else if (mMinUv.x > mUv1.x)
                {
                    mMinUv.x = mUv1.x;
                }

                if (mMaxUv.y < mUv1.y)
                {
                    mMaxUv.y = mUv1.y;
                }
                else if (mMinUv.y > mUv1.y)
                {
                    mMinUv.y = mUv1.y;
                }

                mDisplacement = mNewVerticeArray[i + 1] - mNewFaceCenter;

                mUv2 = new Vector3(0.5f + Vector3.Dot(mDisplacement, mLeft), 0.5f + Vector3.Dot(mDisplacement, mUp), 0.5f + Vector3.Dot(mDisplacement, normal));

                if (mMaxUv.x < mUv2.x)
                {
                    mMaxUv.x = mUv2.x;
                }
                else if (mMinUv.x > mUv2.x)
                {
                    mMinUv.x = mUv2.x;
                }

                if (mMaxUv.y < mUv2.y)
                {
                    mMaxUv.y = mUv2.y;
                }
                else if (mMinUv.y > mUv2.y)
                {
                    mMinUv.y = mUv2.y;
                }
                mNewUvArray[i] = mUv1;
                mNewUvArray[i + 1] = mUv2;
            }

            if (mMaxUv.x > 1 || mMaxUv.y > 1)
            {
                if (mMinUv.x < 0)
                {
                    mMaxUv.x += Mathf.Abs(mMinUv.x);
                }
                else
                {
                    mMinPlusX = true;
                    mMaxUv.x -= mMinUv.x;
                }

                if (mMinUv.y < 0)
                {
                    mMaxUv.y += Mathf.Abs(mMinUv.y);
                }
                else
                {
                    mMinPlusY = true;
                    mMaxUv.y -= mMinUv.y;
                }

                for (int i = 0; (i + 1) < mNewVerticeLength; i += 2)
                {
                    if (mMinPlusX)
                    {
                        mNewUvArray[i] = new Vector3(mNewUvArray[i].x - mMinUv.x, mNewUvArray[i].y, mNewUvArray[i].z);
                        mNewUvArray[i + 1] = new Vector3(mNewUvArray[i + 1].x - mMinUv.x, mNewUvArray[i + 1].y, mNewUvArray[i + 1].z);
                    }
                    else
                    {
                        mNewUvArray[i] = new Vector3(mNewUvArray[i].x + Mathf.Abs(mMinUv.x), mNewUvArray[i].y, mNewUvArray[i].z);
                        mNewUvArray[i + 1] = new Vector3(mNewUvArray[i + 1].x + Mathf.Abs(mMinUv.x), mNewUvArray[i + 1].y, mNewUvArray[i + 1].z);
                    }

                    if (mMinPlusY)
                    {
                        mNewUvArray[i] = new Vector3(mNewUvArray[i].x, mNewUvArray[i].y - mMinUv.y, mNewUvArray[i].z);
                        mNewUvArray[i + 1] = new Vector3(mNewUvArray[i + 1].x, mNewUvArray[i + 1].y - mMinUv.y, mNewUvArray[i + 1].z);
                    }
                    else
                    {
                        mNewUvArray[i] = new Vector3(mNewUvArray[i].x, mNewUvArray[i].y + Mathf.Abs(mMinUv.y), mNewUvArray[i].z);
                        mNewUvArray[i + 1] = new Vector3(mNewUvArray[i + 1].x, mNewUvArray[i + 1].y + Mathf.Abs(mMinUv.y), mNewUvArray[i + 1].z);
                    }

                    mNewUvArray[i] = new Vector3(mNewUvArray[i].x / mMaxUv.x, mNewUvArray[i].y / mMaxUv.y, mNewUvArray[i].z);
                    mNewUvArray[i + 1] = new Vector3(mNewUvArray[i + 1].x / mMaxUv.x, mNewUvArray[i + 1].y / mMaxUv.y, mNewUvArray[i + 1].z);
                }
            }



            //切断面の作成
            for (int i = 0; (i + 1) < mNewVerticeLength; i += 2)
            {
                /*表分と裏分は各々両面作っているので、重くなったときはここを工夫して片面表示でうまくできるようにしましょう。*/
                //表分の面追加
                AddTriangle(
                new Vector3[] { mNewFaceCenter, mNewVerticeArray[i], mNewVerticeArray[i + 1] },
                new Vector2[] { mUvCenter, mNewUvArray[i], mNewUvArray[i + 1] },
                new Vector3[] { -normal, -normal, -normal },
                mFrontSubIndiceLength.Length - 1,
                true
                );


                //------

                AddTriangle(
                new Vector3[] { mNewVerticeArray[i + 1], mNewVerticeArray[i], mNewFaceCenter },
                new Vector2[] { mNewUvArray[i + 1], mNewUvArray[i], mUvCenter },
                new Vector3[] { -normal, -normal, -normal },
                mFrontSubIndiceLength.Length - 1,
                true
                );

                //------

                //裏分の面追加
                AddTriangle(
                new Vector3[] { mNewFaceCenter, mNewVerticeArray[i], mNewVerticeArray[i + 1] },
                new Vector2[] { mUvCenter, mNewUvArray[i], mNewUvArray[i + 1] },
                new Vector3[] { normal, normal, normal },
                mReverseSubIndiceLength.Length - 1,
                false
                );

                //------

                AddTriangle(
                new Vector3[] { mNewVerticeArray[i + 1], mNewVerticeArray[i], mNewFaceCenter },
                new Vector2[] { mNewUvArray[i + 1], mNewUvArray[i], mUvCenter },
                new Vector3[] { normal, normal, normal },
                mReverseSubIndiceLength.Length - 1,
                false
                );
            }


            
            mFrontMesh   = new Mesh();
            mReverseMesh = new Mesh();

            //裏側用に複製
            mTargetSub = GameObject.Instantiate(targetObj);

            //debug
            List<Material> TestMaterials = new List<Material>();
            if (targetObj.GetComponent<MeshRenderer>())
            {
                TestMaterials.AddRange(targetObj.GetComponent<MeshRenderer>().materials);
            }
            else if (targetObj.GetComponent<SkinnedMeshRenderer>())
            {
                TestMaterials.AddRange(targetObj.GetComponent<SkinnedMeshRenderer>().materials);
            }
            TestMaterials.Add(cutMaterial);
            //end



            //表側のオブジェクト生成（元のオブジェクトを変える）

            mFrontMesh.name = "frontMesh";

            mMakeVerticeArray = new Vector3[mFrontVerticeLength];
            mMakeTriangleArray = new int[mFrontVerticeLength];
            mMakeUvArray = new Vector2[mFrontVerticeLength];
            mMakeNormalArray = new Vector3[mFrontVerticeLength];
            mMakeSubIndice = new int[mFrontSubIndiceLength.Length][];

            for (int sub = 0; sub < mMakeSubIndice.Length; sub++)
            {
                mMakeSubIndice[sub] = new int[mFrontSubIndiceLength[sub]];
                Array.Copy(mFrontSubIndiceArray[sub], 0, mMakeSubIndice[sub], 0, mFrontSubIndiceLength[sub]);
            }

            Array.Copy(mFrontVerticeArray, mMakeVerticeArray, mFrontVerticeLength);
            Array.Copy(mFrontNormalArray, mMakeNormalArray, mFrontVerticeLength);
            Array.Copy(mFrontUvArray, mMakeUvArray, mFrontVerticeLength);
            Array.Copy(mFrontTriangleArray, mMakeTriangleArray, mFrontVerticeLength);

            mFrontMesh.vertices = mMakeVerticeArray;
            mFrontMesh.normals = mMakeNormalArray;
            mFrontMesh.uv = mMakeUvArray;
            mFrontMesh.triangles = mMakeTriangleArray;

            mFrontMesh.subMeshCount = mFrontSubIndiceLength.Length;

            for (int sub = 0; sub < mFrontSubIndiceLength.Length; sub++)
            {
                mFrontMesh.SetIndices(mMakeSubIndice[sub], MeshTopology.Triangles, sub);
            }
            targetObj.name = targetObj.name + "+F";

            if (targetObj.GetComponent<MeshFilter>() && targetObj.GetComponent<MeshRenderer>())
            {
                targetObj.GetComponent<MeshFilter>().mesh = mFrontMesh;
                targetObj.GetComponent<MeshRenderer>().sharedMaterials = TestMaterials.ToArray();

            }
            else if (targetObj.GetComponent<SkinnedMeshRenderer>())
            {
                targetObj.GetComponent<SkinnedMeshRenderer>().sharedMesh = mFrontMesh;
                targetObj.GetComponent<SkinnedMeshRenderer>().sharedMaterials = TestMaterials.ToArray();
            }



            //裏側のオブジェクト生成（元のオブジェクトを変える）

            mMakeVerticeArray = new Vector3[mReverseVerticeLength];
            mMakeTriangleArray = new int[mReverseVerticeLength];
            mMakeUvArray = new Vector2[mReverseVerticeLength];
            mMakeNormalArray = new Vector3[mReverseVerticeLength];
            mMakeSubIndice = new int[mReverseSubIndiceLength.Length][];

            for (int sub = 0; sub < mMakeSubIndice.Length; sub++)
            {
                mMakeSubIndice[sub] = new int[mReverseSubIndiceLength[sub]];
                Array.Copy(mReverseSubIndiceArray[sub], 0, mMakeSubIndice[sub], 0, mReverseSubIndiceLength[sub]);
            }

            Array.Copy(mReverseVerticeArray, mMakeVerticeArray, mReverseVerticeLength);
            Array.Copy(mReverseNormalArray, mMakeNormalArray, mReverseVerticeLength);
            Array.Copy(mReverseUvArray, mMakeUvArray, mReverseVerticeLength);
            Array.Copy(mReverseTriangleArray, mMakeTriangleArray, mReverseVerticeLength);

            mReverseMesh.vertices = mMakeVerticeArray;
            mReverseMesh.normals = mMakeNormalArray;
            mReverseMesh.uv = mMakeUvArray;
            mReverseMesh.triangles = mMakeTriangleArray;

            mReverseMesh.subMeshCount = mReverseSubIndiceLength.Length;

            for (int sub = 0; sub < mReverseSubIndiceLength.Length; sub++)
            {
                mReverseMesh.SetIndices(mMakeSubIndice[sub], MeshTopology.Triangles, sub);
            }
            mTargetSub.name = mTargetSub.name + "+R";
            if (mTargetSub.GetComponent<MeshFilter>() && mTargetSub.GetComponent<MeshRenderer>())
            {
                mTargetSub.GetComponent<MeshFilter>().mesh = mReverseMesh;
                mTargetSub.GetComponent<MeshRenderer>().sharedMaterials = TestMaterials.ToArray();
            }
            else if (mTargetSub.GetComponent<SkinnedMeshRenderer>())
            {
                mTargetSub.GetComponent<SkinnedMeshRenderer>().sharedMesh = mReverseMesh;
                mTargetSub.GetComponent<SkinnedMeshRenderer>().sharedMaterials = TestMaterials.ToArray();
            }
        }
    }
}
